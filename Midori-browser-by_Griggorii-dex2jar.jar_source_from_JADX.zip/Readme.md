                                                               Griggorii@gmail.com

                                                      Midori decompilation tutorial convert in source

Install full readme openjdk-8-jdk https://github.com/Griggorii/openjdk-8-jdk_griggorii_build_ubuntu_20.04

Download instrument https://github.com/pxb1988/dex2jar/releases

$ sh d2j-dex2jar.sh -f Midori-browser-by_Griggorii.apk

Upload Midori-browser-by_Griggorii-dex2jar.jar to http://www.javadecompilers.com/result download result inpack source decompilation Midori-browser-by_Griggorii-dex2jar.jar_source_from_JADX.zip

Easy ? 

_______________________________

Alternative idea https://youtu.be/k6EGJOsB3fQ
