package android.support.p000v4.provider;

import android.content.Context;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;

@RequiresApi(21)
/* renamed from: android.support.v4.provider.TreeDocumentFile */
class TreeDocumentFile extends DocumentFile {
    private Context mContext;
    private Uri mUri;

    TreeDocumentFile(@Nullable DocumentFile documentFile, Context context, Uri uri) {
        super(documentFile);
        this.mContext = context;
        this.mUri = uri;
    }

    private static void closeQuietly(@Nullable AutoCloseable autoCloseable) {
        if (autoCloseable != null) {
            try {
                autoCloseable.close();
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception e2) {
            }
        }
    }

    @Nullable
    private static Uri createFile(Context context, Uri uri, String str, String str2) {
        try {
            return DocumentsContract.createDocument(context.getContentResolver(), uri, str, str2);
        } catch (Exception e) {
            return null;
        }
    }

    public boolean canRead() {
        return DocumentsContractApi19.canRead(this.mContext, this.mUri);
    }

    public boolean canWrite() {
        return DocumentsContractApi19.canWrite(this.mContext, this.mUri);
    }

    @Nullable
    public DocumentFile createDirectory(String str) {
        Uri createFile = createFile(this.mContext, this.mUri, "vnd.android.document/directory", str);
        if (createFile != null) {
            return new TreeDocumentFile(this, this.mContext, createFile);
        }
        return null;
    }

    @Nullable
    public DocumentFile createFile(String str, String str2) {
        Uri createFile = createFile(this.mContext, this.mUri, str, str2);
        if (createFile != null) {
            return new TreeDocumentFile(this, this.mContext, createFile);
        }
        return null;
    }

    public boolean delete() {
        try {
            return DocumentsContract.deleteDocument(this.mContext.getContentResolver(), this.mUri);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean exists() {
        return DocumentsContractApi19.exists(this.mContext, this.mUri);
    }

    @Nullable
    public String getName() {
        return DocumentsContractApi19.getName(this.mContext, this.mUri);
    }

    @Nullable
    public String getType() {
        return DocumentsContractApi19.getType(this.mContext, this.mUri);
    }

    public Uri getUri() {
        return this.mUri;
    }

    public boolean isDirectory() {
        return DocumentsContractApi19.isDirectory(this.mContext, this.mUri);
    }

    public boolean isFile() {
        return DocumentsContractApi19.isFile(this.mContext, this.mUri);
    }

    public boolean isVirtual() {
        return DocumentsContractApi19.isVirtual(this.mContext, this.mUri);
    }

    public long lastModified() {
        return DocumentsContractApi19.lastModified(this.mContext, this.mUri);
    }

    public long length() {
        return DocumentsContractApi19.length(this.mContext, this.mUri);
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x006a A[LOOP:1: B:11:0x0067->B:13:0x006a, LOOP_END] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.support.p000v4.provider.DocumentFile[] listFiles() {
        /*
            r9 = this;
            r6 = 0
            r7 = 0
            android.content.Context r0 = r9.mContext
            android.content.ContentResolver r0 = r0.getContentResolver()
            android.net.Uri r1 = r9.mUri
            android.net.Uri r2 = r9.mUri
            java.lang.String r2 = android.provider.DocumentsContract.getDocumentId(r2)
            android.net.Uri r1 = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(r1, r2)
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            r2 = 1
            java.lang.String[] r2 = new java.lang.String[r2]     // Catch:{ Exception -> 0x0080, all -> 0x0078 }
            r3 = 0
            java.lang.String r4 = "document_id"
            r2[r3] = r4     // Catch:{ Exception -> 0x0080, all -> 0x0078 }
            r3 = 0
            r4 = 0
            r5 = 0
            android.database.Cursor r0 = r0.query(r1, r2, r3, r4, r5)     // Catch:{ Exception -> 0x0080, all -> 0x0078 }
        L_0x0028:
            boolean r1 = r0.moveToNext()     // Catch:{ Exception -> 0x003d }
            if (r1 == 0) goto L_0x0054
            r1 = 0
            java.lang.String r1 = r0.getString(r1)     // Catch:{ Exception -> 0x003d }
            android.net.Uri r2 = r9.mUri     // Catch:{ Exception -> 0x003d }
            android.net.Uri r1 = android.provider.DocumentsContract.buildDocumentUriUsingTree(r2, r1)     // Catch:{ Exception -> 0x003d }
            r8.add(r1)     // Catch:{ Exception -> 0x003d }
            goto L_0x0028
        L_0x003d:
            r1 = move-exception
        L_0x003e:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0083 }
            r2.<init>()     // Catch:{ all -> 0x0083 }
            java.lang.String r3 = "Failed query: "
            r2.append(r3)     // Catch:{ all -> 0x0083 }
            r2.append(r1)     // Catch:{ all -> 0x0083 }
            java.lang.String r1 = "DocumentFile"
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0083 }
            android.util.Log.w(r1, r2)     // Catch:{ all -> 0x0083 }
        L_0x0054:
            closeQuietly(r0)
            int r0 = r8.size()
            android.net.Uri[] r0 = new android.net.Uri[r0]
            java.lang.Object[] r0 = r8.toArray(r0)
            android.net.Uri[] r0 = (android.net.Uri[]) r0
            int r1 = r0.length
            android.support.v4.provider.DocumentFile[] r2 = new android.support.p000v4.provider.DocumentFile[r1]
            r1 = r6
        L_0x0067:
            int r3 = r0.length
            if (r1 >= r3) goto L_0x007f
            android.support.v4.provider.TreeDocumentFile r3 = new android.support.v4.provider.TreeDocumentFile
            android.content.Context r4 = r9.mContext
            r5 = r0[r1]
            r3.<init>(r9, r4, r5)
            r2[r1] = r3
            int r1 = r1 + 1
            goto L_0x0067
        L_0x0078:
            r0 = move-exception
            r1 = r0
            r2 = r7
        L_0x007b:
            closeQuietly(r2)
            throw r1
        L_0x007f:
            return r2
        L_0x0080:
            r1 = move-exception
            r0 = r7
            goto L_0x003e
        L_0x0083:
            r1 = move-exception
            r2 = r0
            goto L_0x007b
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.provider.TreeDocumentFile.listFiles():android.support.v4.provider.DocumentFile[]");
    }

    public boolean renameTo(String str) {
        try {
            Uri renameDocument = DocumentsContract.renameDocument(this.mContext.getContentResolver(), this.mUri, str);
            if (renameDocument == null) {
                return false;
            }
            this.mUri = renameDocument;
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
