package android.support.p000v4.util;

/* renamed from: android.support.v4.util.Consumer */
public interface Consumer<T> {
    void accept(T t);
}
