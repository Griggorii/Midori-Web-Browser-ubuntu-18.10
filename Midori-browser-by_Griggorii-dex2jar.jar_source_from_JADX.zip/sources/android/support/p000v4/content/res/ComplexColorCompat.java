package android.support.p000v4.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Shader;
import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.util.Log;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
/* renamed from: android.support.v4.content.res.ComplexColorCompat */
public final class ComplexColorCompat {
    private static final String LOG_TAG = "ComplexColorCompat";
    private int mColor;
    private final ColorStateList mColorStateList;
    private final Shader mShader;

    private ComplexColorCompat(Shader shader, ColorStateList colorStateList, @ColorInt int i) {
        this.mShader = shader;
        this.mColorStateList = colorStateList;
        this.mColor = i;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0058, code lost:
        if (r3.equals("gradient") != false) goto L_0x0027;
     */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x002a  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005b  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0064  */
    @android.support.annotation.NonNull
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static android.support.p000v4.content.res.ComplexColorCompat createFromXml(@android.support.annotation.NonNull android.content.res.Resources r6, @android.support.annotation.ColorRes int r7, @android.support.annotation.Nullable android.content.res.Resources.Theme r8) throws java.io.IOException, org.xmlpull.v1.XmlPullParserException {
        /*
            r4 = 2
            r0 = 1
            android.content.res.XmlResourceParser r1 = r6.getXml(r7)
            android.util.AttributeSet r2 = android.util.Xml.asAttributeSet(r1)
        L_0x000a:
            int r3 = r1.next()
            if (r3 == r4) goto L_0x0012
            if (r3 != r0) goto L_0x000a
        L_0x0012:
            if (r3 != r4) goto L_0x006d
            java.lang.String r3 = r1.getName()
            int r4 = r3.hashCode()
            r5 = 89650992(0x557f730, float:1.01546526E-35)
            if (r4 == r5) goto L_0x0052
            r0 = 1191572447(0x4705f3df, float:34291.87)
            if (r4 == r0) goto L_0x0048
        L_0x0026:
            r0 = -1
        L_0x0027:
            switch(r0) {
                case 0: goto L_0x0064;
                case 1: goto L_0x005b;
                default: goto L_0x002a;
            }
        L_0x002a:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r1.getPositionDescription()
            r0.append(r1)
            java.lang.String r1 = ": unsupported complex color tag "
            r0.append(r1)
            r0.append(r3)
            org.xmlpull.v1.XmlPullParserException r1 = new org.xmlpull.v1.XmlPullParserException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        L_0x0048:
            java.lang.String r0 = "selector"
            boolean r0 = r3.equals(r0)
            if (r0 == 0) goto L_0x0026
            r0 = 0
            goto L_0x0027
        L_0x0052:
            java.lang.String r4 = "gradient"
            boolean r4 = r3.equals(r4)
            if (r4 == 0) goto L_0x0026
            goto L_0x0027
        L_0x005b:
            android.graphics.Shader r0 = android.support.p000v4.content.res.GradientColorInflaterCompat.createFromXmlInner(r6, r1, r2, r8)
            android.support.v4.content.res.ComplexColorCompat r0 = from((android.graphics.Shader) r0)
        L_0x0063:
            return r0
        L_0x0064:
            android.content.res.ColorStateList r0 = android.support.p000v4.content.res.ColorStateListInflaterCompat.createFromXmlInner(r6, r1, r2, r8)
            android.support.v4.content.res.ComplexColorCompat r0 = from((android.content.res.ColorStateList) r0)
            goto L_0x0063
        L_0x006d:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.String r1 = "No start tag found"
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.content.res.ComplexColorCompat.createFromXml(android.content.res.Resources, int, android.content.res.Resources$Theme):android.support.v4.content.res.ComplexColorCompat");
    }

    static ComplexColorCompat from(@ColorInt int i) {
        return new ComplexColorCompat((Shader) null, (ColorStateList) null, i);
    }

    static ComplexColorCompat from(@NonNull ColorStateList colorStateList) {
        return new ComplexColorCompat((Shader) null, colorStateList, colorStateList.getDefaultColor());
    }

    static ComplexColorCompat from(@NonNull Shader shader) {
        return new ComplexColorCompat(shader, (ColorStateList) null, 0);
    }

    @Nullable
    public static ComplexColorCompat inflate(@NonNull Resources resources, @ColorRes int i, @Nullable Resources.Theme theme) {
        try {
            return createFromXml(resources, i, theme);
        } catch (Exception e) {
            Log.e(LOG_TAG, "Failed to inflate ComplexColor.", e);
            return null;
        }
    }

    @ColorInt
    public int getColor() {
        return this.mColor;
    }

    @Nullable
    public Shader getShader() {
        return this.mShader;
    }

    public boolean isGradient() {
        return this.mShader != null;
    }

    public boolean isStateful() {
        return this.mShader == null && this.mColorStateList != null && this.mColorStateList.isStateful();
    }

    public boolean onStateChanged(int[] iArr) {
        int colorForState;
        if (!isStateful() || (colorForState = this.mColorStateList.getColorForState(iArr, this.mColorStateList.getDefaultColor())) == this.mColor) {
            return false;
        }
        this.mColor = colorForState;
        return true;
    }

    public void setColor(@ColorInt int i) {
        this.mColor = i;
    }

    public boolean willDraw() {
        return isGradient() || this.mColor != 0;
    }
}
