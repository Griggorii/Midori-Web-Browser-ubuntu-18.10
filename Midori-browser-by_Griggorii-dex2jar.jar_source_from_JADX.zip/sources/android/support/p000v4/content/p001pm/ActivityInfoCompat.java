package android.support.p000v4.content.p001pm;

@Deprecated
/* renamed from: android.support.v4.content.pm.ActivityInfoCompat */
public final class ActivityInfoCompat {
    @Deprecated
    public static final int CONFIG_UI_MODE = 512;

    private ActivityInfoCompat() {
    }
}
