package android.support.p000v4.print;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.Log;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/* renamed from: android.support.v4.print.PrintHelper */
public final class PrintHelper {
    @SuppressLint({"InlinedApi"})
    public static final int COLOR_MODE_COLOR = 2;
    @SuppressLint({"InlinedApi"})
    public static final int COLOR_MODE_MONOCHROME = 1;
    static final boolean IS_MIN_MARGINS_HANDLING_CORRECT;
    private static final String LOG_TAG = "PrintHelper";
    private static final int MAX_PRINT_SIZE = 3500;
    public static final int ORIENTATION_LANDSCAPE = 1;
    public static final int ORIENTATION_PORTRAIT = 2;
    static final boolean PRINT_ACTIVITY_RESPECTS_ORIENTATION = (Build.VERSION.SDK_INT < 20 || Build.VERSION.SDK_INT > 23);
    public static final int SCALE_MODE_FILL = 2;
    public static final int SCALE_MODE_FIT = 1;
    int mColorMode = 2;
    final Context mContext;
    BitmapFactory.Options mDecodeOptions = null;
    final Object mLock = new Object();
    int mOrientation = 1;
    int mScaleMode = 2;

    /* renamed from: android.support.v4.print.PrintHelper$OnPrintFinishCallback */
    public interface OnPrintFinishCallback {
        void onFinish();
    }

    @RequiresApi(19)
    /* renamed from: android.support.v4.print.PrintHelper$PrintBitmapAdapter */
    private class PrintBitmapAdapter extends PrintDocumentAdapter {
        private PrintAttributes mAttributes;
        private final Bitmap mBitmap;
        private final OnPrintFinishCallback mCallback;
        private final int mFittingMode;
        private final String mJobName;

        PrintBitmapAdapter(String str, int i, Bitmap bitmap, OnPrintFinishCallback onPrintFinishCallback) {
            this.mJobName = str;
            this.mFittingMode = i;
            this.mBitmap = bitmap;
            this.mCallback = onPrintFinishCallback;
        }

        public void onFinish() {
            if (this.mCallback != null) {
                this.mCallback.onFinish();
            }
        }

        public void onLayout(PrintAttributes printAttributes, PrintAttributes printAttributes2, CancellationSignal cancellationSignal, PrintDocumentAdapter.LayoutResultCallback layoutResultCallback, Bundle bundle) {
            this.mAttributes = printAttributes2;
            layoutResultCallback.onLayoutFinished(new PrintDocumentInfo.Builder(this.mJobName).setContentType(1).setPageCount(1).build(), !printAttributes2.equals(printAttributes));
        }

        public void onWrite(PageRange[] pageRangeArr, ParcelFileDescriptor parcelFileDescriptor, CancellationSignal cancellationSignal, PrintDocumentAdapter.WriteResultCallback writeResultCallback) {
            PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, parcelFileDescriptor, cancellationSignal, writeResultCallback);
        }
    }

    @RequiresApi(19)
    /* renamed from: android.support.v4.print.PrintHelper$PrintUriAdapter */
    private class PrintUriAdapter extends PrintDocumentAdapter {
        PrintAttributes mAttributes;
        Bitmap mBitmap = null;
        final OnPrintFinishCallback mCallback;
        final int mFittingMode;
        final Uri mImageFile;
        final String mJobName;
        AsyncTask<Uri, Boolean, Bitmap> mLoadBitmap;

        PrintUriAdapter(String str, Uri uri, OnPrintFinishCallback onPrintFinishCallback, int i) {
            this.mJobName = str;
            this.mImageFile = uri;
            this.mCallback = onPrintFinishCallback;
            this.mFittingMode = i;
        }

        /* access modifiers changed from: package-private */
        public void cancelLoad() {
            synchronized (PrintHelper.this.mLock) {
                if (PrintHelper.this.mDecodeOptions != null) {
                    if (Build.VERSION.SDK_INT < 24) {
                        PrintHelper.this.mDecodeOptions.requestCancelDecode();
                    }
                    PrintHelper.this.mDecodeOptions = null;
                }
            }
        }

        public void onFinish() {
            super.onFinish();
            cancelLoad();
            if (this.mLoadBitmap != null) {
                this.mLoadBitmap.cancel(true);
            }
            if (this.mCallback != null) {
                this.mCallback.onFinish();
            }
            if (this.mBitmap != null) {
                this.mBitmap.recycle();
                this.mBitmap = null;
            }
        }

        public void onLayout(PrintAttributes printAttributes, PrintAttributes printAttributes2, CancellationSignal cancellationSignal, PrintDocumentAdapter.LayoutResultCallback layoutResultCallback, Bundle bundle) {
            synchronized (this) {
                this.mAttributes = printAttributes2;
            }
            if (cancellationSignal.isCanceled()) {
                layoutResultCallback.onLayoutCancelled();
            } else if (this.mBitmap != null) {
                layoutResultCallback.onLayoutFinished(new PrintDocumentInfo.Builder(this.mJobName).setContentType(1).setPageCount(1).build(), !printAttributes2.equals(printAttributes));
            } else {
                final CancellationSignal cancellationSignal2 = cancellationSignal;
                final PrintAttributes printAttributes3 = printAttributes2;
                final PrintAttributes printAttributes4 = printAttributes;
                final PrintDocumentAdapter.LayoutResultCallback layoutResultCallback2 = layoutResultCallback;
                this.mLoadBitmap = new AsyncTask<Uri, Boolean, Bitmap>() {
                    /* access modifiers changed from: protected */
                    public Bitmap doInBackground(Uri... uriArr) {
                        try {
                            return PrintHelper.this.loadConstrainedBitmap(PrintUriAdapter.this.mImageFile);
                        } catch (FileNotFoundException e) {
                            return null;
                        }
                    }

                    /* access modifiers changed from: protected */
                    public void onCancelled(Bitmap bitmap) {
                        layoutResultCallback2.onLayoutCancelled();
                        PrintUriAdapter.this.mLoadBitmap = null;
                    }

                    /* access modifiers changed from: protected */
                    /* JADX WARNING: Code restructure failed: missing block: B:11:0x001e, code lost:
                        if (r0 == null) goto L_0x0042;
                     */
                    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0028, code lost:
                        if (r0.isPortrait() == android.support.p000v4.print.PrintHelper.isPortrait(r9)) goto L_0x0042;
                     */
                    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002a, code lost:
                        r5 = new android.graphics.Matrix();
                        r5.postRotate(90.0f);
                        r9 = android.graphics.Bitmap.createBitmap(r9, 0, 0, r9.getWidth(), r9.getHeight(), r5, true);
                     */
                    /* Code decompiled incorrectly, please refer to instructions dump. */
                    public void onPostExecute(android.graphics.Bitmap r9) {
                        /*
                            r8 = this;
                            r7 = 0
                            r1 = 0
                            r6 = 1
                            super.onPostExecute(r9)
                            if (r9 == 0) goto L_0x0042
                            boolean r0 = android.support.p000v4.print.PrintHelper.PRINT_ACTIVITY_RESPECTS_ORIENTATION
                            if (r0 == 0) goto L_0x0014
                            android.support.v4.print.PrintHelper$PrintUriAdapter r0 = android.support.p000v4.print.PrintHelper.PrintUriAdapter.this
                            android.support.v4.print.PrintHelper r0 = android.support.p000v4.print.PrintHelper.this
                            int r0 = r0.mOrientation
                            if (r0 != 0) goto L_0x0042
                        L_0x0014:
                            monitor-enter(r8)
                            android.support.v4.print.PrintHelper$PrintUriAdapter r0 = android.support.p000v4.print.PrintHelper.PrintUriAdapter.this     // Catch:{ all -> 0x007a }
                            android.print.PrintAttributes r0 = r0.mAttributes     // Catch:{ all -> 0x007a }
                            android.print.PrintAttributes$MediaSize r0 = r0.getMediaSize()     // Catch:{ all -> 0x007a }
                            monitor-exit(r8)     // Catch:{ all -> 0x0071 }
                            if (r0 == 0) goto L_0x0042
                            boolean r0 = r0.isPortrait()
                            boolean r2 = android.support.p000v4.print.PrintHelper.isPortrait(r9)
                            if (r0 == r2) goto L_0x0042
                            android.graphics.Matrix r5 = new android.graphics.Matrix
                            r5.<init>()
                            r0 = 1119092736(0x42b40000, float:90.0)
                            r5.postRotate(r0)
                            int r3 = r9.getWidth()
                            int r4 = r9.getHeight()
                            r0 = r9
                            r2 = r1
                            android.graphics.Bitmap r9 = android.graphics.Bitmap.createBitmap(r0, r1, r2, r3, r4, r5, r6)
                        L_0x0042:
                            android.support.v4.print.PrintHelper$PrintUriAdapter r0 = android.support.p000v4.print.PrintHelper.PrintUriAdapter.this
                            r0.mBitmap = r9
                            if (r9 == 0) goto L_0x0074
                            android.print.PrintDocumentInfo$Builder r0 = new android.print.PrintDocumentInfo$Builder
                            android.support.v4.print.PrintHelper$PrintUriAdapter r1 = android.support.p000v4.print.PrintHelper.PrintUriAdapter.this
                            java.lang.String r1 = r1.mJobName
                            r0.<init>(r1)
                            android.print.PrintDocumentInfo$Builder r0 = r0.setContentType(r6)
                            android.print.PrintDocumentInfo$Builder r0 = r0.setPageCount(r6)
                            android.print.PrintDocumentInfo r0 = r0.build()
                            android.print.PrintAttributes r1 = r3
                            android.print.PrintAttributes r2 = r4
                            boolean r1 = r1.equals(r2)
                            android.print.PrintDocumentAdapter$LayoutResultCallback r2 = r5
                            r1 = r1 ^ 1
                            r2.onLayoutFinished(r0, r1)
                        L_0x006c:
                            android.support.v4.print.PrintHelper$PrintUriAdapter r0 = android.support.p000v4.print.PrintHelper.PrintUriAdapter.this
                            r0.mLoadBitmap = r7
                            return
                        L_0x0071:
                            r0 = move-exception
                        L_0x0072:
                            monitor-exit(r8)     // Catch:{ all -> 0x007a }
                            throw r0
                        L_0x0074:
                            android.print.PrintDocumentAdapter$LayoutResultCallback r0 = r5
                            r0.onLayoutFailed(r7)
                            goto L_0x006c
                        L_0x007a:
                            r0 = move-exception
                            goto L_0x0072
                        */
                        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.print.PrintHelper.PrintUriAdapter.C02481.onPostExecute(android.graphics.Bitmap):void");
                    }

                    /* access modifiers changed from: protected */
                    public void onPreExecute() {
                        cancellationSignal2.setOnCancelListener(new CancellationSignal.OnCancelListener() {
                            public void onCancel() {
                                PrintUriAdapter.this.cancelLoad();
                                C02481.this.cancel(false);
                            }
                        });
                    }
                }.execute(new Uri[0]);
            }
        }

        public void onWrite(PageRange[] pageRangeArr, ParcelFileDescriptor parcelFileDescriptor, CancellationSignal cancellationSignal, PrintDocumentAdapter.WriteResultCallback writeResultCallback) {
            PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, parcelFileDescriptor, cancellationSignal, writeResultCallback);
        }
    }

    static {
        boolean z = true;
        if (Build.VERSION.SDK_INT == 23) {
            z = false;
        }
        IS_MIN_MARGINS_HANDLING_CORRECT = z;
    }

    public PrintHelper(@NonNull Context context) {
        this.mContext = context;
    }

    static Bitmap convertBitmapForColorMode(Bitmap bitmap, int i) {
        if (i != 1) {
            return bitmap;
        }
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint();
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0.0f);
        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        canvas.setBitmap((Bitmap) null);
        return createBitmap;
    }

    @RequiresApi(19)
    private static PrintAttributes.Builder copyAttributes(PrintAttributes printAttributes) {
        PrintAttributes.Builder minMargins = new PrintAttributes.Builder().setMediaSize(printAttributes.getMediaSize()).setResolution(printAttributes.getResolution()).setMinMargins(printAttributes.getMinMargins());
        if (printAttributes.getColorMode() != 0) {
            minMargins.setColorMode(printAttributes.getColorMode());
        }
        if (Build.VERSION.SDK_INT >= 23 && printAttributes.getDuplexMode() != 0) {
            minMargins.setDuplexMode(printAttributes.getDuplexMode());
        }
        return minMargins;
    }

    static Matrix getMatrix(int i, int i2, RectF rectF, int i3) {
        Matrix matrix = new Matrix();
        float width = rectF.width() / ((float) i);
        float max = i3 == 2 ? Math.max(width, rectF.height() / ((float) i2)) : Math.min(width, rectF.height() / ((float) i2));
        matrix.postScale(max, max);
        matrix.postTranslate((rectF.width() - (((float) i) * max)) / 2.0f, (rectF.height() - (max * ((float) i2))) / 2.0f);
        return matrix;
    }

    static boolean isPortrait(Bitmap bitmap) {
        return bitmap.getWidth() <= bitmap.getHeight();
    }

    private Bitmap loadBitmap(Uri uri, BitmapFactory.Options options) throws FileNotFoundException {
        InputStream inputStream = null;
        if (uri == null || this.mContext == null) {
            throw new IllegalArgumentException("bad argument to loadBitmap");
        }
        try {
            inputStream = this.mContext.getContentResolver().openInputStream(uri);
            Bitmap decodeStream = BitmapFactory.decodeStream(inputStream, (Rect) null, options);
            if (inputStream != null) {
                try {
                } catch (IOException e) {
                    Log.w(LOG_TAG, "close fail ", e);
                }
            }
            return decodeStream;
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e2) {
                    Log.w(LOG_TAG, "close fail ", e2);
                }
            }
        }
    }

    public static boolean systemSupportsPrint() {
        return Build.VERSION.SDK_INT >= 19;
    }

    public int getColorMode() {
        return this.mColorMode;
    }

    public int getOrientation() {
        if (Build.VERSION.SDK_INT < 19 || this.mOrientation != 0) {
            return this.mOrientation;
        }
        return 1;
    }

    public int getScaleMode() {
        return this.mScaleMode;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:22:?, code lost:
        r0 = loadBitmap(r7, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x004a, code lost:
        r1 = r6.mLock;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x004d, code lost:
        monitor-enter(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
        r6.mDecodeOptions = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0051, code lost:
        monitor-exit(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0056, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0059, code lost:
        monitor-enter(r6.mLock);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:?, code lost:
        r6.mDecodeOptions = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x005e, code lost:
        throw r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.Bitmap loadConstrainedBitmap(android.net.Uri r7) throws java.io.FileNotFoundException {
        /*
            r6 = this;
            r1 = 1
            r0 = 0
            if (r7 == 0) goto L_0x0065
            android.content.Context r2 = r6.mContext
            if (r2 == 0) goto L_0x0065
            android.graphics.BitmapFactory$Options r2 = new android.graphics.BitmapFactory$Options
            r2.<init>()
            r2.inJustDecodeBounds = r1
            r6.loadBitmap(r7, r2)
            int r3 = r2.outWidth
            int r4 = r2.outHeight
            if (r3 <= 0) goto L_0x001a
            if (r4 > 0) goto L_0x001b
        L_0x001a:
            return r0
        L_0x001b:
            int r2 = java.lang.Math.max(r3, r4)
        L_0x001f:
            r5 = 3500(0xdac, float:4.905E-42)
            if (r2 <= r5) goto L_0x0028
            int r2 = r2 >>> 1
            int r1 = r1 << 1
            goto L_0x001f
        L_0x0028:
            if (r1 <= 0) goto L_0x001a
            int r2 = java.lang.Math.min(r3, r4)
            int r2 = r2 / r1
            if (r2 <= 0) goto L_0x001a
            java.lang.Object r2 = r6.mLock
            monitor-enter(r2)
            android.graphics.BitmapFactory$Options r0 = new android.graphics.BitmapFactory$Options     // Catch:{ all -> 0x006d }
            r0.<init>()     // Catch:{ all -> 0x006d }
            r6.mDecodeOptions = r0     // Catch:{ all -> 0x006d }
            android.graphics.BitmapFactory$Options r0 = r6.mDecodeOptions     // Catch:{ all -> 0x006d }
            r3 = 1
            r0.inMutable = r3     // Catch:{ all -> 0x006d }
            android.graphics.BitmapFactory$Options r0 = r6.mDecodeOptions     // Catch:{ all -> 0x006d }
            r0.inSampleSize = r1     // Catch:{ all -> 0x006d }
            android.graphics.BitmapFactory$Options r0 = r6.mDecodeOptions     // Catch:{ all -> 0x006d }
            monitor-exit(r2)     // Catch:{ all -> 0x0062 }
            android.graphics.Bitmap r0 = r6.loadBitmap(r7, r0)     // Catch:{ all -> 0x0056 }
            java.lang.Object r1 = r6.mLock
            monitor-enter(r1)
            r2 = 0
            r6.mDecodeOptions = r2     // Catch:{ all -> 0x0053 }
            monitor-exit(r1)     // Catch:{ all -> 0x0053 }
            goto L_0x001a
        L_0x0053:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0053 }
            throw r0
        L_0x0056:
            r0 = move-exception
            java.lang.Object r1 = r6.mLock
            monitor-enter(r1)
            r2 = 0
            r6.mDecodeOptions = r2     // Catch:{ all -> 0x005f }
            monitor-exit(r1)     // Catch:{ all -> 0x005f }
            throw r0
        L_0x005f:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x005f }
            throw r0
        L_0x0062:
            r0 = move-exception
        L_0x0063:
            monitor-exit(r2)     // Catch:{ all -> 0x006d }
            throw r0
        L_0x0065:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "bad argument to getScaledBitmap"
            r0.<init>(r1)
            throw r0
        L_0x006d:
            r0 = move-exception
            goto L_0x0063
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.print.PrintHelper.loadConstrainedBitmap(android.net.Uri):android.graphics.Bitmap");
    }

    public void printBitmap(@NonNull String str, @NonNull Bitmap bitmap) {
        printBitmap(str, bitmap, (OnPrintFinishCallback) null);
    }

    public void printBitmap(@NonNull String str, @NonNull Bitmap bitmap, @Nullable OnPrintFinishCallback onPrintFinishCallback) {
        if (Build.VERSION.SDK_INT >= 19 && bitmap != null) {
            ((PrintManager) this.mContext.getSystemService("print")).print(str, new PrintBitmapAdapter(str, this.mScaleMode, bitmap, onPrintFinishCallback), new PrintAttributes.Builder().setMediaSize(isPortrait(bitmap) ? PrintAttributes.MediaSize.UNKNOWN_PORTRAIT : PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE).setColorMode(this.mColorMode).build());
        }
    }

    public void printBitmap(@NonNull String str, @NonNull Uri uri) throws FileNotFoundException {
        printBitmap(str, uri, (OnPrintFinishCallback) null);
    }

    public void printBitmap(@NonNull String str, @NonNull Uri uri, @Nullable OnPrintFinishCallback onPrintFinishCallback) throws FileNotFoundException {
        if (Build.VERSION.SDK_INT >= 19) {
            PrintUriAdapter printUriAdapter = new PrintUriAdapter(str, uri, onPrintFinishCallback, this.mScaleMode);
            PrintManager printManager = (PrintManager) this.mContext.getSystemService("print");
            PrintAttributes.Builder builder = new PrintAttributes.Builder();
            builder.setColorMode(this.mColorMode);
            if (this.mOrientation == 1 || this.mOrientation == 0) {
                builder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE);
            } else if (this.mOrientation == 2) {
                builder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_PORTRAIT);
            }
            printManager.print(str, printUriAdapter, builder.build());
        }
    }

    public void setColorMode(int i) {
        this.mColorMode = i;
    }

    public void setOrientation(int i) {
        this.mOrientation = i;
    }

    public void setScaleMode(int i) {
        this.mScaleMode = i;
    }

    /* access modifiers changed from: package-private */
    @RequiresApi(19)
    public void writeBitmap(PrintAttributes printAttributes, int i, Bitmap bitmap, ParcelFileDescriptor parcelFileDescriptor, CancellationSignal cancellationSignal, PrintDocumentAdapter.WriteResultCallback writeResultCallback) {
        final PrintAttributes build = IS_MIN_MARGINS_HANDLING_CORRECT ? printAttributes : copyAttributes(printAttributes).setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0)).build();
        final CancellationSignal cancellationSignal2 = cancellationSignal;
        final Bitmap bitmap2 = bitmap;
        final PrintAttributes printAttributes2 = printAttributes;
        final int i2 = i;
        final ParcelFileDescriptor parcelFileDescriptor2 = parcelFileDescriptor;
        final PrintDocumentAdapter.WriteResultCallback writeResultCallback2 = writeResultCallback;
        new AsyncTask<Void, Void, Throwable>() {
            /* access modifiers changed from: protected */
            /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
            /* JADX WARNING: Unknown top exception splitter block from list: {B:20:0x0070=Splitter:B:20:0x0070, B:33:0x00ab=Splitter:B:33:0x00ab, B:46:0x00dc=Splitter:B:46:0x00dc} */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public java.lang.Throwable doInBackground(java.lang.Void... r9) {
                /*
                    r8 = this;
                    r0 = 0
                    android.os.CancellationSignal r1 = r2     // Catch:{ Throwable -> 0x0078 }
                    boolean r1 = r1.isCanceled()     // Catch:{ Throwable -> 0x0078 }
                    if (r1 == 0) goto L_0x000a
                L_0x0009:
                    return r0
                L_0x000a:
                    android.print.pdf.PrintedPdfDocument r2 = new android.print.pdf.PrintedPdfDocument     // Catch:{ Throwable -> 0x0078 }
                    android.support.v4.print.PrintHelper r1 = android.support.p000v4.print.PrintHelper.this     // Catch:{ Throwable -> 0x0078 }
                    android.content.Context r1 = r1.mContext     // Catch:{ Throwable -> 0x0078 }
                    android.print.PrintAttributes r3 = r3     // Catch:{ Throwable -> 0x0078 }
                    r2.<init>(r1, r3)     // Catch:{ Throwable -> 0x0078 }
                    android.graphics.Bitmap r1 = r4     // Catch:{ Throwable -> 0x0078 }
                    android.print.PrintAttributes r3 = r3     // Catch:{ Throwable -> 0x0078 }
                    int r3 = r3.getColorMode()     // Catch:{ Throwable -> 0x0078 }
                    android.graphics.Bitmap r3 = android.support.p000v4.print.PrintHelper.convertBitmapForColorMode(r1, r3)     // Catch:{ Throwable -> 0x0078 }
                    android.os.CancellationSignal r1 = r2     // Catch:{ Throwable -> 0x0078 }
                    boolean r1 = r1.isCanceled()     // Catch:{ Throwable -> 0x0078 }
                    if (r1 != 0) goto L_0x0009
                    r1 = 1
                    android.graphics.pdf.PdfDocument$Page r4 = r2.startPage(r1)     // Catch:{ all -> 0x009e }
                    boolean r1 = android.support.p000v4.print.PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT     // Catch:{ all -> 0x009e }
                    if (r1 == 0) goto L_0x007a
                    android.graphics.RectF r1 = new android.graphics.RectF     // Catch:{ all -> 0x009e }
                    android.graphics.pdf.PdfDocument$PageInfo r5 = r4.getInfo()     // Catch:{ all -> 0x009e }
                    android.graphics.Rect r5 = r5.getContentRect()     // Catch:{ all -> 0x009e }
                    r1.<init>(r5)     // Catch:{ all -> 0x009e }
                L_0x003f:
                    int r5 = r3.getWidth()     // Catch:{ all -> 0x009e }
                    int r6 = r3.getHeight()     // Catch:{ all -> 0x009e }
                    int r7 = r6     // Catch:{ all -> 0x009e }
                    android.graphics.Matrix r5 = android.support.p000v4.print.PrintHelper.getMatrix(r5, r6, r1, r7)     // Catch:{ all -> 0x009e }
                    boolean r6 = android.support.p000v4.print.PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT     // Catch:{ all -> 0x009e }
                    if (r6 == 0) goto L_0x00b3
                L_0x0051:
                    android.graphics.Canvas r1 = r4.getCanvas()     // Catch:{ all -> 0x009e }
                    r6 = 0
                    r1.drawBitmap(r3, r5, r6)     // Catch:{ all -> 0x009e }
                    r2.finishPage(r4)     // Catch:{ all -> 0x009e }
                    android.os.CancellationSignal r1 = r2     // Catch:{ all -> 0x009e }
                    boolean r1 = r1.isCanceled()     // Catch:{ all -> 0x009e }
                    if (r1 == 0) goto L_0x00c2
                    r2.close()     // Catch:{ Throwable -> 0x0078 }
                    android.os.ParcelFileDescriptor r1 = r7     // Catch:{ Throwable -> 0x0078 }
                    if (r1 == 0) goto L_0x0070
                    android.os.ParcelFileDescriptor r1 = r7     // Catch:{ IOException -> 0x00e9 }
                    r1.close()     // Catch:{ IOException -> 0x00e9 }
                L_0x0070:
                    android.graphics.Bitmap r1 = r4     // Catch:{ Throwable -> 0x0078 }
                    if (r3 == r1) goto L_0x0009
                    r3.recycle()     // Catch:{ Throwable -> 0x0078 }
                    goto L_0x0009
                L_0x0078:
                    r0 = move-exception
                    goto L_0x0009
                L_0x007a:
                    android.print.pdf.PrintedPdfDocument r5 = new android.print.pdf.PrintedPdfDocument     // Catch:{ all -> 0x009e }
                    android.support.v4.print.PrintHelper r1 = android.support.p000v4.print.PrintHelper.this     // Catch:{ all -> 0x009e }
                    android.content.Context r1 = r1.mContext     // Catch:{ all -> 0x009e }
                    android.print.PrintAttributes r6 = r5     // Catch:{ all -> 0x009e }
                    r5.<init>(r1, r6)     // Catch:{ all -> 0x009e }
                    r1 = 1
                    android.graphics.pdf.PdfDocument$Page r6 = r5.startPage(r1)     // Catch:{ all -> 0x009e }
                    android.graphics.RectF r1 = new android.graphics.RectF     // Catch:{ all -> 0x009e }
                    android.graphics.pdf.PdfDocument$PageInfo r7 = r6.getInfo()     // Catch:{ all -> 0x009e }
                    android.graphics.Rect r7 = r7.getContentRect()     // Catch:{ all -> 0x009e }
                    r1.<init>(r7)     // Catch:{ all -> 0x009e }
                    r5.finishPage(r6)     // Catch:{ all -> 0x009e }
                    r5.close()     // Catch:{ all -> 0x009e }
                    goto L_0x003f
                L_0x009e:
                    r0 = move-exception
                    r2.close()     // Catch:{ Throwable -> 0x0078 }
                    android.os.ParcelFileDescriptor r1 = r7     // Catch:{ Throwable -> 0x0078 }
                    if (r1 == 0) goto L_0x00ab
                    android.os.ParcelFileDescriptor r1 = r7     // Catch:{ IOException -> 0x00e5 }
                    r1.close()     // Catch:{ IOException -> 0x00e5 }
                L_0x00ab:
                    android.graphics.Bitmap r1 = r4     // Catch:{ Throwable -> 0x0078 }
                    if (r3 == r1) goto L_0x00b2
                    r3.recycle()     // Catch:{ Throwable -> 0x0078 }
                L_0x00b2:
                    throw r0     // Catch:{ Throwable -> 0x0078 }
                L_0x00b3:
                    float r6 = r1.left     // Catch:{ all -> 0x009e }
                    float r7 = r1.top     // Catch:{ all -> 0x009e }
                    r5.postTranslate(r6, r7)     // Catch:{ all -> 0x009e }
                    android.graphics.Canvas r6 = r4.getCanvas()     // Catch:{ all -> 0x009e }
                    r6.clipRect(r1)     // Catch:{ all -> 0x009e }
                    goto L_0x0051
                L_0x00c2:
                    java.io.FileOutputStream r1 = new java.io.FileOutputStream     // Catch:{ all -> 0x009e }
                    android.os.ParcelFileDescriptor r4 = r7     // Catch:{ all -> 0x009e }
                    java.io.FileDescriptor r4 = r4.getFileDescriptor()     // Catch:{ all -> 0x009e }
                    r1.<init>(r4)     // Catch:{ all -> 0x009e }
                    r2.writeTo(r1)     // Catch:{ all -> 0x009e }
                    r2.close()     // Catch:{ Throwable -> 0x0078 }
                    android.os.ParcelFileDescriptor r1 = r7     // Catch:{ Throwable -> 0x0078 }
                    if (r1 == 0) goto L_0x00dc
                    android.os.ParcelFileDescriptor r1 = r7     // Catch:{ IOException -> 0x00e7 }
                    r1.close()     // Catch:{ IOException -> 0x00e7 }
                L_0x00dc:
                    android.graphics.Bitmap r1 = r4     // Catch:{ Throwable -> 0x0078 }
                    if (r3 == r1) goto L_0x0009
                    r3.recycle()     // Catch:{ Throwable -> 0x0078 }
                    goto L_0x0009
                L_0x00e5:
                    r1 = move-exception
                    goto L_0x00ab
                L_0x00e7:
                    r1 = move-exception
                    goto L_0x00dc
                L_0x00e9:
                    r1 = move-exception
                    goto L_0x0070
                */
                throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.print.PrintHelper.C02471.doInBackground(java.lang.Void[]):java.lang.Throwable");
            }

            /* access modifiers changed from: protected */
            public void onPostExecute(Throwable th) {
                if (cancellationSignal2.isCanceled()) {
                    writeResultCallback2.onWriteCancelled();
                } else if (th == null) {
                    writeResultCallback2.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                } else {
                    Log.e(PrintHelper.LOG_TAG, "Error writing printed content", th);
                    writeResultCallback2.onWriteFailed((CharSequence) null);
                }
            }
        }.execute(new Void[0]);
    }
}
