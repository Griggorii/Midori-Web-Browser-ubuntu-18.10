package android.support.p000v4.graphics;

import android.graphics.Path;
import android.support.annotation.RestrictTo;
import android.util.Log;
import java.util.ArrayList;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
/* renamed from: android.support.v4.graphics.PathParser */
public class PathParser {
    private static final String LOGTAG = "PathParser";

    /* renamed from: android.support.v4.graphics.PathParser$ExtractFloatResult */
    private static class ExtractFloatResult {
        int mEndPosition;
        boolean mEndWithNegOrDot;

        ExtractFloatResult() {
        }
    }

    /* renamed from: android.support.v4.graphics.PathParser$PathDataNode */
    public static class PathDataNode {
        @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
        public float[] mParams;
        @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
        public char mType;

        PathDataNode(char c, float[] fArr) {
            this.mType = (char) c;
            this.mParams = fArr;
        }

        PathDataNode(PathDataNode pathDataNode) {
            this.mType = (char) pathDataNode.mType;
            this.mParams = PathParser.copyOfRange(pathDataNode.mParams, 0, pathDataNode.mParams.length);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0065, code lost:
            r12 = r2;
            r1 = r4;
            r3 = r5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0068, code lost:
            r5 = r12;
            r6 = r13;
            r2 = r14;
            r4 = r15;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:54:0x01f7, code lost:
            r1 = r7;
            r2 = r14;
            r4 = r15;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private static void addCommand(android.graphics.Path r17, float[] r18, char r19, char r20, float[] r21) {
            /*
                r7 = 2
                r1 = 0
                r6 = r18[r1]
                r1 = 1
                r5 = r18[r1]
                r1 = 2
                r3 = r18[r1]
                r1 = 3
                r1 = r18[r1]
                r2 = 4
                r4 = r18[r2]
                r2 = 5
                r2 = r18[r2]
                switch(r20) {
                    case 65: goto L_0x0051;
                    case 67: goto L_0x004e;
                    case 72: goto L_0x004b;
                    case 76: goto L_0x0048;
                    case 77: goto L_0x0048;
                    case 81: goto L_0x0045;
                    case 83: goto L_0x0045;
                    case 84: goto L_0x0048;
                    case 86: goto L_0x004b;
                    case 90: goto L_0x0037;
                    case 97: goto L_0x0051;
                    case 99: goto L_0x004e;
                    case 104: goto L_0x004b;
                    case 108: goto L_0x0048;
                    case 109: goto L_0x0048;
                    case 113: goto L_0x0045;
                    case 115: goto L_0x0045;
                    case 116: goto L_0x0048;
                    case 118: goto L_0x004b;
                    case 122: goto L_0x0037;
                    default: goto L_0x0016;
                }
            L_0x0016:
                r11 = r7
            L_0x0017:
                r7 = 0
                r12 = r5
                r13 = r6
                r14 = r2
                r15 = r4
                r16 = r7
            L_0x001e:
                r0 = r21
                int r2 = r0.length
                r0 = r16
                if (r0 >= r2) goto L_0x0399
                switch(r20) {
                    case 65: goto L_0x0358;
                    case 67: goto L_0x0326;
                    case 72: goto L_0x0313;
                    case 76: goto L_0x02f8;
                    case 77: goto L_0x02c8;
                    case 81: goto L_0x029e;
                    case 83: goto L_0x0250;
                    case 84: goto L_0x0213;
                    case 86: goto L_0x0200;
                    case 97: goto L_0x01b6;
                    case 99: goto L_0x0181;
                    case 104: goto L_0x0170;
                    case 108: goto L_0x0156;
                    case 109: goto L_0x0125;
                    case 113: goto L_0x00f8;
                    case 115: goto L_0x00ac;
                    case 116: goto L_0x006d;
                    case 118: goto L_0x0054;
                    default: goto L_0x0028;
                }
            L_0x0028:
                r5 = r12
                r6 = r13
                r2 = r14
                r4 = r15
            L_0x002c:
                int r7 = r16 + r11
                r19 = r20
                r12 = r5
                r13 = r6
                r14 = r2
                r15 = r4
                r16 = r7
                goto L_0x001e
            L_0x0037:
                r17.close()
                r0 = r17
                r0.moveTo(r4, r2)
                r1 = r2
                r3 = r4
                r5 = r2
                r6 = r4
                r11 = r7
                goto L_0x0017
            L_0x0045:
                r7 = 4
                r11 = r7
                goto L_0x0017
            L_0x0048:
                r7 = 2
                r11 = r7
                goto L_0x0017
            L_0x004b:
                r7 = 1
                r11 = r7
                goto L_0x0017
            L_0x004e:
                r7 = 6
                r11 = r7
                goto L_0x0017
            L_0x0051:
                r7 = 7
                r11 = r7
                goto L_0x0017
            L_0x0054:
                r2 = 0
                int r4 = r16 + 0
                r4 = r21[r4]
                r0 = r17
                r0.rLineTo(r2, r4)
                int r2 = r16 + 0
                r2 = r21[r2]
                float r2 = r2 + r12
                r4 = r1
                r5 = r3
            L_0x0065:
                r12 = r2
                r1 = r4
                r3 = r5
            L_0x0068:
                r5 = r12
                r6 = r13
                r2 = r14
                r4 = r15
                goto L_0x002c
            L_0x006d:
                r4 = 0
                r2 = 0
                r5 = 113(0x71, float:1.58E-43)
                r0 = r19
                if (r0 == r5) goto L_0x0087
                r5 = 116(0x74, float:1.63E-43)
                r0 = r19
                if (r0 == r5) goto L_0x0087
                r5 = 81
                r0 = r19
                if (r0 == r5) goto L_0x0087
                r5 = 84
                r0 = r19
                if (r0 != r5) goto L_0x008d
            L_0x0087:
                float r3 = r13 - r3
                float r1 = r12 - r1
                r2 = r1
                r4 = r3
            L_0x008d:
                int r1 = r16 + 0
                r1 = r21[r1]
                int r3 = r16 + 1
                r3 = r21[r3]
                r0 = r17
                r0.rQuadTo(r4, r2, r1, r3)
                int r1 = r16 + 0
                r1 = r21[r1]
                float r3 = r13 + r1
                int r1 = r16 + 1
                r1 = r21[r1]
                float r1 = r1 + r12
                float r5 = r13 + r4
                float r4 = r12 + r2
                r2 = r1
                r13 = r3
                goto L_0x0065
            L_0x00ac:
                r2 = 99
                r0 = r19
                if (r0 == r2) goto L_0x00c4
                r2 = 115(0x73, float:1.61E-43)
                r0 = r19
                if (r0 == r2) goto L_0x00c4
                r2 = 67
                r0 = r19
                if (r0 == r2) goto L_0x00c4
                r2 = 83
                r0 = r19
                if (r0 != r2) goto L_0x00f5
            L_0x00c4:
                float r2 = r13 - r3
                float r3 = r12 - r1
            L_0x00c8:
                int r1 = r16 + 0
                r4 = r21[r1]
                int r1 = r16 + 1
                r5 = r21[r1]
                int r1 = r16 + 2
                r6 = r21[r1]
                int r1 = r16 + 3
                r7 = r21[r1]
                r1 = r17
                r1.rCubicTo(r2, r3, r4, r5, r6, r7)
                int r1 = r16 + 0
                r1 = r21[r1]
                float r3 = r1 + r13
                int r1 = r16 + 1
                r1 = r21[r1]
                float r1 = r1 + r12
                int r2 = r16 + 2
                r2 = r21[r2]
                float r13 = r13 + r2
                int r2 = r16 + 3
                r2 = r21[r2]
                float r2 = r2 + r12
                r12 = r2
                goto L_0x0068
            L_0x00f5:
                r2 = 0
                r3 = 0
                goto L_0x00c8
            L_0x00f8:
                int r1 = r16 + 0
                r1 = r21[r1]
                int r2 = r16 + 1
                r2 = r21[r2]
                int r3 = r16 + 2
                r3 = r21[r3]
                int r4 = r16 + 3
                r4 = r21[r4]
                r0 = r17
                r0.rQuadTo(r1, r2, r3, r4)
                int r1 = r16 + 0
                r1 = r21[r1]
                float r3 = r1 + r13
                int r1 = r16 + 1
                r1 = r21[r1]
                float r1 = r1 + r12
                int r2 = r16 + 2
                r2 = r21[r2]
                float r13 = r13 + r2
                int r2 = r16 + 3
                r2 = r21[r2]
                float r2 = r2 + r12
                r12 = r2
                goto L_0x0068
            L_0x0125:
                int r2 = r16 + 0
                r2 = r21[r2]
                float r4 = r13 + r2
                int r2 = r16 + 1
                r2 = r21[r2]
                float r2 = r2 + r12
                if (r16 <= 0) goto L_0x0143
                int r5 = r16 + 0
                r5 = r21[r5]
                int r6 = r16 + 1
                r6 = r21[r6]
                r0 = r17
                r0.rLineTo(r5, r6)
                r12 = r2
                r13 = r4
                goto L_0x0068
            L_0x0143:
                int r5 = r16 + 0
                r5 = r21[r5]
                int r6 = r16 + 1
                r6 = r21[r6]
                r0 = r17
                r0.rMoveTo(r5, r6)
                r12 = r2
                r13 = r4
                r14 = r2
                r15 = r4
                goto L_0x0068
            L_0x0156:
                int r2 = r16 + 0
                r2 = r21[r2]
                int r4 = r16 + 1
                r4 = r21[r4]
                r0 = r17
                r0.rLineTo(r2, r4)
                int r2 = r16 + 0
                r2 = r21[r2]
                float r13 = r13 + r2
                int r2 = r16 + 1
                r2 = r21[r2]
                float r2 = r2 + r12
                r12 = r2
                goto L_0x0068
            L_0x0170:
                int r2 = r16 + 0
                r2 = r21[r2]
                r4 = 0
                r0 = r17
                r0.rLineTo(r2, r4)
                int r2 = r16 + 0
                r2 = r21[r2]
                float r13 = r13 + r2
                goto L_0x0068
            L_0x0181:
                int r1 = r16 + 0
                r2 = r21[r1]
                int r1 = r16 + 1
                r3 = r21[r1]
                int r1 = r16 + 2
                r4 = r21[r1]
                int r1 = r16 + 3
                r5 = r21[r1]
                int r1 = r16 + 4
                r6 = r21[r1]
                int r1 = r16 + 5
                r7 = r21[r1]
                r1 = r17
                r1.rCubicTo(r2, r3, r4, r5, r6, r7)
                int r1 = r16 + 2
                r1 = r21[r1]
                float r3 = r1 + r13
                int r1 = r16 + 3
                r1 = r21[r1]
                float r1 = r1 + r12
                int r2 = r16 + 4
                r2 = r21[r2]
                float r13 = r13 + r2
                int r2 = r16 + 5
                r2 = r21[r2]
                float r2 = r2 + r12
                r12 = r2
                goto L_0x0068
            L_0x01b6:
                int r1 = r16 + 5
                r1 = r21[r1]
                int r2 = r16 + 6
                r2 = r21[r2]
                int r3 = r16 + 0
                r6 = r21[r3]
                int r3 = r16 + 1
                r7 = r21[r3]
                int r3 = r16 + 2
                r8 = r21[r3]
                int r3 = r16 + 3
                r3 = r21[r3]
                r4 = 0
                int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
                if (r3 == 0) goto L_0x01fc
                r9 = 1
            L_0x01d4:
                int r3 = r16 + 4
                r3 = r21[r3]
                r4 = 0
                int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
                if (r3 == 0) goto L_0x01fe
                r10 = 1
            L_0x01de:
                float r4 = r1 + r13
                float r5 = r2 + r12
                r1 = r17
                r2 = r13
                r3 = r12
                drawArc(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10)
                int r1 = r16 + 5
                r1 = r21[r1]
                float r1 = r1 + r13
                int r2 = r16 + 6
                r2 = r21[r2]
                float r2 = r2 + r12
                r3 = r1
                r7 = r2
                r6 = r1
                r5 = r2
            L_0x01f7:
                r1 = r7
                r2 = r14
                r4 = r15
                goto L_0x002c
            L_0x01fc:
                r9 = 0
                goto L_0x01d4
            L_0x01fe:
                r10 = 0
                goto L_0x01de
            L_0x0200:
                int r2 = r16 + 0
                r2 = r21[r2]
                r0 = r17
                r0.lineTo(r13, r2)
                int r2 = r16 + 0
                r12 = r21[r2]
                r5 = r12
                r6 = r13
                r2 = r14
                r4 = r15
                goto L_0x002c
            L_0x0213:
                r2 = 113(0x71, float:1.58E-43)
                r0 = r19
                if (r0 == r2) goto L_0x022b
                r2 = 116(0x74, float:1.63E-43)
                r0 = r19
                if (r0 == r2) goto L_0x022b
                r2 = 81
                r0 = r19
                if (r0 == r2) goto L_0x022b
                r2 = 84
                r0 = r19
                if (r0 != r2) goto L_0x0235
            L_0x022b:
                r2 = 1073741824(0x40000000, float:2.0)
                float r2 = r2 * r13
                float r13 = r2 - r3
                r2 = 1073741824(0x40000000, float:2.0)
                float r2 = r2 * r12
                float r12 = r2 - r1
            L_0x0235:
                int r1 = r16 + 0
                r1 = r21[r1]
                int r2 = r16 + 1
                r2 = r21[r2]
                r0 = r17
                r0.quadTo(r13, r12, r1, r2)
                int r1 = r16 + 0
                r6 = r21[r1]
                int r1 = r16 + 1
                r5 = r21[r1]
                r1 = r12
                r2 = r14
                r3 = r13
                r4 = r15
                goto L_0x002c
            L_0x0250:
                r2 = 99
                r0 = r19
                if (r0 == r2) goto L_0x0268
                r2 = 115(0x73, float:1.61E-43)
                r0 = r19
                if (r0 == r2) goto L_0x0268
                r2 = 67
                r0 = r19
                if (r0 == r2) goto L_0x0268
                r2 = 83
                r0 = r19
                if (r0 != r2) goto L_0x029b
            L_0x0268:
                r2 = 1073741824(0x40000000, float:2.0)
                float r2 = r2 * r13
                float r2 = r2 - r3
                r3 = 1073741824(0x40000000, float:2.0)
                float r3 = r3 * r12
                float r3 = r3 - r1
            L_0x0270:
                int r1 = r16 + 0
                r4 = r21[r1]
                int r1 = r16 + 1
                r5 = r21[r1]
                int r1 = r16 + 2
                r6 = r21[r1]
                int r1 = r16 + 3
                r7 = r21[r1]
                r1 = r17
                r1.cubicTo(r2, r3, r4, r5, r6, r7)
                int r1 = r16 + 0
                r3 = r21[r1]
                int r1 = r16 + 1
                r1 = r21[r1]
                int r2 = r16 + 2
                r13 = r21[r2]
                int r2 = r16 + 3
                r12 = r21[r2]
                r5 = r12
                r6 = r13
                r2 = r14
                r4 = r15
                goto L_0x002c
            L_0x029b:
                r3 = r12
                r2 = r13
                goto L_0x0270
            L_0x029e:
                int r1 = r16 + 0
                r1 = r21[r1]
                int r2 = r16 + 1
                r2 = r21[r2]
                int r3 = r16 + 2
                r3 = r21[r3]
                int r4 = r16 + 3
                r4 = r21[r4]
                r0 = r17
                r0.quadTo(r1, r2, r3, r4)
                int r1 = r16 + 0
                r1 = r21[r1]
                int r2 = r16 + 1
                r2 = r21[r2]
                int r3 = r16 + 2
                r4 = r21[r3]
                int r3 = r16 + 3
                r5 = r21[r3]
                r3 = r1
                r7 = r2
                r6 = r4
                goto L_0x01f7
            L_0x02c8:
                int r2 = r16 + 0
                r13 = r21[r2]
                int r2 = r16 + 1
                r12 = r21[r2]
                if (r16 <= 0) goto L_0x02e5
                int r2 = r16 + 0
                r2 = r21[r2]
                int r4 = r16 + 1
                r4 = r21[r4]
                r0 = r17
                r0.lineTo(r2, r4)
                r5 = r12
                r6 = r13
                r2 = r14
                r4 = r15
                goto L_0x002c
            L_0x02e5:
                int r2 = r16 + 0
                r2 = r21[r2]
                int r4 = r16 + 1
                r4 = r21[r4]
                r0 = r17
                r0.moveTo(r2, r4)
                r5 = r12
                r6 = r13
                r2 = r12
                r4 = r13
                goto L_0x002c
            L_0x02f8:
                int r2 = r16 + 0
                r2 = r21[r2]
                int r4 = r16 + 1
                r4 = r21[r4]
                r0 = r17
                r0.lineTo(r2, r4)
                int r2 = r16 + 0
                r13 = r21[r2]
                int r2 = r16 + 1
                r12 = r21[r2]
                r5 = r12
                r6 = r13
                r2 = r14
                r4 = r15
                goto L_0x002c
            L_0x0313:
                int r2 = r16 + 0
                r2 = r21[r2]
                r0 = r17
                r0.lineTo(r2, r12)
                int r2 = r16 + 0
                r13 = r21[r2]
                r5 = r12
                r6 = r13
                r2 = r14
                r4 = r15
                goto L_0x002c
            L_0x0326:
                int r1 = r16 + 0
                r2 = r21[r1]
                int r1 = r16 + 1
                r3 = r21[r1]
                int r1 = r16 + 2
                r4 = r21[r1]
                int r1 = r16 + 3
                r5 = r21[r1]
                int r1 = r16 + 4
                r6 = r21[r1]
                int r1 = r16 + 5
                r7 = r21[r1]
                r1 = r17
                r1.cubicTo(r2, r3, r4, r5, r6, r7)
                int r1 = r16 + 4
                r4 = r21[r1]
                int r1 = r16 + 5
                r5 = r21[r1]
                int r1 = r16 + 2
                r1 = r21[r1]
                int r2 = r16 + 3
                r2 = r21[r2]
                r3 = r1
                r7 = r2
                r6 = r4
                goto L_0x01f7
            L_0x0358:
                int r1 = r16 + 5
                r4 = r21[r1]
                int r1 = r16 + 6
                r5 = r21[r1]
                int r1 = r16 + 0
                r6 = r21[r1]
                int r1 = r16 + 1
                r7 = r21[r1]
                int r1 = r16 + 2
                r8 = r21[r1]
                int r1 = r16 + 3
                r1 = r21[r1]
                r2 = 0
                int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
                if (r1 == 0) goto L_0x0395
                r9 = 1
            L_0x0376:
                int r1 = r16 + 4
                r1 = r21[r1]
                r2 = 0
                int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
                if (r1 == 0) goto L_0x0397
                r10 = 1
            L_0x0380:
                r1 = r17
                r2 = r13
                r3 = r12
                drawArc(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10)
                int r1 = r16 + 5
                r1 = r21[r1]
                int r2 = r16 + 6
                r2 = r21[r2]
                r3 = r1
                r7 = r2
                r6 = r1
                r5 = r2
                goto L_0x01f7
            L_0x0395:
                r9 = 0
                goto L_0x0376
            L_0x0397:
                r10 = 0
                goto L_0x0380
            L_0x0399:
                r2 = 0
                r18[r2] = r13
                r2 = 1
                r18[r2] = r12
                r2 = 2
                r18[r2] = r3
                r2 = 3
                r18[r2] = r1
                r1 = 4
                r18[r1] = r15
                r1 = 5
                r18[r1] = r14
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.graphics.PathParser.PathDataNode.addCommand(android.graphics.Path, float[], char, char, float[]):void");
        }

        private static void arcToBezier(Path path, double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8, double d9) {
            int ceil = (int) Math.ceil(Math.abs((4.0d * d9) / 3.141592653589793d));
            double cos = Math.cos(d7);
            double sin = Math.sin(d7);
            double cos2 = Math.cos(d8);
            double sin2 = Math.sin(d8);
            double d10 = (double) ceil;
            Double.isNaN(d10);
            double d11 = d9 / d10;
            double d12 = ((-d3) * sin * sin2) + (d4 * cos * cos2);
            double d13 = (sin2 * ((-d3) * cos)) - (cos2 * (d4 * sin));
            int i = 0;
            while (i < ceil) {
                double d14 = d8 + d11;
                double sin3 = Math.sin(d14);
                double cos3 = Math.cos(d14);
                double d15 = (((d3 * cos) * cos3) + d) - ((d4 * sin) * sin3);
                double d16 = (d3 * sin * cos3) + d2 + (d4 * cos * sin3);
                double d17 = (((-d3) * cos) * sin3) - ((d4 * sin) * cos3);
                double d18 = (cos3 * d4 * cos) + (sin3 * (-d3) * sin);
                double tan = Math.tan((d14 - d8) / 2.0d);
                double sqrt = ((Math.sqrt((tan * (3.0d * tan)) + 4.0d) - 1.0d) * Math.sin(d14 - d8)) / 3.0d;
                path.rLineTo(0.0f, 0.0f);
                path.cubicTo((float) ((sqrt * d13) + d5), (float) ((sqrt * d12) + d6), (float) (d15 - (sqrt * d17)), (float) (d16 - (sqrt * d18)), (float) d15, (float) d16);
                i++;
                d8 = d14;
                d6 = d16;
                d5 = d15;
                d13 = d17;
                d12 = d18;
            }
        }

        private static void drawArc(Path path, float f, float f2, float f3, float f4, float f5, float f6, float f7, boolean z, boolean z2) {
            double d;
            double d2;
            double radians = Math.toRadians((double) f7);
            double cos = Math.cos(radians);
            double sin = Math.sin(radians);
            double d3 = (double) f;
            Double.isNaN(d3);
            double d4 = (double) f2;
            Double.isNaN(d4);
            double d5 = (double) f5;
            Double.isNaN(d5);
            double d6 = ((d3 * cos) + (d4 * sin)) / d5;
            double d7 = (double) (-f);
            Double.isNaN(d7);
            double d8 = (double) f2;
            Double.isNaN(d8);
            double d9 = (double) f6;
            Double.isNaN(d9);
            double d10 = ((d7 * sin) + (d8 * cos)) / d9;
            double d11 = (double) f3;
            Double.isNaN(d11);
            double d12 = (double) f4;
            Double.isNaN(d12);
            double d13 = (double) f5;
            Double.isNaN(d13);
            double d14 = ((d11 * cos) + (d12 * sin)) / d13;
            double d15 = (double) (-f3);
            Double.isNaN(d15);
            double d16 = (double) f4;
            Double.isNaN(d16);
            double d17 = (double) f6;
            Double.isNaN(d17);
            double d18 = ((d15 * sin) + (d16 * cos)) / d17;
            double d19 = d6 - d14;
            double d20 = d10 - d18;
            double d21 = (d6 + d14) / 2.0d;
            double d22 = (d10 + d18) / 2.0d;
            double d23 = (d19 * d19) + (d20 * d20);
            if (d23 == 0.0d) {
                Log.w(PathParser.LOGTAG, " Points are coincident");
                return;
            }
            double d24 = (1.0d / d23) - 0.25d;
            if (d24 < 0.0d) {
                Log.w(PathParser.LOGTAG, "Points are too far apart " + d23);
                float sqrt = (float) (Math.sqrt(d23) / 1.99999d);
                drawArc(path, f, f2, f3, f4, f5 * sqrt, f6 * sqrt, f7, z, z2);
                return;
            }
            double sqrt2 = Math.sqrt(d24);
            double d25 = sqrt2 * d19;
            double d26 = sqrt2 * d20;
            if (z == z2) {
                d = d21 - d26;
                d2 = d22 + d25;
            } else {
                d = d26 + d21;
                d2 = d22 - d25;
            }
            double atan2 = Math.atan2(d10 - d2, d6 - d);
            double atan22 = Math.atan2(d18 - d2, d14 - d) - atan2;
            if (z2 != (atan22 >= 0.0d)) {
                atan22 = atan22 > 0.0d ? atan22 - 6.283185307179586d : atan22 + 6.283185307179586d;
            }
            double d27 = (double) f5;
            Double.isNaN(d27);
            double d28 = d * d27;
            double d29 = (double) f6;
            Double.isNaN(d29);
            double d30 = d29 * d2;
            arcToBezier(path, (d28 * cos) - (d30 * sin), (d30 * cos) + (d28 * sin), (double) f5, (double) f6, (double) f, (double) f2, radians, atan2, atan22);
        }

        public static void nodesToPath(PathDataNode[] pathDataNodeArr, Path path) {
            float[] fArr = new float[6];
            char c = 'm';
            for (int i = 0; i < pathDataNodeArr.length; i++) {
                addCommand(path, fArr, c, pathDataNodeArr[i].mType, pathDataNodeArr[i].mParams);
                c = pathDataNodeArr[i].mType;
            }
        }

        public void interpolatePathDataNode(PathDataNode pathDataNode, PathDataNode pathDataNode2, float f) {
            for (int i = 0; i < pathDataNode.mParams.length; i++) {
                this.mParams[i] = (pathDataNode.mParams[i] * (1.0f - f)) + (pathDataNode2.mParams[i] * f);
            }
        }
    }

    private PathParser() {
    }

    private static void addNode(ArrayList<PathDataNode> arrayList, char c, float[] fArr) {
        arrayList.add(new PathDataNode(c, fArr));
    }

    public static boolean canMorph(PathDataNode[] pathDataNodeArr, PathDataNode[] pathDataNodeArr2) {
        if (pathDataNodeArr == null || pathDataNodeArr2 == null || pathDataNodeArr.length != pathDataNodeArr2.length) {
            return false;
        }
        for (int i = 0; i < pathDataNodeArr.length; i++) {
            if (pathDataNodeArr[i].mType != pathDataNodeArr2[i].mType || pathDataNodeArr[i].mParams.length != pathDataNodeArr2[i].mParams.length) {
                return false;
            }
        }
        return true;
    }

    static float[] copyOfRange(float[] fArr, int i, int i2) {
        if (i <= i2) {
            int length = fArr.length;
            if (i < 0 || i > length) {
                throw new ArrayIndexOutOfBoundsException();
            }
            int i3 = i2 - i;
            int min = Math.min(i3, length - i);
            float[] fArr2 = new float[i3];
            System.arraycopy(fArr, i, fArr2, 0, min);
            return fArr2;
        }
        throw new IllegalArgumentException();
    }

    public static PathDataNode[] createNodesFromPathData(String str) {
        if (str == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        int i = 1;
        int i2 = 0;
        while (i < str.length()) {
            int nextStart = nextStart(str, i);
            String trim = str.substring(i2, nextStart).trim();
            if (trim.length() > 0) {
                addNode(arrayList, trim.charAt(0), getFloats(trim));
            }
            i = nextStart + 1;
            i2 = nextStart;
        }
        if (i - i2 == 1 && i2 < str.length()) {
            addNode(arrayList, str.charAt(i2), new float[0]);
        }
        return (PathDataNode[]) arrayList.toArray(new PathDataNode[arrayList.size()]);
    }

    public static Path createPathFromPathData(String str) {
        Path path = new Path();
        PathDataNode[] createNodesFromPathData = createNodesFromPathData(str);
        if (createNodesFromPathData == null) {
            return null;
        }
        try {
            PathDataNode.nodesToPath(createNodesFromPathData, path);
            return path;
        } catch (RuntimeException e) {
            throw new RuntimeException("Error in parsing " + str, e);
        }
    }

    public static PathDataNode[] deepCopyNodes(PathDataNode[] pathDataNodeArr) {
        if (pathDataNodeArr == null) {
            return null;
        }
        PathDataNode[] pathDataNodeArr2 = new PathDataNode[pathDataNodeArr.length];
        for (int i = 0; i < pathDataNodeArr.length; i++) {
            pathDataNodeArr2[i] = new PathDataNode(pathDataNodeArr[i]);
        }
        return pathDataNodeArr2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x003f A[LOOP:0: B:1:0x0008->B:22:0x003f, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0024 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void extract(java.lang.String r8, int r9, android.support.p000v4.graphics.PathParser.ExtractFloatResult r10) {
        /*
            r1 = 0
            r5 = 1
            r10.mEndWithNegOrDot = r1
            r0 = r1
            r2 = r1
            r3 = r1
            r4 = r9
        L_0x0008:
            int r6 = r8.length()
            if (r4 >= r6) goto L_0x0024
            char r6 = r8.charAt(r4)
            r7 = 32
            if (r6 == r7) goto L_0x003c
            r7 = 69
            if (r6 == r7) goto L_0x003a
            r7 = 101(0x65, float:1.42E-43)
            if (r6 == r7) goto L_0x003a
            switch(r6) {
                case 44: goto L_0x003c;
                case 45: goto L_0x0031;
                case 46: goto L_0x0027;
                default: goto L_0x0021;
            }
        L_0x0021:
            r2 = r1
        L_0x0022:
            if (r3 == 0) goto L_0x003f
        L_0x0024:
            r10.mEndPosition = r4
            return
        L_0x0027:
            if (r0 != 0) goto L_0x002c
            r0 = r5
            r2 = r1
            goto L_0x0022
        L_0x002c:
            r10.mEndWithNegOrDot = r5
            r2 = r1
            r3 = r5
            goto L_0x0022
        L_0x0031:
            if (r4 == r9) goto L_0x0042
            if (r2 != 0) goto L_0x0042
            r10.mEndWithNegOrDot = r5
            r2 = r1
            r3 = r5
            goto L_0x0022
        L_0x003a:
            r2 = r5
            goto L_0x0022
        L_0x003c:
            r2 = r1
            r3 = r5
            goto L_0x0022
        L_0x003f:
            int r4 = r4 + 1
            goto L_0x0008
        L_0x0042:
            r2 = r1
            goto L_0x0022
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.graphics.PathParser.extract(java.lang.String, int, android.support.v4.graphics.PathParser$ExtractFloatResult):void");
    }

    private static float[] getFloats(String str) {
        int i = 0;
        if (str.charAt(0) == 'z' || str.charAt(0) == 'Z') {
            return new float[0];
        }
        try {
            float[] fArr = new float[str.length()];
            int i2 = 1;
            ExtractFloatResult extractFloatResult = new ExtractFloatResult();
            int length = str.length();
            while (i2 < length) {
                extract(str, i2, extractFloatResult);
                int i3 = extractFloatResult.mEndPosition;
                if (i2 < i3) {
                    fArr[i] = Float.parseFloat(str.substring(i2, i3));
                    i++;
                }
                i2 = extractFloatResult.mEndWithNegOrDot ? i3 : i3 + 1;
            }
            return copyOfRange(fArr, 0, i);
        } catch (NumberFormatException e) {
            throw new RuntimeException("error in parsing \"" + str + "\"", e);
        }
    }

    private static int nextStart(String str, int i) {
        while (i < str.length()) {
            char charAt = str.charAt(i);
            if (((charAt - 'A') * (charAt - 'Z') <= 0 || (charAt - 'a') * (charAt - 'z') <= 0) && charAt != 'e' && charAt != 'E') {
                break;
            }
            i++;
        }
        return i;
    }

    public static void updateNodes(PathDataNode[] pathDataNodeArr, PathDataNode[] pathDataNodeArr2) {
        for (int i = 0; i < pathDataNodeArr2.length; i++) {
            pathDataNodeArr[i].mType = (char) pathDataNodeArr2[i].mType;
            for (int i2 = 0; i2 < pathDataNodeArr2[i].mParams.length; i2++) {
                pathDataNodeArr[i].mParams[i2] = pathDataNodeArr2[i].mParams[i2];
            }
        }
    }
}
