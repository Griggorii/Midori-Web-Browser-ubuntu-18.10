package android.support.p000v4.graphics;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.p000v4.content.res.FontResourcesParserCompat;
import android.util.Log;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

@RequiresApi(26)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
/* renamed from: android.support.v4.graphics.TypefaceCompatApi26Impl */
public class TypefaceCompatApi26Impl extends TypefaceCompatApi21Impl {
    private static final String ABORT_CREATION_METHOD = "abortCreation";
    private static final String ADD_FONT_FROM_ASSET_MANAGER_METHOD = "addFontFromAssetManager";
    private static final String ADD_FONT_FROM_BUFFER_METHOD = "addFontFromBuffer";
    private static final String CREATE_FROM_FAMILIES_WITH_DEFAULT_METHOD = "createFromFamiliesWithDefault";
    private static final String DEFAULT_FAMILY = "sans-serif";
    private static final String FONT_FAMILY_CLASS = "android.graphics.FontFamily";
    private static final String FREEZE_METHOD = "freeze";
    private static final int RESOLVE_BY_FONT_TABLE = -1;
    private static final String TAG = "TypefaceCompatApi26Impl";
    protected final Method mAbortCreation;
    protected final Method mAddFontFromAssetManager;
    protected final Method mAddFontFromBuffer;
    protected final Method mCreateFromFamiliesWithDefault;
    protected final Class mFontFamily;
    protected final Constructor mFontFamilyCtor;
    protected final Method mFreeze;

    public TypefaceCompatApi26Impl() {
        Class cls;
        Method method;
        Method method2;
        Method method3;
        Method method4;
        Constructor constructor;
        Method method5;
        try {
            cls = obtainFontFamily();
            constructor = obtainFontFamilyCtor(cls);
            method5 = obtainAddFontFromAssetManagerMethod(cls);
            method4 = obtainAddFontFromBufferMethod(cls);
            method3 = obtainFreezeMethod(cls);
            method2 = obtainAbortCreationMethod(cls);
            method = obtainCreateFromFamiliesWithDefaultMethod(cls);
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            Log.e(TAG, "Unable to collect necessary methods for class " + e.getClass().getName(), e);
            cls = null;
            method = null;
            method2 = null;
            method3 = null;
            method4 = null;
            constructor = null;
            method5 = null;
        }
        this.mFontFamily = cls;
        this.mFontFamilyCtor = constructor;
        this.mAddFontFromAssetManager = method5;
        this.mAddFontFromBuffer = method4;
        this.mFreeze = method3;
        this.mAbortCreation = method2;
        this.mCreateFromFamiliesWithDefault = method;
    }

    private void abortCreation(Object obj) {
        try {
            this.mAbortCreation.invoke(obj, new Object[0]);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    private boolean addFontFromAssetManager(Context context, Object obj, String str, int i, int i2, int i3, @Nullable FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.mAddFontFromAssetManager.invoke(obj, new Object[]{context.getAssets(), str, 0, false, Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3), fontVariationAxisArr})).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    private boolean addFontFromBuffer(Object obj, ByteBuffer byteBuffer, int i, int i2, int i3) {
        try {
            return ((Boolean) this.mAddFontFromBuffer.invoke(obj, new Object[]{byteBuffer, Integer.valueOf(i), null, Integer.valueOf(i2), Integer.valueOf(i3)})).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    private boolean freeze(Object obj) {
        try {
            return ((Boolean) this.mFreeze.invoke(obj, new Object[0])).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    private boolean isFontFamilyPrivateAPIAvailable() {
        if (this.mAddFontFromAssetManager == null) {
            Log.w(TAG, "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        return this.mAddFontFromAssetManager != null;
    }

    private Object newFamily() {
        try {
            return this.mFontFamilyCtor.newInstance(new Object[0]);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    /* access modifiers changed from: protected */
    public Typeface createFromFamiliesWithDefault(Object obj) {
        try {
            Object newInstance = Array.newInstance(this.mFontFamily, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) this.mCreateFromFamiliesWithDefault.invoke((Object) null, new Object[]{newInstance, -1, -1});
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public Typeface createFromFontFamilyFilesResourceEntry(Context context, FontResourcesParserCompat.FontFamilyFilesResourceEntry fontFamilyFilesResourceEntry, Resources resources, int i) {
        if (!isFontFamilyPrivateAPIAvailable()) {
            return super.createFromFontFamilyFilesResourceEntry(context, fontFamilyFilesResourceEntry, resources, i);
        }
        Object newFamily = newFamily();
        for (FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry : fontFamilyFilesResourceEntry.getEntries()) {
            if (!addFontFromAssetManager(context, newFamily, fontFileResourceEntry.getFileName(), fontFileResourceEntry.getTtcIndex(), fontFileResourceEntry.getWeight(), fontFileResourceEntry.isItalic() ? 1 : 0, FontVariationAxis.fromFontVariationSettings(fontFileResourceEntry.getVariationSettings()))) {
                abortCreation(newFamily);
                return null;
            }
        }
        if (!freeze(newFamily)) {
            return null;
        }
        return createFromFamiliesWithDefault(newFamily);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x004f, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0050, code lost:
        r1 = null;
        r2 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x005c, code lost:
        r2 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x005d, code lost:
        r1 = r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.Typeface createFromFontInfo(android.content.Context r12, @android.support.annotation.Nullable android.os.CancellationSignal r13, @android.support.annotation.NonNull android.support.p000v4.provider.FontsContractCompat.FontInfo[] r14, int r15) {
        /*
            r11 = this;
            r6 = 1
            r2 = 0
            r7 = 0
            int r0 = r14.length
            if (r0 >= r6) goto L_0x0008
            r0 = r7
        L_0x0007:
            return r0
        L_0x0008:
            boolean r0 = r11.isFontFamilyPrivateAPIAvailable()
            if (r0 != 0) goto L_0x0068
            android.support.v4.provider.FontsContractCompat$FontInfo r0 = r11.findBestInfo(r14, r15)
            android.content.ContentResolver r1 = r12.getContentResolver()
            android.net.Uri r2 = r0.getUri()     // Catch:{ IOException -> 0x004c }
            java.lang.String r3 = "r"
            android.os.ParcelFileDescriptor r3 = r1.openFileDescriptor(r2, r3, r13)     // Catch:{ IOException -> 0x004c }
            if (r3 != 0) goto L_0x0029
            if (r3 == 0) goto L_0x0027
            r3.close()     // Catch:{ IOException -> 0x004c }
        L_0x0027:
            r0 = r7
            goto L_0x0007
        L_0x0029:
            android.graphics.Typeface$Builder r1 = new android.graphics.Typeface$Builder     // Catch:{ Throwable -> 0x005a, all -> 0x004f }
            java.io.FileDescriptor r2 = r3.getFileDescriptor()     // Catch:{ Throwable -> 0x005a, all -> 0x004f }
            r1.<init>(r2)     // Catch:{ Throwable -> 0x005a, all -> 0x004f }
            int r2 = r0.getWeight()     // Catch:{ Throwable -> 0x005a, all -> 0x004f }
            android.graphics.Typeface$Builder r1 = r1.setWeight(r2)     // Catch:{ Throwable -> 0x005a, all -> 0x004f }
            boolean r0 = r0.isItalic()     // Catch:{ Throwable -> 0x005a, all -> 0x004f }
            android.graphics.Typeface$Builder r0 = r1.setItalic(r0)     // Catch:{ Throwable -> 0x005a, all -> 0x004f }
            android.graphics.Typeface r0 = r0.build()     // Catch:{ Throwable -> 0x005a, all -> 0x004f }
            if (r3 == 0) goto L_0x0007
            r3.close()     // Catch:{ IOException -> 0x004c }
            goto L_0x0007
        L_0x004c:
            r0 = move-exception
            r0 = r7
            goto L_0x0007
        L_0x004f:
            r0 = move-exception
            r1 = r7
            r2 = r0
        L_0x0052:
            if (r3 == 0) goto L_0x0059
            if (r1 == 0) goto L_0x0064
            r3.close()     // Catch:{ Throwable -> 0x005f }
        L_0x0059:
            throw r2     // Catch:{ IOException -> 0x004c }
        L_0x005a:
            r0 = move-exception
            throw r0     // Catch:{ all -> 0x005c }
        L_0x005c:
            r2 = move-exception
            r1 = r0
            goto L_0x0052
        L_0x005f:
            r0 = move-exception
            r1.addSuppressed(r0)     // Catch:{ IOException -> 0x004c }
            goto L_0x0059
        L_0x0064:
            r3.close()     // Catch:{ IOException -> 0x004c }
            goto L_0x0059
        L_0x0068:
            java.util.Map r9 = android.support.p000v4.provider.FontsContractCompat.prepareFontData(r12, r14, r13)
            java.lang.Object r1 = r11.newFamily()
            int r10 = r14.length
            r8 = r2
            r0 = r2
        L_0x0073:
            if (r8 >= r10) goto L_0x00a2
            r5 = r14[r8]
            android.net.Uri r2 = r5.getUri()
            java.lang.Object r2 = r9.get(r2)
            java.nio.ByteBuffer r2 = (java.nio.ByteBuffer) r2
            if (r2 != 0) goto L_0x0087
        L_0x0083:
            int r2 = r8 + 1
            r8 = r2
            goto L_0x0073
        L_0x0087:
            int r3 = r5.getTtcIndex()
            int r4 = r5.getWeight()
            boolean r5 = r5.isItalic()
            r0 = r11
            boolean r0 = r0.addFontFromBuffer(r1, r2, r3, r4, r5)
            if (r0 != 0) goto L_0x00a0
            r11.abortCreation(r1)
            r0 = r7
            goto L_0x0007
        L_0x00a0:
            r0 = r6
            goto L_0x0083
        L_0x00a2:
            if (r0 != 0) goto L_0x00aa
            r11.abortCreation(r1)
            r0 = r7
            goto L_0x0007
        L_0x00aa:
            boolean r0 = r11.freeze(r1)
            if (r0 != 0) goto L_0x00b3
            r0 = r7
            goto L_0x0007
        L_0x00b3:
            android.graphics.Typeface r0 = r11.createFromFamiliesWithDefault(r1)
            android.graphics.Typeface r0 = android.graphics.Typeface.create(r0, r15)
            goto L_0x0007
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.graphics.TypefaceCompatApi26Impl.createFromFontInfo(android.content.Context, android.os.CancellationSignal, android.support.v4.provider.FontsContractCompat$FontInfo[], int):android.graphics.Typeface");
    }

    @Nullable
    public Typeface createFromResourcesFontFile(Context context, Resources resources, int i, String str, int i2) {
        if (!isFontFamilyPrivateAPIAvailable()) {
            return super.createFromResourcesFontFile(context, resources, i, str, i2);
        }
        Object newFamily = newFamily();
        if (!addFontFromAssetManager(context, newFamily, str, 0, -1, -1, (FontVariationAxis[]) null)) {
            abortCreation(newFamily);
            return null;
        } else if (freeze(newFamily)) {
            return createFromFamiliesWithDefault(newFamily);
        } else {
            return null;
        }
    }

    /* access modifiers changed from: protected */
    public Method obtainAbortCreationMethod(Class cls) throws NoSuchMethodException {
        return cls.getMethod(ABORT_CREATION_METHOD, new Class[0]);
    }

    /* access modifiers changed from: protected */
    public Method obtainAddFontFromAssetManagerMethod(Class cls) throws NoSuchMethodException {
        return cls.getMethod(ADD_FONT_FROM_ASSET_MANAGER_METHOD, new Class[]{AssetManager.class, String.class, Integer.TYPE, Boolean.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, FontVariationAxis[].class});
    }

    /* access modifiers changed from: protected */
    public Method obtainAddFontFromBufferMethod(Class cls) throws NoSuchMethodException {
        return cls.getMethod(ADD_FONT_FROM_BUFFER_METHOD, new Class[]{ByteBuffer.class, Integer.TYPE, FontVariationAxis[].class, Integer.TYPE, Integer.TYPE});
    }

    /* access modifiers changed from: protected */
    public Method obtainCreateFromFamiliesWithDefaultMethod(Class cls) throws NoSuchMethodException {
        Method declaredMethod = Typeface.class.getDeclaredMethod(CREATE_FROM_FAMILIES_WITH_DEFAULT_METHOD, new Class[]{Array.newInstance(cls, 1).getClass(), Integer.TYPE, Integer.TYPE});
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }

    /* access modifiers changed from: protected */
    public Class obtainFontFamily() throws ClassNotFoundException {
        return Class.forName(FONT_FAMILY_CLASS);
    }

    /* access modifiers changed from: protected */
    public Constructor obtainFontFamilyCtor(Class cls) throws NoSuchMethodException {
        return cls.getConstructor(new Class[0]);
    }

    /* access modifiers changed from: protected */
    public Method obtainFreezeMethod(Class cls) throws NoSuchMethodException {
        return cls.getMethod(FREEZE_METHOD, new Class[0]);
    }
}
