package android.support.p000v4.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.os.Process;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
/* renamed from: android.support.v4.graphics.TypefaceCompatUtil */
public class TypefaceCompatUtil {
    private static final String CACHE_FILE_PREFIX = ".font";
    private static final String TAG = "TypefaceCompatUtil";

    private TypefaceCompatUtil() {
    }

    public static void closeQuietly(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
            }
        }
    }

    @Nullable
    @RequiresApi(19)
    public static ByteBuffer copyToDirectBuffer(Context context, Resources resources, int i) {
        ByteBuffer byteBuffer = null;
        File tempFile = getTempFile(context);
        if (tempFile != null) {
            try {
                if (copyToFile(tempFile, resources, i)) {
                    byteBuffer = mmap(tempFile);
                }
            } finally {
                tempFile.delete();
            }
        }
        return byteBuffer;
    }

    public static boolean copyToFile(File file, Resources resources, int i) {
        InputStream inputStream = null;
        try {
            inputStream = resources.openRawResource(i);
            return copyToFile(file, inputStream);
        } finally {
            closeQuietly(inputStream);
        }
    }

    public static boolean copyToFile(File file, InputStream inputStream) {
        FileOutputStream fileOutputStream;
        boolean z = false;
        StrictMode.ThreadPolicy allowThreadDiskWrites = StrictMode.allowThreadDiskWrites();
        try {
            fileOutputStream = new FileOutputStream(file, false);
            try {
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = inputStream.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    fileOutputStream.write(bArr, 0, read);
                }
                z = true;
            } catch (IOException e) {
                e = e;
                try {
                    Log.e(TAG, "Error copying resource contents to temp file: " + e.getMessage());
                    closeQuietly(fileOutputStream);
                    StrictMode.setThreadPolicy(allowThreadDiskWrites);
                    return z;
                } catch (Throwable th) {
                    th = th;
                    closeQuietly(fileOutputStream);
                    StrictMode.setThreadPolicy(allowThreadDiskWrites);
                    throw th;
                }
            }
        } catch (IOException e2) {
            e = e2;
            fileOutputStream = null;
            Log.e(TAG, "Error copying resource contents to temp file: " + e.getMessage());
            closeQuietly(fileOutputStream);
            StrictMode.setThreadPolicy(allowThreadDiskWrites);
            return z;
        } catch (Throwable th2) {
            th = th2;
            fileOutputStream = null;
            closeQuietly(fileOutputStream);
            StrictMode.setThreadPolicy(allowThreadDiskWrites);
            throw th;
        }
        closeQuietly(fileOutputStream);
        StrictMode.setThreadPolicy(allowThreadDiskWrites);
        return z;
    }

    @Nullable
    public static File getTempFile(Context context) {
        String str = CACHE_FILE_PREFIX + Process.myPid() + "-" + Process.myTid() + "-";
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= 100) {
                return null;
            }
            File file = new File(context.getCacheDir(), str + i2);
            try {
                if (file.createNewFile()) {
                    return file;
                }
                i = i2 + 1;
            } catch (IOException e) {
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0039, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x003a, code lost:
        r1 = r0;
        r2 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0044, code lost:
        r2 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0045, code lost:
        r1 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0048, code lost:
        if (r1 != null) goto L_0x004a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:?, code lost:
        r7.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x0050, code lost:
        r1 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0051, code lost:
        r2 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x0058, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x0059, code lost:
        r1 = null;
        r2 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0060, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:?, code lost:
        r1.addSuppressed(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x0065, code lost:
        r7.close();
     */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0048  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0058 A[Catch:{ all -> 0x0058, all -> 0x0044 }, ExcHandler: all (r0v3 'th' java.lang.Throwable A[CUSTOM_DECLARE, Catch:{ all -> 0x0058, all -> 0x0044 }])] */
    @android.support.annotation.Nullable
    @android.support.annotation.RequiresApi(19)
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.nio.ByteBuffer mmap(android.content.Context r9, android.os.CancellationSignal r10, android.net.Uri r11) {
        /*
            r6 = 0
            android.content.ContentResolver r0 = r9.getContentResolver()
            java.lang.String r1 = "r"
            android.os.ParcelFileDescriptor r7 = r0.openFileDescriptor(r11, r1, r10)     // Catch:{ IOException -> 0x0036 }
            if (r7 != 0) goto L_0x0014
            if (r7 == 0) goto L_0x0012
            r7.close()     // Catch:{ IOException -> 0x0036 }
        L_0x0012:
            r0 = r6
        L_0x0013:
            return r0
        L_0x0014:
            java.io.FileInputStream r8 = new java.io.FileInputStream     // Catch:{ Throwable -> 0x0042, all -> 0x0058 }
            java.io.FileDescriptor r0 = r7.getFileDescriptor()     // Catch:{ Throwable -> 0x0042, all -> 0x0058 }
            r8.<init>(r0)     // Catch:{ Throwable -> 0x0042, all -> 0x0058 }
            java.nio.channels.FileChannel r0 = r8.getChannel()     // Catch:{ Throwable -> 0x004e, all -> 0x0039 }
            long r4 = r0.size()     // Catch:{ Throwable -> 0x004e, all -> 0x0039 }
            java.nio.channels.FileChannel$MapMode r1 = java.nio.channels.FileChannel.MapMode.READ_ONLY     // Catch:{ Throwable -> 0x004e, all -> 0x0039 }
            r2 = 0
            java.nio.MappedByteBuffer r0 = r0.map(r1, r2, r4)     // Catch:{ Throwable -> 0x004e, all -> 0x0039 }
            r8.close()     // Catch:{ Throwable -> 0x0042, all -> 0x0058 }
            if (r7 == 0) goto L_0x0013
            r7.close()     // Catch:{ IOException -> 0x0036 }
            goto L_0x0013
        L_0x0036:
            r0 = move-exception
            r0 = r6
            goto L_0x0013
        L_0x0039:
            r0 = move-exception
            r1 = r0
            r2 = r6
        L_0x003c:
            if (r2 == 0) goto L_0x005c
            r8.close()     // Catch:{ Throwable -> 0x0053, all -> 0x0058 }
        L_0x0041:
            throw r1     // Catch:{ Throwable -> 0x0042, all -> 0x0058 }
        L_0x0042:
            r0 = move-exception
            throw r0     // Catch:{ all -> 0x0044 }
        L_0x0044:
            r2 = move-exception
            r1 = r0
        L_0x0046:
            if (r7 == 0) goto L_0x004d
            if (r1 == 0) goto L_0x0065
            r7.close()     // Catch:{ Throwable -> 0x0060 }
        L_0x004d:
            throw r2     // Catch:{ IOException -> 0x0036 }
        L_0x004e:
            r0 = move-exception
            throw r0     // Catch:{ all -> 0x0050 }
        L_0x0050:
            r1 = move-exception
            r2 = r0
            goto L_0x003c
        L_0x0053:
            r0 = move-exception
            r2.addSuppressed(r0)     // Catch:{ Throwable -> 0x0042, all -> 0x0058 }
            goto L_0x0041
        L_0x0058:
            r0 = move-exception
            r1 = r6
            r2 = r0
            goto L_0x0046
        L_0x005c:
            r8.close()     // Catch:{ Throwable -> 0x0042, all -> 0x0058 }
            goto L_0x0041
        L_0x0060:
            r0 = move-exception
            r1.addSuppressed(r0)     // Catch:{ IOException -> 0x0036 }
            goto L_0x004d
        L_0x0065:
            r7.close()     // Catch:{ IOException -> 0x0036 }
            goto L_0x004d
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.graphics.TypefaceCompatUtil.mmap(android.content.Context, android.os.CancellationSignal, android.net.Uri):java.nio.ByteBuffer");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0028, code lost:
        r1 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0029, code lost:
        r2 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x001a, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x001b, code lost:
        r1 = r0;
        r2 = null;
     */
    @android.support.annotation.Nullable
    @android.support.annotation.RequiresApi(19)
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.nio.ByteBuffer mmap(java.io.File r8) {
        /*
            r6 = 0
            java.io.FileInputStream r7 = new java.io.FileInputStream     // Catch:{ IOException -> 0x0023 }
            r7.<init>(r8)     // Catch:{ IOException -> 0x0023 }
            java.nio.channels.FileChannel r0 = r7.getChannel()     // Catch:{ Throwable -> 0x0026, all -> 0x001a }
            long r4 = r0.size()     // Catch:{ Throwable -> 0x0026, all -> 0x001a }
            java.nio.channels.FileChannel$MapMode r1 = java.nio.channels.FileChannel.MapMode.READ_ONLY     // Catch:{ Throwable -> 0x0026, all -> 0x001a }
            r2 = 0
            java.nio.MappedByteBuffer r0 = r0.map(r1, r2, r4)     // Catch:{ Throwable -> 0x0026, all -> 0x001a }
            r7.close()     // Catch:{ IOException -> 0x0023 }
        L_0x0019:
            return r0
        L_0x001a:
            r0 = move-exception
            r1 = r0
            r2 = r6
        L_0x001d:
            if (r2 == 0) goto L_0x0030
            r7.close()     // Catch:{ Throwable -> 0x002b }
        L_0x0022:
            throw r1     // Catch:{ IOException -> 0x0023 }
        L_0x0023:
            r0 = move-exception
            r0 = r6
            goto L_0x0019
        L_0x0026:
            r0 = move-exception
            throw r0     // Catch:{ all -> 0x0028 }
        L_0x0028:
            r1 = move-exception
            r2 = r0
            goto L_0x001d
        L_0x002b:
            r0 = move-exception
            r2.addSuppressed(r0)     // Catch:{ IOException -> 0x0023 }
            goto L_0x0022
        L_0x0030:
            r7.close()     // Catch:{ IOException -> 0x0023 }
            goto L_0x0022
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.graphics.TypefaceCompatUtil.mmap(java.io.File):java.nio.ByteBuffer");
    }
}
