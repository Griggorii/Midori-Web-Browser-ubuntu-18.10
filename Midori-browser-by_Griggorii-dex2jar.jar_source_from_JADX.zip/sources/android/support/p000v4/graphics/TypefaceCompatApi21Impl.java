package android.support.p000v4.graphics;

import android.os.ParcelFileDescriptor;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.File;

@RequiresApi(21)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
/* renamed from: android.support.v4.graphics.TypefaceCompatApi21Impl */
class TypefaceCompatApi21Impl extends TypefaceCompatBaseImpl {
    private static final String TAG = "TypefaceCompatApi21Impl";

    TypefaceCompatApi21Impl() {
    }

    private File getFile(ParcelFileDescriptor parcelFileDescriptor) {
        try {
            String readlink = Os.readlink("/proc/self/fd/" + parcelFileDescriptor.getFd());
            if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                return new File(readlink);
            }
            return null;
        } catch (ErrnoException e) {
            return null;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0046, code lost:
        r1 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0047, code lost:
        r2 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0050, code lost:
        r2 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0051, code lost:
        r3 = r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x0054, code lost:
        if (r3 != null) goto L_0x0056;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:?, code lost:
        r4.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x005e, code lost:
        r1 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x0065, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x0066, code lost:
        r2 = r1;
        r3 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x006d, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:?, code lost:
        r3.addSuppressed(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x0072, code lost:
        r4.close();
     */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0065 A[Catch:{ all -> 0x0065, all -> 0x0050 }, ExcHandler: all (r1v4 'th' java.lang.Throwable A[CUSTOM_DECLARE, Catch:{ all -> 0x0065, all -> 0x0050 }])] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.Typeface createFromFontInfo(android.content.Context r6, android.os.CancellationSignal r7, @android.support.annotation.NonNull android.support.p000v4.provider.FontsContractCompat.FontInfo[] r8, int r9) {
        /*
            r5 = this;
            r0 = 0
            int r1 = r8.length
            r2 = 1
            if (r1 >= r2) goto L_0x0006
        L_0x0005:
            return r0
        L_0x0006:
            android.support.v4.provider.FontsContractCompat$FontInfo r1 = r5.findBestInfo(r8, r9)
            android.content.ContentResolver r2 = r6.getContentResolver()
            android.net.Uri r1 = r1.getUri()     // Catch:{ IOException -> 0x005a }
            java.lang.String r3 = "r"
            android.os.ParcelFileDescriptor r4 = r2.openFileDescriptor(r1, r3, r7)     // Catch:{ IOException -> 0x005a }
            java.io.File r1 = r5.getFile(r4)     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            if (r1 == 0) goto L_0x0024
            boolean r2 = r1.canRead()     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            if (r2 != 0) goto L_0x003b
        L_0x0024:
            java.io.FileInputStream r3 = new java.io.FileInputStream     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            java.io.FileDescriptor r1 = r4.getFileDescriptor()     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            r3.<init>(r1)     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            android.graphics.Typeface r1 = super.createFromInputStream(r6, r3)     // Catch:{ Throwable -> 0x005c, all -> 0x0046 }
            r3.close()     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            if (r4 == 0) goto L_0x0039
            r4.close()     // Catch:{ IOException -> 0x005a }
        L_0x0039:
            r0 = r1
            goto L_0x0005
        L_0x003b:
            android.graphics.Typeface r1 = android.graphics.Typeface.createFromFile(r1)     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            if (r4 == 0) goto L_0x0044
            r4.close()     // Catch:{ IOException -> 0x005a }
        L_0x0044:
            r0 = r1
            goto L_0x0005
        L_0x0046:
            r1 = move-exception
            r2 = r0
        L_0x0048:
            if (r2 == 0) goto L_0x0069
            r3.close()     // Catch:{ Throwable -> 0x0060, all -> 0x0065 }
        L_0x004d:
            throw r1     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
        L_0x004e:
            r1 = move-exception
            throw r1     // Catch:{ all -> 0x0050 }
        L_0x0050:
            r2 = move-exception
            r3 = r1
        L_0x0052:
            if (r4 == 0) goto L_0x0059
            if (r3 == 0) goto L_0x0072
            r4.close()     // Catch:{ Throwable -> 0x006d }
        L_0x0059:
            throw r2     // Catch:{ IOException -> 0x005a }
        L_0x005a:
            r1 = move-exception
            goto L_0x0005
        L_0x005c:
            r2 = move-exception
            throw r2     // Catch:{ all -> 0x005e }
        L_0x005e:
            r1 = move-exception
            goto L_0x0048
        L_0x0060:
            r3 = move-exception
            r2.addSuppressed(r3)     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            goto L_0x004d
        L_0x0065:
            r1 = move-exception
            r2 = r1
            r3 = r0
            goto L_0x0052
        L_0x0069:
            r3.close()     // Catch:{ Throwable -> 0x004e, all -> 0x0065 }
            goto L_0x004d
        L_0x006d:
            r1 = move-exception
            r3.addSuppressed(r1)     // Catch:{ IOException -> 0x005a }
            goto L_0x0059
        L_0x0072:
            r4.close()     // Catch:{ IOException -> 0x005a }
            goto L_0x0059
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.graphics.TypefaceCompatApi21Impl.createFromFontInfo(android.content.Context, android.os.CancellationSignal, android.support.v4.provider.FontsContractCompat$FontInfo[], int):android.graphics.Typeface");
    }
}
