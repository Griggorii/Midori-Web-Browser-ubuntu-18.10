package android.support.design.shape;

import android.support.design.internal.Experimental;

@Experimental("The shapes API is currently experimental and subject to change")
public class CutCornerTreatment extends CornerTreatment {
    private final float size;

    public CutCornerTreatment(float f) {
        this.size = f;
    }

    public void getCornerPath(float f, float f2, ShapePath shapePath) {
        shapePath.reset(0.0f, this.size * f2);
        double sin = Math.sin((double) f);
        double d = (double) this.size;
        Double.isNaN(d);
        double d2 = (double) f2;
        Double.isNaN(d2);
        double cos = Math.cos((double) f);
        double d3 = (double) this.size;
        Double.isNaN(d3);
        double d4 = (double) f2;
        Double.isNaN(d4);
        shapePath.lineTo((float) (sin * d * d2), (float) (cos * d3 * d4));
    }
}
