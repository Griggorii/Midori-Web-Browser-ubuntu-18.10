package android.support.design.transformation;

import android.content.Context;
import android.support.annotation.CallSuper;
import android.support.annotation.Nullable;
import android.support.design.expandable.ExpandableWidget;
import android.support.design.widget.CoordinatorLayout;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;

public abstract class ExpandableBehavior extends CoordinatorLayout.Behavior<View> {
    private static final int STATE_COLLAPSED = 2;
    private static final int STATE_EXPANDED = 1;
    private static final int STATE_UNINITIALIZED = 0;
    /* access modifiers changed from: private */
    public int currentState = 0;

    public ExpandableBehavior() {
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    private boolean didStateChange(boolean z) {
        boolean z2 = true;
        if (z) {
            return this.currentState == 0 || this.currentState == 2;
        }
        if (this.currentState != 1) {
            z2 = false;
        }
        return z2;
    }

    public static <T extends ExpandableBehavior> T from(View view, Class<T> cls) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof CoordinatorLayout.LayoutParams) {
            CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams) layoutParams).getBehavior();
            if (behavior instanceof ExpandableBehavior) {
                return (ExpandableBehavior) cls.cast(behavior);
            }
            throw new IllegalArgumentException("The view is not associated with ExpandableBehavior");
        }
        throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
    }

    /* access modifiers changed from: protected */
    @Nullable
    public ExpandableWidget findExpandableWidget(CoordinatorLayout coordinatorLayout, View view) {
        List<View> dependencies = coordinatorLayout.getDependencies(view);
        int size = dependencies.size();
        for (int i = 0; i < size; i++) {
            View view2 = dependencies.get(i);
            if (layoutDependsOn(coordinatorLayout, view, view2)) {
                return (ExpandableWidget) view2;
            }
        }
        return null;
    }

    public abstract boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, View view, View view2);

    @CallSuper
    public boolean onDependentViewChanged(CoordinatorLayout coordinatorLayout, View view, View view2) {
        ExpandableWidget expandableWidget = (ExpandableWidget) view2;
        if (!didStateChange(expandableWidget.isExpanded())) {
            return false;
        }
        this.currentState = expandableWidget.isExpanded() ? 1 : 2;
        return onExpandedStateChange((View) expandableWidget, view, expandableWidget.isExpanded(), true);
    }

    /* access modifiers changed from: protected */
    public abstract boolean onExpandedStateChange(View view, View view2, boolean z, boolean z2);

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r1 = findExpandableWidget(r5, r6);
     */
    @android.support.annotation.CallSuper
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onLayoutChild(android.support.design.widget.CoordinatorLayout r5, final android.view.View r6, int r7) {
        /*
            r4 = this;
            boolean r0 = android.support.p000v4.view.ViewCompat.isLaidOut(r6)
            if (r0 != 0) goto L_0x002d
            android.support.design.expandable.ExpandableWidget r1 = r4.findExpandableWidget(r5, r6)
            if (r1 == 0) goto L_0x002d
            boolean r0 = r1.isExpanded()
            boolean r0 = r4.didStateChange(r0)
            if (r0 == 0) goto L_0x002d
            boolean r0 = r1.isExpanded()
            if (r0 == 0) goto L_0x002f
            r0 = 1
        L_0x001d:
            r4.currentState = r0
            int r0 = r4.currentState
            android.view.ViewTreeObserver r2 = r6.getViewTreeObserver()
            android.support.design.transformation.ExpandableBehavior$1 r3 = new android.support.design.transformation.ExpandableBehavior$1
            r3.<init>(r6, r0, r1)
            r2.addOnPreDrawListener(r3)
        L_0x002d:
            r0 = 0
            return r0
        L_0x002f:
            r0 = 2
            goto L_0x001d
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.design.transformation.ExpandableBehavior.onLayoutChild(android.support.design.widget.CoordinatorLayout, android.view.View, int):boolean");
    }
}
