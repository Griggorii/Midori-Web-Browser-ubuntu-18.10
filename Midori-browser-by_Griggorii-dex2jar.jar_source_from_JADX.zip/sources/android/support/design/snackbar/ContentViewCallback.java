package android.support.design.snackbar;

public interface ContentViewCallback {
    void animateContentIn(int i, int i2);

    void animateContentOut(int i, int i2);
}
