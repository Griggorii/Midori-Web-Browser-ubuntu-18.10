package android.support.design.expandable;

public interface ExpandableWidget {
    boolean isExpanded();

    boolean setExpanded(boolean z);
}
