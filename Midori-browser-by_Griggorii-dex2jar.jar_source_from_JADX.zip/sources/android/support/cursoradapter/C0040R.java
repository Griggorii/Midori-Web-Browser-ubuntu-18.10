package android.support.cursoradapter;

/* renamed from: android.support.cursoradapter.R */
public final class C0040R {
    private C0040R() {
    }
}
