package android.support.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build;
import android.support.annotation.AnimatorRes;
import android.support.annotation.RestrictTo;
import android.support.p000v4.content.res.TypedArrayUtils;
import android.support.p000v4.graphics.PathParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.InflateException;
import java.io.IOException;
import java.util.ArrayList;
import org.midori_browser.midori.BuildConfig;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class AnimatorInflaterCompat {
    private static final boolean DBG_ANIMATOR_INFLATER = false;
    private static final int MAX_NUM_POINTS = 100;
    private static final String TAG = "AnimatorInflater";
    private static final int TOGETHER = 0;
    private static final int VALUE_TYPE_COLOR = 3;
    private static final int VALUE_TYPE_FLOAT = 0;
    private static final int VALUE_TYPE_INT = 1;
    private static final int VALUE_TYPE_PATH = 2;
    private static final int VALUE_TYPE_UNDEFINED = 4;

    private static class PathDataEvaluator implements TypeEvaluator<PathParser.PathDataNode[]> {
        private PathParser.PathDataNode[] mNodeArray;

        PathDataEvaluator() {
        }

        PathDataEvaluator(PathParser.PathDataNode[] pathDataNodeArr) {
            this.mNodeArray = pathDataNodeArr;
        }

        public PathParser.PathDataNode[] evaluate(float f, PathParser.PathDataNode[] pathDataNodeArr, PathParser.PathDataNode[] pathDataNodeArr2) {
            if (PathParser.canMorph(pathDataNodeArr, pathDataNodeArr2)) {
                if (this.mNodeArray == null || !PathParser.canMorph(this.mNodeArray, pathDataNodeArr)) {
                    this.mNodeArray = PathParser.deepCopyNodes(pathDataNodeArr);
                }
                for (int i = 0; i < pathDataNodeArr.length; i++) {
                    this.mNodeArray[i].interpolatePathDataNode(pathDataNodeArr[i], pathDataNodeArr2[i], f);
                }
                return this.mNodeArray;
            }
            throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
        }
    }

    private AnimatorInflaterCompat() {
    }

    private static Animator createAnimatorFromXml(Context context, Resources resources, Resources.Theme theme, XmlPullParser xmlPullParser, float f) throws XmlPullParserException, IOException {
        return createAnimatorFromXml(context, resources, theme, xmlPullParser, Xml.asAttributeSet(xmlPullParser), (AnimatorSet) null, 0, f);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0041  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static android.animation.Animator createAnimatorFromXml(android.content.Context r17, android.content.res.Resources r18, android.content.res.Resources.Theme r19, org.xmlpull.v1.XmlPullParser r20, android.util.AttributeSet r21, android.animation.AnimatorSet r22, int r23, float r24) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            int r15 = r20.getDepth()
            r5 = 0
            r13 = 0
        L_0x0006:
            int r4 = r20.next()
            r6 = 3
            if (r4 != r6) goto L_0x0013
            int r6 = r20.getDepth()
            if (r6 <= r15) goto L_0x00e6
        L_0x0013:
            r6 = 1
            if (r4 == r6) goto L_0x00e6
            r6 = 2
            if (r4 == r6) goto L_0x001c
        L_0x0019:
            r4 = r13
            r13 = r4
            goto L_0x0006
        L_0x001c:
            java.lang.String r4 = r20.getName()
            r14 = 0
            java.lang.String r6 = "objectAnimator"
            boolean r6 = r4.equals(r6)
            if (r6 == 0) goto L_0x004a
            r4 = r17
            r5 = r18
            r6 = r19
            r7 = r21
            r8 = r24
            r9 = r20
            android.animation.ObjectAnimator r4 = loadObjectAnimator(r4, r5, r6, r7, r8, r9)
        L_0x0039:
            r6 = r14
            r5 = r4
        L_0x003b:
            if (r22 == 0) goto L_0x0019
            if (r6 != 0) goto L_0x0019
            if (r13 != 0) goto L_0x0046
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
        L_0x0046:
            r13.add(r5)
            goto L_0x0019
        L_0x004a:
            java.lang.String r6 = "animator"
            boolean r6 = r4.equals(r6)
            if (r6 == 0) goto L_0x0064
            r8 = 0
            r4 = r17
            r5 = r18
            r6 = r19
            r7 = r21
            r9 = r24
            r10 = r20
            android.animation.ValueAnimator r4 = loadAnimator(r4, r5, r6, r7, r8, r9, r10)
            goto L_0x0039
        L_0x0064:
            java.lang.String r6 = "set"
            boolean r6 = r4.equals(r6)
            if (r6 == 0) goto L_0x00a1
            android.animation.AnimatorSet r12 = new android.animation.AnimatorSet
            r12.<init>()
            int[] r4 = android.support.graphics.drawable.AndroidResources.STYLEABLE_ANIMATOR_SET
            r0 = r18
            r1 = r19
            r2 = r21
            android.content.res.TypedArray r16 = android.support.p000v4.content.res.TypedArrayUtils.obtainAttributes(r0, r1, r2, r4)
            java.lang.String r4 = "ordering"
            r5 = 0
            r6 = 0
            r0 = r16
            r1 = r20
            int r10 = android.support.p000v4.content.res.TypedArrayUtils.getNamedInt(r0, r1, r4, r5, r6)
            r9 = r12
            android.animation.AnimatorSet r9 = (android.animation.AnimatorSet) r9
            r4 = r17
            r5 = r18
            r6 = r19
            r7 = r20
            r8 = r21
            r11 = r24
            createAnimatorFromXml(r4, r5, r6, r7, r8, r9, r10, r11)
            r16.recycle()
            r6 = r14
            r5 = r12
            goto L_0x003b
        L_0x00a1:
            java.lang.String r6 = "propertyValuesHolder"
            boolean r4 = r4.equals(r6)
            if (r4 == 0) goto L_0x00cb
            android.util.AttributeSet r4 = android.util.Xml.asAttributeSet(r20)
            r0 = r17
            r1 = r18
            r2 = r19
            r3 = r20
            android.animation.PropertyValuesHolder[] r6 = loadValues(r0, r1, r2, r3, r4)
            if (r6 == 0) goto L_0x00c7
            if (r5 == 0) goto L_0x00c7
            boolean r4 = r5 instanceof android.animation.ValueAnimator
            if (r4 == 0) goto L_0x00c7
            r4 = r5
            android.animation.ValueAnimator r4 = (android.animation.ValueAnimator) r4
            r4.setValues(r6)
        L_0x00c7:
            r4 = 1
            r6 = r4
            goto L_0x003b
        L_0x00cb:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "Unknown animator name: "
            r4.append(r5)
            java.lang.String r5 = r20.getName()
            r4.append(r5)
            java.lang.RuntimeException r5 = new java.lang.RuntimeException
            java.lang.String r4 = r4.toString()
            r5.<init>(r4)
            throw r5
        L_0x00e6:
            if (r22 == 0) goto L_0x010f
            if (r13 == 0) goto L_0x010f
            int r4 = r13.size()
            android.animation.Animator[] r7 = new android.animation.Animator[r4]
            r4 = 0
            java.util.Iterator r8 = r13.iterator()
            r6 = r4
        L_0x00f6:
            boolean r4 = r8.hasNext()
            if (r4 == 0) goto L_0x0108
            java.lang.Object r4 = r8.next()
            android.animation.Animator r4 = (android.animation.Animator) r4
            r7[r6] = r4
            int r4 = r6 + 1
            r6 = r4
            goto L_0x00f6
        L_0x0108:
            if (r23 != 0) goto L_0x0110
            r0 = r22
            r0.playTogether(r7)
        L_0x010f:
            return r5
        L_0x0110:
            r0 = r22
            r0.playSequentially(r7)
            goto L_0x010f
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.graphics.drawable.AnimatorInflaterCompat.createAnimatorFromXml(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.animation.AnimatorSet, int, float):android.animation.Animator");
    }

    private static Keyframe createNewKeyframe(Keyframe keyframe, float f) {
        return keyframe.getType() == Float.TYPE ? Keyframe.ofFloat(f) : keyframe.getType() == Integer.TYPE ? Keyframe.ofInt(f) : Keyframe.ofObject(f);
    }

    private static void distributeKeyframes(Keyframe[] keyframeArr, float f, int i, int i2) {
        float f2 = f / ((float) ((i2 - i) + 2));
        while (i <= i2) {
            keyframeArr[i].setFraction(keyframeArr[i - 1].getFraction() + f2);
            i++;
        }
    }

    private static void dumpKeyframes(Object[] objArr, String str) {
        if (objArr != null && objArr.length != 0) {
            Log.d(TAG, str);
            int length = objArr.length;
            for (int i = 0; i < length; i++) {
                Keyframe keyframe = objArr[i];
                StringBuilder sb = new StringBuilder();
                sb.append("Keyframe ");
                sb.append(i);
                sb.append(": fraction ");
                sb.append(keyframe.getFraction() < 0.0f ? "null" : Float.valueOf(keyframe.getFraction()));
                sb.append(", ");
                sb.append(", value : ");
                sb.append(keyframe.hasValue() ? keyframe.getValue() : "null");
                Log.d(TAG, sb.toString());
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v25, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v64, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v69, resolved type: java.lang.Object[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static android.animation.PropertyValuesHolder getPVH(android.content.res.TypedArray r7, int r8, int r9, int r10, java.lang.String r11) {
        /*
            android.util.TypedValue r1 = r7.peekValue(r9)
            if (r1 == 0) goto L_0x0065
            r0 = 1
            r6 = r0
        L_0x0008:
            if (r6 == 0) goto L_0x0068
            int r0 = r1.type
        L_0x000c:
            android.util.TypedValue r2 = r7.peekValue(r10)
            if (r2 == 0) goto L_0x006a
            r1 = 1
            r5 = r1
        L_0x0014:
            if (r5 == 0) goto L_0x006d
            int r1 = r2.type
            r4 = r1
        L_0x0019:
            r1 = 4
            if (r8 != r1) goto L_0x002d
            if (r6 == 0) goto L_0x0024
            boolean r1 = isColorType(r0)
            if (r1 != 0) goto L_0x002c
        L_0x0024:
            if (r5 == 0) goto L_0x0070
            boolean r1 = isColorType(r4)
            if (r1 == 0) goto L_0x0070
        L_0x002c:
            r8 = 3
        L_0x002d:
            if (r8 != 0) goto L_0x0072
            r1 = 1
            r3 = r1
        L_0x0031:
            r1 = 2
            if (r8 != r1) goto L_0x00b3
            java.lang.String r0 = r7.getString(r9)
            java.lang.String r1 = r7.getString(r10)
            android.support.v4.graphics.PathParser$PathDataNode[] r2 = android.support.p000v4.graphics.PathParser.createNodesFromPathData(r0)
            android.support.v4.graphics.PathParser$PathDataNode[] r3 = android.support.p000v4.graphics.PathParser.createNodesFromPathData(r1)
            if (r2 != 0) goto L_0x0048
            if (r3 == 0) goto L_0x00b1
        L_0x0048:
            if (r2 == 0) goto L_0x009f
            android.support.graphics.drawable.AnimatorInflaterCompat$PathDataEvaluator r4 = new android.support.graphics.drawable.AnimatorInflaterCompat$PathDataEvaluator
            r4.<init>()
            if (r3 == 0) goto L_0x0094
            boolean r5 = android.support.p000v4.graphics.PathParser.canMorph(r2, r3)
            if (r5 == 0) goto L_0x0075
            r0 = 2
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r1 = 0
            r0[r1] = r2
            r1 = 1
            r0[r1] = r3
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofObject(r11, r4, r0)
        L_0x0064:
            return r0
        L_0x0065:
            r0 = 0
            r6 = r0
            goto L_0x0008
        L_0x0068:
            r0 = 0
            goto L_0x000c
        L_0x006a:
            r1 = 0
            r5 = r1
            goto L_0x0014
        L_0x006d:
            r1 = 0
            r4 = r1
            goto L_0x0019
        L_0x0070:
            r8 = 0
            goto L_0x002d
        L_0x0072:
            r1 = 0
            r3 = r1
            goto L_0x0031
        L_0x0075:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = " Can't morph from "
            r2.append(r3)
            r2.append(r0)
            java.lang.String r0 = " to "
            r2.append(r0)
            r2.append(r1)
            android.view.InflateException r0 = new android.view.InflateException
            java.lang.String r1 = r2.toString()
            r0.<init>(r1)
            throw r0
        L_0x0094:
            r0 = 1
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r1 = 0
            r0[r1] = r2
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofObject(r11, r4, r0)
            goto L_0x0064
        L_0x009f:
            if (r3 == 0) goto L_0x00b1
            android.support.graphics.drawable.AnimatorInflaterCompat$PathDataEvaluator r0 = new android.support.graphics.drawable.AnimatorInflaterCompat$PathDataEvaluator
            r0.<init>()
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = 0
            r1[r2] = r3
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofObject(r11, r0, r1)
            goto L_0x0064
        L_0x00b1:
            r0 = 0
            goto L_0x0064
        L_0x00b3:
            r1 = 0
            r2 = 3
            if (r8 != r2) goto L_0x019d
            android.support.graphics.drawable.ArgbEvaluator r1 = android.support.graphics.drawable.ArgbEvaluator.getInstance()
            r2 = r1
        L_0x00bc:
            if (r3 == 0) goto L_0x011a
            if (r6 == 0) goto L_0x0101
            r1 = 5
            if (r0 != r1) goto L_0x00e9
            r0 = 0
            float r0 = r7.getDimension(r9, r0)
            r1 = r0
        L_0x00c9:
            if (r5 == 0) goto L_0x00f6
            r0 = 5
            if (r4 != r0) goto L_0x00f0
            r0 = 0
            float r0 = r7.getDimension(r10, r0)
        L_0x00d3:
            r3 = 2
            float[] r3 = new float[r3]
            r4 = 0
            r3[r4] = r1
            r1 = 1
            r3[r1] = r0
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofFloat(r11, r3)
        L_0x00e0:
            if (r0 == 0) goto L_0x0064
            if (r2 == 0) goto L_0x0064
            r0.setEvaluator(r2)
            goto L_0x0064
        L_0x00e9:
            r0 = 0
            float r0 = r7.getFloat(r9, r0)
            r1 = r0
            goto L_0x00c9
        L_0x00f0:
            r0 = 0
            float r0 = r7.getFloat(r10, r0)
            goto L_0x00d3
        L_0x00f6:
            r0 = 1
            float[] r0 = new float[r0]
            r3 = 0
            r0[r3] = r1
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofFloat(r11, r0)
            goto L_0x00e0
        L_0x0101:
            r0 = 5
            if (r4 != r0) goto L_0x0114
            r0 = 0
            float r0 = r7.getDimension(r10, r0)
        L_0x0109:
            r1 = 1
            float[] r1 = new float[r1]
            r3 = 0
            r1[r3] = r0
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofFloat(r11, r1)
            goto L_0x00e0
        L_0x0114:
            r0 = 0
            float r0 = r7.getFloat(r10, r0)
            goto L_0x0109
        L_0x011a:
            if (r6 == 0) goto L_0x0171
            r1 = 5
            if (r0 != r1) goto L_0x013f
            r0 = 0
            float r0 = r7.getDimension(r9, r0)
            int r0 = (int) r0
            r1 = r0
        L_0x0126:
            if (r5 == 0) goto L_0x0165
            r0 = 5
            if (r4 != r0) goto L_0x0153
            r0 = 0
            float r0 = r7.getDimension(r10, r0)
            int r0 = (int) r0
        L_0x0131:
            r3 = 2
            int[] r3 = new int[r3]
            r4 = 0
            r3[r4] = r1
            r1 = 1
            r3[r1] = r0
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofInt(r11, r3)
            goto L_0x00e0
        L_0x013f:
            boolean r0 = isColorType(r0)
            if (r0 == 0) goto L_0x014c
            r0 = 0
            int r0 = r7.getColor(r9, r0)
            r1 = r0
            goto L_0x0126
        L_0x014c:
            r0 = 0
            int r0 = r7.getInt(r9, r0)
            r1 = r0
            goto L_0x0126
        L_0x0153:
            boolean r0 = isColorType(r4)
            if (r0 == 0) goto L_0x015f
            r0 = 0
            int r0 = r7.getColor(r10, r0)
            goto L_0x0131
        L_0x015f:
            r0 = 0
            int r0 = r7.getInt(r10, r0)
            goto L_0x0131
        L_0x0165:
            r0 = 1
            int[] r0 = new int[r0]
            r3 = 0
            r0[r3] = r1
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofInt(r11, r0)
            goto L_0x00e0
        L_0x0171:
            if (r5 == 0) goto L_0x019a
            r0 = 5
            if (r4 != r0) goto L_0x0188
            r0 = 0
            float r0 = r7.getDimension(r10, r0)
            int r0 = (int) r0
        L_0x017c:
            r1 = 1
            int[] r1 = new int[r1]
            r3 = 0
            r1[r3] = r0
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofInt(r11, r1)
            goto L_0x00e0
        L_0x0188:
            boolean r0 = isColorType(r4)
            if (r0 == 0) goto L_0x0194
            r0 = 0
            int r0 = r7.getColor(r10, r0)
            goto L_0x017c
        L_0x0194:
            r0 = 0
            int r0 = r7.getInt(r10, r0)
            goto L_0x017c
        L_0x019a:
            r0 = 0
            goto L_0x00e0
        L_0x019d:
            r2 = r1
            goto L_0x00bc
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.graphics.drawable.AnimatorInflaterCompat.getPVH(android.content.res.TypedArray, int, int, int, java.lang.String):android.animation.PropertyValuesHolder");
    }

    private static int inferValueTypeFromValues(TypedArray typedArray, int i, int i2) {
        TypedValue peekValue = typedArray.peekValue(i);
        boolean z = peekValue != null;
        int i3 = z ? peekValue.type : 0;
        TypedValue peekValue2 = typedArray.peekValue(i2);
        boolean z2 = peekValue2 != null;
        return ((!z || !isColorType(i3)) && (!z2 || !isColorType(z2 ? peekValue2.type : 0))) ? 0 : 3;
    }

    private static int inferValueTypeOfKeyframe(Resources resources, Resources.Theme theme, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        int i = 0;
        TypedArray obtainAttributes = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_KEYFRAME);
        TypedValue peekNamedValue = TypedArrayUtils.peekNamedValue(obtainAttributes, xmlPullParser, "value", 0);
        if ((peekNamedValue != null) && isColorType(peekNamedValue.type)) {
            i = 3;
        }
        obtainAttributes.recycle();
        return i;
    }

    private static boolean isColorType(int i) {
        return i >= 28 && i <= 31;
    }

    public static Animator loadAnimator(Context context, @AnimatorRes int i) throws Resources.NotFoundException {
        return Build.VERSION.SDK_INT >= 24 ? AnimatorInflater.loadAnimator(context, i) : loadAnimator(context, context.getResources(), context.getTheme(), i);
    }

    public static Animator loadAnimator(Context context, Resources resources, Resources.Theme theme, @AnimatorRes int i) throws Resources.NotFoundException {
        return loadAnimator(context, resources, theme, i, 1.0f);
    }

    public static Animator loadAnimator(Context context, Resources resources, Resources.Theme theme, @AnimatorRes int i, float f) throws Resources.NotFoundException {
        XmlResourceParser xmlResourceParser = null;
        try {
            xmlResourceParser = resources.getAnimation(i);
            Animator createAnimatorFromXml = createAnimatorFromXml(context, resources, theme, xmlResourceParser, f);
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
            return createAnimatorFromXml;
        } catch (XmlPullParserException e) {
            Resources.NotFoundException notFoundException = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(i));
            notFoundException.initCause(e);
            throw notFoundException;
        } catch (IOException e2) {
            Resources.NotFoundException notFoundException2 = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(i));
            notFoundException2.initCause(e2);
            throw notFoundException2;
        } catch (Throwable th) {
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
            throw th;
        }
    }

    private static ValueAnimator loadAnimator(Context context, Resources resources, Resources.Theme theme, AttributeSet attributeSet, ValueAnimator valueAnimator, float f, XmlPullParser xmlPullParser) throws Resources.NotFoundException {
        TypedArray obtainAttributes = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_ANIMATOR);
        TypedArray obtainAttributes2 = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_PROPERTY_ANIMATOR);
        if (valueAnimator == null) {
            valueAnimator = new ValueAnimator();
        }
        parseAnimatorFromTypeArray(valueAnimator, obtainAttributes, obtainAttributes2, f, xmlPullParser);
        int namedResourceId = TypedArrayUtils.getNamedResourceId(obtainAttributes, xmlPullParser, "interpolator", 0, 0);
        if (namedResourceId > 0) {
            valueAnimator.setInterpolator(AnimationUtilsCompat.loadInterpolator(context, namedResourceId));
        }
        obtainAttributes.recycle();
        if (obtainAttributes2 != null) {
            obtainAttributes2.recycle();
        }
        return valueAnimator;
    }

    private static Keyframe loadKeyframe(Context context, Resources resources, Resources.Theme theme, AttributeSet attributeSet, int i, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        TypedArray obtainAttributes = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_KEYFRAME);
        Keyframe keyframe = null;
        float namedFloat = TypedArrayUtils.getNamedFloat(obtainAttributes, xmlPullParser, "fraction", 3, -1.0f);
        TypedValue peekNamedValue = TypedArrayUtils.peekNamedValue(obtainAttributes, xmlPullParser, "value", 0);
        boolean z = peekNamedValue != null;
        if (i == 4) {
            i = (!z || !isColorType(peekNamedValue.type)) ? 0 : 3;
        }
        if (z) {
            if (i != 3) {
                switch (i) {
                    case 0:
                        keyframe = Keyframe.ofFloat(namedFloat, TypedArrayUtils.getNamedFloat(obtainAttributes, xmlPullParser, "value", 0, 0.0f));
                        break;
                    case 1:
                        break;
                }
            }
            keyframe = Keyframe.ofInt(namedFloat, TypedArrayUtils.getNamedInt(obtainAttributes, xmlPullParser, "value", 0, 0));
        } else {
            keyframe = i == 0 ? Keyframe.ofFloat(namedFloat) : Keyframe.ofInt(namedFloat);
        }
        int namedResourceId = TypedArrayUtils.getNamedResourceId(obtainAttributes, xmlPullParser, "interpolator", 1, 0);
        if (namedResourceId > 0) {
            keyframe.setInterpolator(AnimationUtilsCompat.loadInterpolator(context, namedResourceId));
        }
        obtainAttributes.recycle();
        return keyframe;
    }

    private static ObjectAnimator loadObjectAnimator(Context context, Resources resources, Resources.Theme theme, AttributeSet attributeSet, float f, XmlPullParser xmlPullParser) throws Resources.NotFoundException {
        ObjectAnimator objectAnimator = new ObjectAnimator();
        loadAnimator(context, resources, theme, attributeSet, objectAnimator, f, xmlPullParser);
        return objectAnimator;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0049  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x00fd A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static android.animation.PropertyValuesHolder loadPvh(android.content.Context r8, android.content.res.Resources r9, android.content.res.Resources.Theme r10, org.xmlpull.v1.XmlPullParser r11, java.lang.String r12, int r13) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            r6 = 0
            r4 = r13
        L_0x0002:
            int r0 = r11.next()
            r1 = 3
            if (r0 == r1) goto L_0x0041
            r1 = 1
            if (r0 == r1) goto L_0x0041
            java.lang.String r0 = r11.getName()
            java.lang.String r1 = "keyframe"
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x0102
            r0 = 4
            if (r4 != r0) goto L_0x0023
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r11)
            int r4 = inferValueTypeOfKeyframe(r9, r10, r0, r11)
        L_0x0023:
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r11)
            r0 = r8
            r1 = r9
            r2 = r10
            r5 = r11
            android.animation.Keyframe r0 = loadKeyframe(r0, r1, r2, r3, r4, r5)
            if (r0 == 0) goto L_0x003b
            if (r6 != 0) goto L_0x0038
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
        L_0x0038:
            r6.add(r0)
        L_0x003b:
            r0 = r6
            r11.next()
        L_0x003f:
            r6 = r0
            goto L_0x0002
        L_0x0041:
            if (r6 == 0) goto L_0x00fd
            int r2 = r6.size()
            if (r2 <= 0) goto L_0x00fd
            r3 = 0
            r0 = 0
            java.lang.Object r0 = r6.get(r0)
            android.animation.Keyframe r0 = (android.animation.Keyframe) r0
            int r1 = r2 + -1
            java.lang.Object r1 = r6.get(r1)
            android.animation.Keyframe r1 = (android.animation.Keyframe) r1
            float r5 = r1.getFraction()
            r7 = 1065353216(0x3f800000, float:1.0)
            int r7 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r7 >= 0) goto L_0x00ff
            r7 = 0
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 >= 0) goto L_0x009c
            r5 = 1065353216(0x3f800000, float:1.0)
            r1.setFraction(r5)
            r1 = r2
        L_0x006e:
            float r2 = r0.getFraction()
            r5 = 0
            int r5 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r5 == 0) goto L_0x0080
            r5 = 0
            int r2 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r2 >= 0) goto L_0x00ac
            r2 = 0
            r0.setFraction(r2)
        L_0x0080:
            android.animation.Keyframe[] r7 = new android.animation.Keyframe[r1]
            r6.toArray(r7)
            r0 = r3
        L_0x0086:
            if (r0 >= r1) goto L_0x00ee
            r2 = r7[r0]
            float r3 = r2.getFraction()
            r5 = 0
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 >= 0) goto L_0x0099
            if (r0 != 0) goto L_0x00b8
            r3 = 0
            r2.setFraction(r3)
        L_0x0099:
            int r0 = r0 + 1
            goto L_0x0086
        L_0x009c:
            int r5 = r6.size()
            r7 = 1065353216(0x3f800000, float:1.0)
            android.animation.Keyframe r1 = createNewKeyframe(r1, r7)
            r6.add(r5, r1)
            int r1 = r2 + 1
            goto L_0x006e
        L_0x00ac:
            r2 = 0
            r5 = 0
            android.animation.Keyframe r0 = createNewKeyframe(r0, r5)
            r6.add(r2, r0)
            int r1 = r1 + 1
            goto L_0x0080
        L_0x00b8:
            int r3 = r1 + -1
            if (r0 != r3) goto L_0x00c2
            r3 = 1065353216(0x3f800000, float:1.0)
            r2.setFraction(r3)
            goto L_0x0099
        L_0x00c2:
            int r3 = r0 + 1
            r2 = r0
        L_0x00c5:
            int r5 = r1 + -1
            if (r3 >= r5) goto L_0x00d4
            r5 = r7[r3]
            float r5 = r5.getFraction()
            r6 = 0
            int r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1))
            if (r5 < 0) goto L_0x00e9
        L_0x00d4:
            int r3 = r2 + 1
            r3 = r7[r3]
            float r3 = r3.getFraction()
            int r5 = r0 + -1
            r5 = r7[r5]
            float r5 = r5.getFraction()
            float r3 = r3 - r5
            distributeKeyframes(r7, r3, r0, r2)
            goto L_0x0099
        L_0x00e9:
            int r5 = r3 + 1
            r2 = r3
            r3 = r5
            goto L_0x00c5
        L_0x00ee:
            android.animation.PropertyValuesHolder r0 = android.animation.PropertyValuesHolder.ofKeyframe(r12, r7)
            r1 = 3
            if (r4 != r1) goto L_0x00fc
            android.support.graphics.drawable.ArgbEvaluator r1 = android.support.graphics.drawable.ArgbEvaluator.getInstance()
            r0.setEvaluator(r1)
        L_0x00fc:
            return r0
        L_0x00fd:
            r0 = 0
            goto L_0x00fc
        L_0x00ff:
            r1 = r2
            goto L_0x006e
        L_0x0102:
            r0 = r6
            goto L_0x003f
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.graphics.drawable.AnimatorInflaterCompat.loadPvh(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser, java.lang.String, int):android.animation.PropertyValuesHolder");
    }

    private static PropertyValuesHolder[] loadValues(Context context, Resources resources, Resources.Theme theme, XmlPullParser xmlPullParser, AttributeSet attributeSet) throws XmlPullParserException, IOException {
        ArrayList arrayList;
        ArrayList arrayList2 = null;
        while (true) {
            int eventType = xmlPullParser.getEventType();
            if (eventType == 3 || eventType == 1) {
            } else if (eventType != 2) {
                xmlPullParser.next();
            } else {
                if (xmlPullParser.getName().equals("propertyValuesHolder")) {
                    TypedArray obtainAttributes = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_PROPERTY_VALUES_HOLDER);
                    String namedString = TypedArrayUtils.getNamedString(obtainAttributes, xmlPullParser, "propertyName", 3);
                    int namedInt = TypedArrayUtils.getNamedInt(obtainAttributes, xmlPullParser, "valueType", 2, 4);
                    PropertyValuesHolder loadPvh = loadPvh(context, resources, theme, xmlPullParser, namedString, namedInt);
                    if (loadPvh == null) {
                        loadPvh = getPVH(obtainAttributes, namedInt, 0, 1, namedString);
                    }
                    if (loadPvh != null) {
                        if (arrayList2 == null) {
                            arrayList2 = new ArrayList();
                        }
                        arrayList2.add(loadPvh);
                    }
                    arrayList = arrayList2;
                    obtainAttributes.recycle();
                } else {
                    arrayList = arrayList2;
                }
                xmlPullParser.next();
                arrayList2 = arrayList;
            }
        }
        if (arrayList2 == null) {
            return null;
        }
        int size = arrayList2.size();
        PropertyValuesHolder[] propertyValuesHolderArr = new PropertyValuesHolder[size];
        for (int i = 0; i < size; i++) {
            propertyValuesHolderArr[i] = (PropertyValuesHolder) arrayList2.get(i);
        }
        return propertyValuesHolderArr;
    }

    private static void parseAnimatorFromTypeArray(ValueAnimator valueAnimator, TypedArray typedArray, TypedArray typedArray2, float f, XmlPullParser xmlPullParser) {
        long namedInt = (long) TypedArrayUtils.getNamedInt(typedArray, xmlPullParser, "duration", 1, 300);
        long namedInt2 = (long) TypedArrayUtils.getNamedInt(typedArray, xmlPullParser, "startOffset", 2, 0);
        int namedInt3 = TypedArrayUtils.getNamedInt(typedArray, xmlPullParser, "valueType", 7, 4);
        if (TypedArrayUtils.hasAttribute(xmlPullParser, "valueFrom") && TypedArrayUtils.hasAttribute(xmlPullParser, "valueTo")) {
            if (namedInt3 == 4) {
                namedInt3 = inferValueTypeFromValues(typedArray, 5, 6);
            }
            PropertyValuesHolder pvh = getPVH(typedArray, namedInt3, 5, 6, BuildConfig.FLAVOR);
            if (pvh != null) {
                valueAnimator.setValues(new PropertyValuesHolder[]{pvh});
            }
        }
        valueAnimator.setDuration(namedInt);
        valueAnimator.setStartDelay(namedInt2);
        valueAnimator.setRepeatCount(TypedArrayUtils.getNamedInt(typedArray, xmlPullParser, "repeatCount", 3, 0));
        valueAnimator.setRepeatMode(TypedArrayUtils.getNamedInt(typedArray, xmlPullParser, "repeatMode", 4, 1));
        if (typedArray2 != null) {
            setupObjectAnimator(valueAnimator, typedArray2, namedInt3, f, xmlPullParser);
        }
    }

    private static void setupObjectAnimator(ValueAnimator valueAnimator, TypedArray typedArray, int i, float f, XmlPullParser xmlPullParser) {
        ObjectAnimator objectAnimator = (ObjectAnimator) valueAnimator;
        String namedString = TypedArrayUtils.getNamedString(typedArray, xmlPullParser, "pathData", 1);
        if (namedString != null) {
            String namedString2 = TypedArrayUtils.getNamedString(typedArray, xmlPullParser, "propertyXName", 2);
            String namedString3 = TypedArrayUtils.getNamedString(typedArray, xmlPullParser, "propertyYName", 3);
            if (i == 2 || i == 4) {
            }
            if (namedString2 == null && namedString3 == null) {
                throw new InflateException(typedArray.getPositionDescription() + " propertyXName or propertyYName is needed for PathData");
            }
            setupPathMotion(PathParser.createPathFromPathData(namedString), objectAnimator, 0.5f * f, namedString2, namedString3);
            return;
        }
        objectAnimator.setPropertyName(TypedArrayUtils.getNamedString(typedArray, xmlPullParser, "propertyName", 0));
    }

    private static void setupPathMotion(Path path, ObjectAnimator objectAnimator, float f, String str, String str2) {
        int i;
        PathMeasure pathMeasure = new PathMeasure(path, false);
        float f2 = 0.0f;
        ArrayList arrayList = new ArrayList();
        arrayList.add(Float.valueOf(0.0f));
        do {
            f2 += pathMeasure.getLength();
            arrayList.add(Float.valueOf(f2));
        } while (pathMeasure.nextContour());
        PathMeasure pathMeasure2 = new PathMeasure(path, false);
        int min = Math.min(100, ((int) (f2 / f)) + 1);
        float[] fArr = new float[min];
        float[] fArr2 = new float[min];
        float[] fArr3 = new float[2];
        float f3 = f2 / ((float) (min - 1));
        float f4 = 0.0f;
        int i2 = 0;
        int i3 = 0;
        while (i3 < min) {
            pathMeasure2.getPosTan(f4 - ((Float) arrayList.get(i2)).floatValue(), fArr3, (float[]) null);
            fArr[i3] = fArr3[0];
            fArr2[i3] = fArr3[1];
            f4 += f3;
            if (i2 + 1 >= arrayList.size() || f4 <= ((Float) arrayList.get(i2 + 1)).floatValue()) {
                i = i2;
            } else {
                i = i2 + 1;
                pathMeasure2.nextContour();
            }
            i3++;
            i2 = i;
        }
        PropertyValuesHolder propertyValuesHolder = null;
        PropertyValuesHolder propertyValuesHolder2 = null;
        if (str != null) {
            propertyValuesHolder = PropertyValuesHolder.ofFloat(str, fArr);
        }
        if (str2 != null) {
            propertyValuesHolder2 = PropertyValuesHolder.ofFloat(str2, fArr2);
        }
        if (propertyValuesHolder == null) {
            objectAnimator.setValues(new PropertyValuesHolder[]{propertyValuesHolder2});
        } else if (propertyValuesHolder2 == null) {
            objectAnimator.setValues(new PropertyValuesHolder[]{propertyValuesHolder});
        } else {
            objectAnimator.setValues(new PropertyValuesHolder[]{propertyValuesHolder, propertyValuesHolder2});
        }
    }
}
