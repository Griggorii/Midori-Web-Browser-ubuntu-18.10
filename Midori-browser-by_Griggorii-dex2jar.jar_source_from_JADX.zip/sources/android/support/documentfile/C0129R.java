package android.support.documentfile;

/* renamed from: android.support.documentfile.R */
public final class C0129R {
    private C0129R() {
    }
}
