package android.support.localbroadcastmanager;

/* renamed from: android.support.localbroadcastmanager.R */
public final class C0147R {
    private C0147R() {
    }
}
