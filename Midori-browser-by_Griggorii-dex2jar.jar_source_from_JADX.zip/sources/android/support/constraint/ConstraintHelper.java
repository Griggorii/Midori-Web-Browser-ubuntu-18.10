package android.support.constraint;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.solver.widgets.Helper;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;

public abstract class ConstraintHelper extends View {
    protected int mCount;
    protected Helper mHelperWidget;
    protected int[] mIds = new int[32];
    private String mReferenceIds;
    protected boolean mUseViewMeasure = false;
    protected Context myContext;

    public ConstraintHelper(Context context) {
        super(context);
        this.myContext = context;
        init((AttributeSet) null);
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.myContext = context;
        init(attributeSet);
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.myContext = context;
        init(attributeSet);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x003c, code lost:
        r0 = ((android.support.constraint.ConstraintLayout) getParent()).getDesignInformation(0, r3);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void addID(java.lang.String r7) {
        /*
            r6 = this;
            r5 = 0
            r2 = 0
            if (r7 != 0) goto L_0x0005
        L_0x0004:
            return
        L_0x0005:
            android.content.Context r0 = r6.myContext
            if (r0 == 0) goto L_0x0004
            java.lang.String r3 = r7.trim()
            java.lang.Class<android.support.constraint.R$id> r0 = android.support.constraint.C0025R.C0026id.class
            java.lang.reflect.Field r0 = r0.getField(r3)     // Catch:{ Exception -> 0x0058 }
            r1 = 0
            int r1 = r0.getInt(r1)     // Catch:{ Exception -> 0x0058 }
        L_0x0018:
            if (r1 != 0) goto L_0x002c
            android.content.Context r0 = r6.myContext
            android.content.res.Resources r0 = r0.getResources()
            java.lang.String r1 = "id"
            android.content.Context r4 = r6.myContext
            java.lang.String r4 = r4.getPackageName()
            int r1 = r0.getIdentifier(r3, r1, r4)
        L_0x002c:
            if (r1 != 0) goto L_0x0077
            boolean r0 = r6.isInEditMode()
            if (r0 == 0) goto L_0x0077
            android.view.ViewParent r0 = r6.getParent()
            boolean r0 = r0 instanceof android.support.constraint.ConstraintLayout
            if (r0 == 0) goto L_0x0077
            android.view.ViewParent r0 = r6.getParent()
            android.support.constraint.ConstraintLayout r0 = (android.support.constraint.ConstraintLayout) r0
            java.lang.Object r0 = r0.getDesignInformation(r2, r3)
            if (r0 == 0) goto L_0x0077
            boolean r2 = r0 instanceof java.lang.Integer
            if (r2 == 0) goto L_0x0077
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
        L_0x0052:
            if (r0 == 0) goto L_0x005b
            r6.setTag(r0, r5)
            goto L_0x0004
        L_0x0058:
            r0 = move-exception
            r1 = r2
            goto L_0x0018
        L_0x005b:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Could not find id of \""
            r0.append(r1)
            r0.append(r3)
            java.lang.String r1 = "\""
            r0.append(r1)
            java.lang.String r1 = "ConstraintHelper"
            java.lang.String r0 = r0.toString()
            android.util.Log.w(r1, r0)
            goto L_0x0004
        L_0x0077:
            r0 = r1
            goto L_0x0052
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.ConstraintHelper.addID(java.lang.String):void");
    }

    private void setIds(String str) {
        if (str != null) {
            int i = 0;
            while (true) {
                int indexOf = str.indexOf(44, i);
                if (indexOf == -1) {
                    addID(str.substring(i));
                    return;
                } else {
                    addID(str.substring(i, indexOf));
                    i = indexOf + 1;
                }
            }
        }
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.mIds, this.mCount);
    }

    /* access modifiers changed from: protected */
    public void init(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0025R.styleable.ConstraintLayout_Layout);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == C0025R.styleable.ConstraintLayout_Layout_constraint_referenced_ids) {
                    this.mReferenceIds = obtainStyledAttributes.getString(index);
                    setIds(this.mReferenceIds);
                }
            }
        }
    }

    public void onDraw(Canvas canvas) {
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        if (this.mUseViewMeasure) {
            super.onMeasure(i, i2);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.mCount = 0;
        for (int tag : iArr) {
            setTag(tag, (Object) null);
        }
    }

    public void setTag(int i, Object obj) {
        if (this.mCount + 1 > this.mIds.length) {
            this.mIds = Arrays.copyOf(this.mIds, this.mIds.length * 2);
        }
        this.mIds[this.mCount] = i;
        this.mCount++;
    }

    public void updatePostLayout(ConstraintLayout constraintLayout) {
    }

    public void updatePostMeasure(ConstraintLayout constraintLayout) {
    }

    public void updatePreLayout(ConstraintLayout constraintLayout) {
        if (isInEditMode()) {
            setIds(this.mReferenceIds);
        }
        if (this.mHelperWidget != null) {
            this.mHelperWidget.removeAllIds();
            for (int i = 0; i < this.mCount; i++) {
                View viewById = constraintLayout.getViewById(this.mIds[i]);
                if (viewById != null) {
                    this.mHelperWidget.add(constraintLayout.getViewWidget(viewById));
                }
            }
        }
    }

    public void validateParams() {
        if (this.mHelperWidget != null) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            if (layoutParams instanceof ConstraintLayout.LayoutParams) {
                ((ConstraintLayout.LayoutParams) layoutParams).widget = this.mHelperWidget;
            }
        }
    }
}
