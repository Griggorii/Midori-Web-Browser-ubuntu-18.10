package android.support.constraint.solver.widgets;

public class ConstraintHorizontalLayout extends ConstraintWidgetContainer {
    private ContentAlignment mAlignment = ContentAlignment.MIDDLE;

    public enum ContentAlignment {
        BEGIN,
        MIDDLE,
        END,
        TOP,
        VERTICAL_MIDDLE,
        BOTTOM,
        LEFT,
        RIGHT
    }

    public ConstraintHorizontalLayout() {
    }

    public ConstraintHorizontalLayout(int i, int i2) {
        super(i, i2);
    }

    public ConstraintHorizontalLayout(int i, int i2, int i3, int i4) {
        super(i, i2, i3, i4);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: android.support.constraint.solver.widgets.ConstraintHorizontalLayout} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: android.support.constraint.solver.widgets.ConstraintHorizontalLayout} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v6, resolved type: android.support.constraint.solver.widgets.ConstraintWidget} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v4, resolved type: android.support.constraint.solver.widgets.ConstraintHorizontalLayout} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void addToSolver(android.support.constraint.solver.LinearSystem r12) {
        /*
            r11 = this;
            r4 = 0
            java.util.ArrayList r0 = r11.mChildren
            int r0 = r0.size()
            if (r0 == 0) goto L_0x0066
            java.util.ArrayList r0 = r11.mChildren
            int r7 = r0.size()
            r6 = r4
            r2 = r11
        L_0x0011:
            if (r6 >= r7) goto L_0x0050
            java.util.ArrayList r0 = r11.mChildren
            java.lang.Object r0 = r0.get(r6)
            android.support.constraint.solver.widgets.ConstraintWidget r0 = (android.support.constraint.solver.widgets.ConstraintWidget) r0
            if (r2 == r11) goto L_0x003e
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r1 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r3 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            r0.connect((android.support.constraint.solver.widgets.ConstraintAnchor.Type) r1, (android.support.constraint.solver.widgets.ConstraintWidget) r2, (android.support.constraint.solver.widgets.ConstraintAnchor.Type) r3)
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r1 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r3 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            r2.connect((android.support.constraint.solver.widgets.ConstraintAnchor.Type) r1, (android.support.constraint.solver.widgets.ConstraintWidget) r0, (android.support.constraint.solver.widgets.ConstraintAnchor.Type) r3)
        L_0x002b:
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r1 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r2 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            r0.connect((android.support.constraint.solver.widgets.ConstraintAnchor.Type) r1, (android.support.constraint.solver.widgets.ConstraintWidget) r11, (android.support.constraint.solver.widgets.ConstraintAnchor.Type) r2)
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r1 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r2 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            r0.connect((android.support.constraint.solver.widgets.ConstraintAnchor.Type) r1, (android.support.constraint.solver.widgets.ConstraintWidget) r11, (android.support.constraint.solver.widgets.ConstraintAnchor.Type) r2)
            int r1 = r6 + 1
            r6 = r1
            r2 = r0
            goto L_0x0011
        L_0x003e:
            android.support.constraint.solver.widgets.ConstraintAnchor$Strength r5 = android.support.constraint.solver.widgets.ConstraintAnchor.Strength.STRONG
            android.support.constraint.solver.widgets.ConstraintHorizontalLayout$ContentAlignment r1 = r11.mAlignment
            android.support.constraint.solver.widgets.ConstraintHorizontalLayout$ContentAlignment r3 = android.support.constraint.solver.widgets.ConstraintHorizontalLayout.ContentAlignment.END
            if (r1 != r3) goto L_0x0048
            android.support.constraint.solver.widgets.ConstraintAnchor$Strength r5 = android.support.constraint.solver.widgets.ConstraintAnchor.Strength.WEAK
        L_0x0048:
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r1 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r3 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            r0.connect((android.support.constraint.solver.widgets.ConstraintAnchor.Type) r1, (android.support.constraint.solver.widgets.ConstraintWidget) r2, (android.support.constraint.solver.widgets.ConstraintAnchor.Type) r3, (int) r4, (android.support.constraint.solver.widgets.ConstraintAnchor.Strength) r5)
            goto L_0x002b
        L_0x0050:
            if (r2 == r11) goto L_0x0066
            android.support.constraint.solver.widgets.ConstraintAnchor$Strength r10 = android.support.constraint.solver.widgets.ConstraintAnchor.Strength.STRONG
            android.support.constraint.solver.widgets.ConstraintHorizontalLayout$ContentAlignment r0 = r11.mAlignment
            android.support.constraint.solver.widgets.ConstraintHorizontalLayout$ContentAlignment r1 = android.support.constraint.solver.widgets.ConstraintHorizontalLayout.ContentAlignment.BEGIN
            if (r0 != r1) goto L_0x005c
            android.support.constraint.solver.widgets.ConstraintAnchor$Strength r10 = android.support.constraint.solver.widgets.ConstraintAnchor.Strength.WEAK
        L_0x005c:
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r6 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r8 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            r5 = r2
            r7 = r11
            r9 = r4
            r5.connect((android.support.constraint.solver.widgets.ConstraintAnchor.Type) r6, (android.support.constraint.solver.widgets.ConstraintWidget) r7, (android.support.constraint.solver.widgets.ConstraintAnchor.Type) r8, (int) r9, (android.support.constraint.solver.widgets.ConstraintAnchor.Strength) r10)
        L_0x0066:
            super.addToSolver(r12)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.solver.widgets.ConstraintHorizontalLayout.addToSolver(android.support.constraint.solver.LinearSystem):void");
    }
}
