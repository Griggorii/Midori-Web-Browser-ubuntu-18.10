package android.support.constraint.solver.widgets;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ConstraintWidgetGroup {
    public List<ConstraintWidget> mConstrainedGroup;
    public final int[] mGroupDimensions = {this.mGroupWidth, this.mGroupHeight};
    int mGroupHeight = -1;
    int mGroupWidth = -1;
    public boolean mSkipSolver = false;
    List<ConstraintWidget> mStartHorizontalWidgets = new ArrayList();
    List<ConstraintWidget> mStartVerticalWidgets = new ArrayList();
    List<ConstraintWidget> mUnresolvedWidgets = new ArrayList();
    HashSet<ConstraintWidget> mWidgetsToSetHorizontal = new HashSet<>();
    HashSet<ConstraintWidget> mWidgetsToSetVertical = new HashSet<>();
    List<ConstraintWidget> mWidgetsToSolve = new ArrayList();

    ConstraintWidgetGroup(List<ConstraintWidget> list) {
        this.mConstrainedGroup = list;
    }

    ConstraintWidgetGroup(List<ConstraintWidget> list, boolean z) {
        this.mConstrainedGroup = list;
        this.mSkipSolver = z;
    }

    private void getWidgetsToSolveTraversal(ArrayList<ConstraintWidget> arrayList, ConstraintWidget constraintWidget) {
        if (!constraintWidget.mGroupsToSolver) {
            arrayList.add(constraintWidget);
            constraintWidget.mGroupsToSolver = true;
            if (!constraintWidget.isFullyResolved()) {
                if (constraintWidget instanceof Helper) {
                    Helper helper = (Helper) constraintWidget;
                    int i = helper.mWidgetsCount;
                    for (int i2 = 0; i2 < i; i2++) {
                        getWidgetsToSolveTraversal(arrayList, helper.mWidgets[i2]);
                    }
                }
                for (ConstraintAnchor constraintAnchor : constraintWidget.mListAnchors) {
                    ConstraintAnchor constraintAnchor2 = constraintAnchor.mTarget;
                    if (constraintAnchor2 != null) {
                        ConstraintWidget constraintWidget2 = constraintAnchor2.mOwner;
                        if (!(constraintAnchor2 == null || constraintWidget2 == constraintWidget.getParent())) {
                            getWidgetsToSolveTraversal(arrayList, constraintWidget2);
                        }
                    }
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x003a  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0050  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x0086  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0093  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void updateResolvedDimension(android.support.constraint.solver.widgets.ConstraintWidget r7) {
        /*
            r6 = this;
            r1 = 0
            r3 = 1
            boolean r0 = r7.mOptimizerMeasurable
            if (r0 == 0) goto L_0x000c
            boolean r0 = r7.isFullyResolved()
            if (r0 == 0) goto L_0x000d
        L_0x000c:
            return
        L_0x000d:
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r7.mRight
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            if (r0 == 0) goto L_0x0074
            r2 = r3
        L_0x0014:
            if (r2 == 0) goto L_0x0076
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r7.mRight
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
        L_0x001a:
            if (r0 == 0) goto L_0x00f3
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mOwner
            boolean r4 = r4.mOptimizerMeasured
            if (r4 != 0) goto L_0x0027
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mOwner
            r6.updateResolvedDimension(r4)
        L_0x0027:
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r4 = r0.mType
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r5 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            if (r4 != r5) goto L_0x007b
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mOwner
            int r4 = r4.f5mX
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mOwner
            int r0 = r0.getWidth()
            int r0 = r0 + r4
        L_0x0038:
            if (r2 == 0) goto L_0x0086
            android.support.constraint.solver.widgets.ConstraintAnchor r2 = r7.mRight
            int r2 = r2.getMargin()
            int r0 = r0 - r2
        L_0x0041:
            int r2 = r7.getWidth()
            int r2 = r0 - r2
            r7.setHorizontalDimension(r2, r0)
            android.support.constraint.solver.widgets.ConstraintAnchor r2 = r7.mBaseline
            android.support.constraint.solver.widgets.ConstraintAnchor r2 = r2.mTarget
            if (r2 == 0) goto L_0x0093
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r7.mBaseline
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r0.mOwner
            boolean r1 = r1.mOptimizerMeasured
            if (r1 != 0) goto L_0x005f
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r0.mOwner
            r6.updateResolvedDimension(r1)
        L_0x005f:
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r0.mOwner
            int r1 = r1.f6mY
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mOwner
            int r0 = r0.mBaselineDistance
            int r0 = r0 + r1
            int r1 = r7.mBaselineDistance
            int r0 = r0 - r1
            int r1 = r7.mHeight
            int r1 = r1 + r0
            r7.setVerticalDimension(r0, r1)
            r7.mOptimizerMeasured = r3
            goto L_0x000c
        L_0x0074:
            r2 = r1
            goto L_0x0014
        L_0x0076:
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r7.mLeft
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            goto L_0x001a
        L_0x007b:
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r4 = r0.mType
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r5 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            if (r4 != r5) goto L_0x00f3
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mOwner
            int r0 = r0.f5mX
            goto L_0x0038
        L_0x0086:
            android.support.constraint.solver.widgets.ConstraintAnchor r2 = r7.mLeft
            int r2 = r2.getMargin()
            int r4 = r7.getWidth()
            int r2 = r2 + r4
            int r0 = r0 + r2
            goto L_0x0041
        L_0x0093:
            android.support.constraint.solver.widgets.ConstraintAnchor r2 = r7.mBottom
            android.support.constraint.solver.widgets.ConstraintAnchor r2 = r2.mTarget
            if (r2 == 0) goto L_0x00f1
            r2 = r3
        L_0x009a:
            if (r2 == 0) goto L_0x00d4
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r7.mBottom
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r1.mTarget
        L_0x00a0:
            if (r1 == 0) goto L_0x00be
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r1.mOwner
            boolean r4 = r4.mOptimizerMeasured
            if (r4 != 0) goto L_0x00ad
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r1.mOwner
            r6.updateResolvedDimension(r4)
        L_0x00ad:
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r4 = r1.mType
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r5 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            if (r4 != r5) goto L_0x00d9
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r1.mOwner
            int r0 = r0.f6mY
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r1.mOwner
            int r1 = r1.getHeight()
            int r0 = r0 + r1
        L_0x00be:
            if (r2 == 0) goto L_0x00e4
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r7.mBottom
            int r1 = r1.getMargin()
            int r0 = r0 - r1
        L_0x00c7:
            int r1 = r7.getHeight()
            int r1 = r0 - r1
            r7.setVerticalDimension(r1, r0)
            r7.mOptimizerMeasured = r3
            goto L_0x000c
        L_0x00d4:
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r7.mTop
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r1.mTarget
            goto L_0x00a0
        L_0x00d9:
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r4 = r1.mType
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r5 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            if (r4 != r5) goto L_0x00be
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r1.mOwner
            int r0 = r0.f6mY
            goto L_0x00be
        L_0x00e4:
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r7.mTop
            int r1 = r1.getMargin()
            int r2 = r7.getHeight()
            int r1 = r1 + r2
            int r0 = r0 + r1
            goto L_0x00c7
        L_0x00f1:
            r2 = r1
            goto L_0x009a
        L_0x00f3:
            r0 = r1
            goto L_0x0038
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.solver.widgets.ConstraintWidgetGroup.updateResolvedDimension(android.support.constraint.solver.widgets.ConstraintWidget):void");
    }

    /* access modifiers changed from: package-private */
    public void addWidgetsToSet(ConstraintWidget constraintWidget, int i) {
        if (i == 0) {
            this.mWidgetsToSetHorizontal.add(constraintWidget);
        } else if (i == 1) {
            this.mWidgetsToSetVertical.add(constraintWidget);
        }
    }

    public List<ConstraintWidget> getStartWidgets(int i) {
        if (i == 0) {
            return this.mStartHorizontalWidgets;
        }
        if (i == 1) {
            return this.mStartVerticalWidgets;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public Set<ConstraintWidget> getWidgetsToSet(int i) {
        if (i == 0) {
            return this.mWidgetsToSetHorizontal;
        }
        if (i == 1) {
            return this.mWidgetsToSetVertical;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public List<ConstraintWidget> getWidgetsToSolve() {
        if (!this.mWidgetsToSolve.isEmpty()) {
            return this.mWidgetsToSolve;
        }
        int size = this.mConstrainedGroup.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = this.mConstrainedGroup.get(i);
            if (!constraintWidget.mOptimizerMeasurable) {
                getWidgetsToSolveTraversal((ArrayList) this.mWidgetsToSolve, constraintWidget);
            }
        }
        this.mUnresolvedWidgets.clear();
        this.mUnresolvedWidgets.addAll(this.mConstrainedGroup);
        this.mUnresolvedWidgets.removeAll(this.mWidgetsToSolve);
        return this.mWidgetsToSolve;
    }

    /* access modifiers changed from: package-private */
    public void updateUnresolvedWidgets() {
        int size = this.mUnresolvedWidgets.size();
        for (int i = 0; i < size; i++) {
            updateResolvedDimension(this.mUnresolvedWidgets.get(i));
        }
    }
}
