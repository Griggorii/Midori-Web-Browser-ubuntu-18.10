package android.support.constraint.solver.widgets;

import android.support.constraint.solver.Cache;
import android.support.constraint.solver.LinearSystem;
import android.support.constraint.solver.SolverVariable;
import android.support.constraint.solver.widgets.ConstraintAnchor;
import java.util.ArrayList;
import org.midori_browser.midori.BuildConfig;

public class ConstraintWidget {
    protected static final int ANCHOR_BASELINE = 4;
    protected static final int ANCHOR_BOTTOM = 3;
    protected static final int ANCHOR_LEFT = 0;
    protected static final int ANCHOR_RIGHT = 1;
    protected static final int ANCHOR_TOP = 2;
    private static final boolean AUTOTAG_CENTER = false;
    public static final int CHAIN_PACKED = 2;
    public static final int CHAIN_SPREAD = 0;
    public static final int CHAIN_SPREAD_INSIDE = 1;
    public static float DEFAULT_BIAS = 0.5f;
    static final int DIMENSION_HORIZONTAL = 0;
    static final int DIMENSION_VERTICAL = 1;
    protected static final int DIRECT = 2;
    public static final int GONE = 8;
    public static final int HORIZONTAL = 0;
    public static final int INVISIBLE = 4;
    public static final int MATCH_CONSTRAINT_PERCENT = 2;
    public static final int MATCH_CONSTRAINT_RATIO = 3;
    public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
    public static final int MATCH_CONSTRAINT_SPREAD = 0;
    public static final int MATCH_CONSTRAINT_WRAP = 1;
    protected static final int SOLVER = 1;
    public static final int UNKNOWN = -1;
    public static final int VERTICAL = 1;
    public static final int VISIBLE = 0;
    private static final int WRAP = -2;
    protected ArrayList<ConstraintAnchor> mAnchors;
    ConstraintAnchor mBaseline;
    int mBaselineDistance;
    ConstraintWidgetGroup mBelongingGroup;
    ConstraintAnchor mBottom;
    boolean mBottomHasCentered;
    ConstraintAnchor mCenter;
    ConstraintAnchor mCenterX;
    ConstraintAnchor mCenterY;
    private float mCircleConstraintAngle;
    private Object mCompanionWidget;
    private int mContainerItemSkip;
    private String mDebugName;
    protected float mDimensionRatio;
    protected int mDimensionRatioSide;
    int mDistToBottom;
    int mDistToLeft;
    int mDistToRight;
    int mDistToTop;
    private int mDrawHeight;
    private int mDrawWidth;
    private int mDrawX;
    private int mDrawY;
    boolean mGroupsToSolver;
    int mHeight;
    float mHorizontalBiasPercent;
    boolean mHorizontalChainFixedPosition;
    int mHorizontalChainStyle;
    ConstraintWidget mHorizontalNextWidget;
    public int mHorizontalResolution;
    boolean mHorizontalWrapVisited;
    boolean mIsHeightWrapContent;
    boolean mIsWidthWrapContent;
    ConstraintAnchor mLeft;
    boolean mLeftHasCentered;
    protected ConstraintAnchor[] mListAnchors;
    protected DimensionBehaviour[] mListDimensionBehaviors;
    protected ConstraintWidget[] mListNextMatchConstraintsWidget;
    int mMatchConstraintDefaultHeight;
    int mMatchConstraintDefaultWidth;
    int mMatchConstraintMaxHeight;
    int mMatchConstraintMaxWidth;
    int mMatchConstraintMinHeight;
    int mMatchConstraintMinWidth;
    float mMatchConstraintPercentHeight;
    float mMatchConstraintPercentWidth;
    private int[] mMaxDimension;
    protected int mMinHeight;
    protected int mMinWidth;
    protected ConstraintWidget[] mNextChainWidget;
    protected int mOffsetX;
    protected int mOffsetY;
    boolean mOptimizerMeasurable;
    boolean mOptimizerMeasured;
    ConstraintWidget mParent;
    int mRelX;
    int mRelY;
    ResolutionDimension mResolutionHeight;
    ResolutionDimension mResolutionWidth;
    float mResolvedDimensionRatio;
    int mResolvedDimensionRatioSide;
    int[] mResolvedMatchConstraintDefault;
    ConstraintAnchor mRight;
    boolean mRightHasCentered;
    ConstraintAnchor mTop;
    boolean mTopHasCentered;
    private String mType;
    float mVerticalBiasPercent;
    boolean mVerticalChainFixedPosition;
    int mVerticalChainStyle;
    ConstraintWidget mVerticalNextWidget;
    public int mVerticalResolution;
    boolean mVerticalWrapVisited;
    private int mVisibility;
    float[] mWeight;
    int mWidth;
    private int mWrapHeight;
    private int mWrapWidth;

    /* renamed from: mX */
    protected int f5mX;

    /* renamed from: mY */
    protected int f6mY;

    public enum ContentAlignment {
        BEGIN,
        MIDDLE,
        END,
        TOP,
        VERTICAL_MIDDLE,
        BOTTOM,
        LEFT,
        RIGHT
    }

    public enum DimensionBehaviour {
        FIXED,
        WRAP_CONTENT,
        MATCH_CONSTRAINT,
        MATCH_PARENT
    }

    public ConstraintWidget() {
        this.mHorizontalResolution = -1;
        this.mVerticalResolution = -1;
        this.mMatchConstraintDefaultWidth = 0;
        this.mMatchConstraintDefaultHeight = 0;
        this.mResolvedMatchConstraintDefault = new int[2];
        this.mMatchConstraintMinWidth = 0;
        this.mMatchConstraintMaxWidth = 0;
        this.mMatchConstraintPercentWidth = 1.0f;
        this.mMatchConstraintMinHeight = 0;
        this.mMatchConstraintMaxHeight = 0;
        this.mMatchConstraintPercentHeight = 1.0f;
        this.mResolvedDimensionRatioSide = -1;
        this.mResolvedDimensionRatio = 1.0f;
        this.mBelongingGroup = null;
        this.mMaxDimension = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.mCircleConstraintAngle = 0.0f;
        this.mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
        this.mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
        this.mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
        this.mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
        this.mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
        this.mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
        this.mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
        this.mCenter = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
        this.mListAnchors = new ConstraintAnchor[]{this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, this.mCenter};
        this.mAnchors = new ArrayList<>();
        this.mListDimensionBehaviors = new DimensionBehaviour[]{DimensionBehaviour.FIXED, DimensionBehaviour.FIXED};
        this.mParent = null;
        this.mWidth = 0;
        this.mHeight = 0;
        this.mDimensionRatio = 0.0f;
        this.mDimensionRatioSide = -1;
        this.f5mX = 0;
        this.f6mY = 0;
        this.mRelX = 0;
        this.mRelY = 0;
        this.mDrawX = 0;
        this.mDrawY = 0;
        this.mDrawWidth = 0;
        this.mDrawHeight = 0;
        this.mOffsetX = 0;
        this.mOffsetY = 0;
        this.mBaselineDistance = 0;
        this.mHorizontalBiasPercent = DEFAULT_BIAS;
        this.mVerticalBiasPercent = DEFAULT_BIAS;
        this.mContainerItemSkip = 0;
        this.mVisibility = 0;
        this.mDebugName = null;
        this.mType = null;
        this.mOptimizerMeasurable = false;
        this.mOptimizerMeasured = false;
        this.mGroupsToSolver = false;
        this.mHorizontalChainStyle = 0;
        this.mVerticalChainStyle = 0;
        this.mWeight = new float[]{-1.0f, -1.0f};
        this.mListNextMatchConstraintsWidget = new ConstraintWidget[]{null, null};
        this.mNextChainWidget = new ConstraintWidget[]{null, null};
        this.mHorizontalNextWidget = null;
        this.mVerticalNextWidget = null;
        addAnchors();
    }

    public ConstraintWidget(int i, int i2) {
        this(0, 0, i, i2);
    }

    public ConstraintWidget(int i, int i2, int i3, int i4) {
        this.mHorizontalResolution = -1;
        this.mVerticalResolution = -1;
        this.mMatchConstraintDefaultWidth = 0;
        this.mMatchConstraintDefaultHeight = 0;
        this.mResolvedMatchConstraintDefault = new int[2];
        this.mMatchConstraintMinWidth = 0;
        this.mMatchConstraintMaxWidth = 0;
        this.mMatchConstraintPercentWidth = 1.0f;
        this.mMatchConstraintMinHeight = 0;
        this.mMatchConstraintMaxHeight = 0;
        this.mMatchConstraintPercentHeight = 1.0f;
        this.mResolvedDimensionRatioSide = -1;
        this.mResolvedDimensionRatio = 1.0f;
        this.mBelongingGroup = null;
        this.mMaxDimension = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.mCircleConstraintAngle = 0.0f;
        this.mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
        this.mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
        this.mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
        this.mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
        this.mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
        this.mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
        this.mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
        this.mCenter = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
        this.mListAnchors = new ConstraintAnchor[]{this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, this.mCenter};
        this.mAnchors = new ArrayList<>();
        this.mListDimensionBehaviors = new DimensionBehaviour[]{DimensionBehaviour.FIXED, DimensionBehaviour.FIXED};
        this.mParent = null;
        this.mWidth = 0;
        this.mHeight = 0;
        this.mDimensionRatio = 0.0f;
        this.mDimensionRatioSide = -1;
        this.f5mX = 0;
        this.f6mY = 0;
        this.mRelX = 0;
        this.mRelY = 0;
        this.mDrawX = 0;
        this.mDrawY = 0;
        this.mDrawWidth = 0;
        this.mDrawHeight = 0;
        this.mOffsetX = 0;
        this.mOffsetY = 0;
        this.mBaselineDistance = 0;
        this.mHorizontalBiasPercent = DEFAULT_BIAS;
        this.mVerticalBiasPercent = DEFAULT_BIAS;
        this.mContainerItemSkip = 0;
        this.mVisibility = 0;
        this.mDebugName = null;
        this.mType = null;
        this.mOptimizerMeasurable = false;
        this.mOptimizerMeasured = false;
        this.mGroupsToSolver = false;
        this.mHorizontalChainStyle = 0;
        this.mVerticalChainStyle = 0;
        this.mWeight = new float[]{-1.0f, -1.0f};
        this.mListNextMatchConstraintsWidget = new ConstraintWidget[]{null, null};
        this.mNextChainWidget = new ConstraintWidget[]{null, null};
        this.mHorizontalNextWidget = null;
        this.mVerticalNextWidget = null;
        this.f5mX = i;
        this.f6mY = i2;
        this.mWidth = i3;
        this.mHeight = i4;
        addAnchors();
        forceUpdateDrawPosition();
    }

    private void addAnchors() {
        this.mAnchors.add(this.mLeft);
        this.mAnchors.add(this.mTop);
        this.mAnchors.add(this.mRight);
        this.mAnchors.add(this.mBottom);
        this.mAnchors.add(this.mCenterX);
        this.mAnchors.add(this.mCenterY);
        this.mAnchors.add(this.mCenter);
        this.mAnchors.add(this.mBaseline);
    }

    private void applyConstraints(LinearSystem linearSystem, boolean z, SolverVariable solverVariable, SolverVariable solverVariable2, DimensionBehaviour dimensionBehaviour, boolean z2, ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, int i, int i2, int i3, int i4, float f, boolean z3, boolean z4, int i5, int i6, int i7, float f2, boolean z5) {
        int i8;
        int i9;
        SolverVariable solverVariable3;
        SolverVariable solverVariable4;
        boolean z6;
        boolean z7;
        int i10;
        boolean z8;
        boolean z9;
        boolean z10;
        boolean z11;
        int i11;
        SolverVariable createObjectVariable = linearSystem.createObjectVariable(constraintAnchor);
        SolverVariable createObjectVariable2 = linearSystem.createObjectVariable(constraintAnchor2);
        SolverVariable createObjectVariable3 = linearSystem.createObjectVariable(constraintAnchor.getTarget());
        SolverVariable createObjectVariable4 = linearSystem.createObjectVariable(constraintAnchor2.getTarget());
        if (linearSystem.graphOptimizer && constraintAnchor.getResolutionNode().state == 1 && constraintAnchor2.getResolutionNode().state == 1) {
            if (LinearSystem.getMetrics() != null) {
                LinearSystem.getMetrics().resolvedWidgets++;
            }
            constraintAnchor.getResolutionNode().addResolvedValue(linearSystem);
            constraintAnchor2.getResolutionNode().addResolvedValue(linearSystem);
            if (!z4 && z) {
                linearSystem.addGreaterThan(solverVariable2, createObjectVariable2, 0, 6);
                return;
            }
            return;
        }
        if (LinearSystem.getMetrics() != null) {
            LinearSystem.getMetrics().nonresolvedWidgets++;
        }
        boolean isConnected = constraintAnchor.isConnected();
        boolean isConnected2 = constraintAnchor2.isConnected();
        boolean isConnected3 = this.mCenter.isConnected();
        boolean z12 = false;
        int i12 = 0;
        if (isConnected) {
            i12 = 1;
        }
        if (isConnected2) {
            i12++;
        }
        int i13 = isConnected3 ? i12 + 1 : i12;
        if (z3) {
            i5 = 3;
        }
        switch (dimensionBehaviour) {
            case FIXED:
                z12 = false;
                break;
            case WRAP_CONTENT:
                z12 = false;
                break;
            case MATCH_PARENT:
                z12 = false;
                break;
            case MATCH_CONSTRAINT:
                z12 = true;
                if (i5 == 4) {
                    z12 = false;
                    break;
                }
                break;
        }
        if (this.mVisibility == 8) {
            i8 = 0;
            z12 = false;
        } else {
            i8 = i2;
        }
        if (z5) {
            if (!isConnected && !isConnected2 && !isConnected3) {
                linearSystem.addEquality(createObjectVariable, i);
            } else if (isConnected && !isConnected2) {
                linearSystem.addEquality(createObjectVariable, createObjectVariable3, constraintAnchor.getMargin(), 6);
            }
        }
        if (!z12) {
            if (z2) {
                linearSystem.addEquality(createObjectVariable2, createObjectVariable, 0, 3);
                if (i3 > 0) {
                    linearSystem.addGreaterThan(createObjectVariable2, createObjectVariable, i3, 6);
                }
                if (i4 < Integer.MAX_VALUE) {
                    linearSystem.addLowerThan(createObjectVariable2, createObjectVariable, i4, 6);
                }
            } else {
                linearSystem.addEquality(createObjectVariable2, createObjectVariable, i8, 6);
            }
            z6 = z12;
        } else {
            if (i6 == -2) {
                i6 = i8;
            }
            if (i7 == -2) {
                i7 = i8;
            }
            if (i6 > 0) {
                linearSystem.addGreaterThan(createObjectVariable2, createObjectVariable, i6, 6);
                i8 = Math.max(i8, i6);
            }
            if (i7 > 0) {
                linearSystem.addLowerThan(createObjectVariable2, createObjectVariable, i7, 6);
                i9 = Math.min(i8, i7);
            } else {
                i9 = i8;
            }
            if (i5 == 1) {
                if (z) {
                    linearSystem.addEquality(createObjectVariable2, createObjectVariable, i9, 6);
                } else if (z4) {
                    linearSystem.addEquality(createObjectVariable2, createObjectVariable, i9, 4);
                } else {
                    linearSystem.addEquality(createObjectVariable2, createObjectVariable, i9, 1);
                }
            } else if (i5 == 2) {
                if (constraintAnchor.getType() == ConstraintAnchor.Type.TOP || constraintAnchor.getType() == ConstraintAnchor.Type.BOTTOM) {
                    solverVariable3 = linearSystem.createObjectVariable(this.mParent.getAnchor(ConstraintAnchor.Type.TOP));
                    solverVariable4 = linearSystem.createObjectVariable(this.mParent.getAnchor(ConstraintAnchor.Type.BOTTOM));
                } else {
                    solverVariable3 = linearSystem.createObjectVariable(this.mParent.getAnchor(ConstraintAnchor.Type.LEFT));
                    solverVariable4 = linearSystem.createObjectVariable(this.mParent.getAnchor(ConstraintAnchor.Type.RIGHT));
                }
                linearSystem.addConstraint(linearSystem.createRow().createRowDimensionRatio(createObjectVariable2, createObjectVariable, solverVariable4, solverVariable3, f2));
                z12 = false;
            }
            if (z12 && i13 != 2 && !z3) {
                int max = Math.max(i6, i9);
                if (i7 > 0) {
                    max = Math.min(i7, max);
                }
                linearSystem.addEquality(createObjectVariable2, createObjectVariable, max, 6);
                z12 = false;
            }
            z6 = z12;
        }
        if (z5 && !z4) {
            if (isConnected || isConnected2 || isConnected3) {
                if (!isConnected || isConnected2) {
                    if (!isConnected && isConnected2) {
                        linearSystem.addEquality(createObjectVariable2, createObjectVariable4, -constraintAnchor2.getMargin(), 6);
                        if (z) {
                            linearSystem.addGreaterThan(createObjectVariable, solverVariable, 0, 5);
                        }
                    } else if (isConnected && isConnected2) {
                        boolean z13 = false;
                        if (z6) {
                            if (z && i3 == 0) {
                                linearSystem.addGreaterThan(createObjectVariable2, createObjectVariable, 0, 6);
                            }
                            if (i5 == 0) {
                                int i14 = 6;
                                if (i7 > 0 || i6 > 0) {
                                    i14 = 4;
                                    z13 = true;
                                }
                                linearSystem.addEquality(createObjectVariable, createObjectVariable3, constraintAnchor.getMargin(), i14);
                                linearSystem.addEquality(createObjectVariable2, createObjectVariable4, -constraintAnchor2.getMargin(), i14);
                                i10 = 5;
                                z8 = i7 > 0 || i6 > 0;
                                z9 = z13;
                            } else if (i5 == 1) {
                                i10 = 6;
                                z8 = true;
                                z9 = true;
                            } else if (i5 == 3) {
                                int i15 = 4;
                                if (!z3 && this.mResolvedDimensionRatioSide != -1 && i7 <= 0) {
                                    i15 = 6;
                                }
                                linearSystem.addEquality(createObjectVariable, createObjectVariable3, constraintAnchor.getMargin(), i15);
                                linearSystem.addEquality(createObjectVariable2, createObjectVariable4, -constraintAnchor2.getMargin(), i15);
                                z7 = true;
                                i10 = 5;
                                z8 = true;
                                z9 = z7;
                            } else {
                                i10 = 5;
                                z8 = false;
                                z9 = false;
                            }
                        } else {
                            z7 = false;
                            i10 = 5;
                            z8 = true;
                            z9 = z7;
                        }
                        int i16 = 5;
                        if (z8) {
                            linearSystem.addCentering(createObjectVariable, createObjectVariable3, constraintAnchor.getMargin(), f, createObjectVariable4, createObjectVariable2, constraintAnchor2.getMargin(), i10);
                            boolean z14 = constraintAnchor.mTarget.mOwner instanceof Barrier;
                            boolean z15 = constraintAnchor2.mTarget.mOwner instanceof Barrier;
                            if (z14 && !z15) {
                                i16 = 6;
                                z10 = true;
                                z11 = z;
                                i11 = 5;
                            } else if (z14 || !z15) {
                                z10 = z;
                                z11 = z;
                                i11 = 5;
                            } else {
                                i11 = 6;
                                z11 = true;
                                z10 = z;
                            }
                        } else {
                            z10 = z;
                            z11 = z;
                            i11 = 5;
                        }
                        if (z9) {
                            i11 = 6;
                            i16 = 6;
                        }
                        if ((!z6 && z11) || z9) {
                            linearSystem.addGreaterThan(createObjectVariable, createObjectVariable3, constraintAnchor.getMargin(), i11);
                        }
                        if ((!z6 && z10) || z9) {
                            linearSystem.addLowerThan(createObjectVariable2, createObjectVariable4, -constraintAnchor2.getMargin(), i16);
                        }
                        if (z) {
                            linearSystem.addGreaterThan(createObjectVariable, solverVariable, 0, 6);
                        }
                    }
                } else if (z) {
                    linearSystem.addGreaterThan(solverVariable2, createObjectVariable2, 0, 5);
                }
            } else if (z) {
                linearSystem.addGreaterThan(solverVariable2, createObjectVariable2, 0, 5);
            }
            if (z) {
                linearSystem.addGreaterThan(solverVariable2, createObjectVariable2, 0, 6);
            }
        } else if (i13 < 2 && z) {
            linearSystem.addGreaterThan(createObjectVariable, solverVariable, 0, 6);
            linearSystem.addGreaterThan(solverVariable2, createObjectVariable2, 0, 6);
        }
    }

    private boolean isChainHead(int i) {
        int i2 = i * 2;
        return (this.mListAnchors[i2].mTarget == null || this.mListAnchors[i2].mTarget.mTarget == this.mListAnchors[i2] || this.mListAnchors[i2 + 1].mTarget == null || this.mListAnchors[i2 + 1].mTarget.mTarget != this.mListAnchors[i2 + 1]) ? false : true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:100:0x026c  */
    /* JADX WARNING: Removed duplicated region for block: B:101:0x026f  */
    /* JADX WARNING: Removed duplicated region for block: B:102:0x0272  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x02ed  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x02f1  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x02fa  */
    /* JADX WARNING: Removed duplicated region for block: B:165:? A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0108  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x0116  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0125  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0131  */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x0197  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x01c5  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x01d8  */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x01e5  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x01ee  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void addToSolver(android.support.constraint.solver.LinearSystem r36) {
        /*
            r35 = this;
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mLeft
            r0 = r36
            android.support.constraint.solver.SolverVariable r30 = r0.createObjectVariable(r4)
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mRight
            r0 = r36
            android.support.constraint.solver.SolverVariable r31 = r0.createObjectVariable(r4)
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mTop
            r0 = r36
            android.support.constraint.solver.SolverVariable r32 = r0.createObjectVariable(r4)
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mBottom
            r0 = r36
            android.support.constraint.solver.SolverVariable r33 = r0.createObjectVariable(r4)
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mBaseline
            r0 = r36
            android.support.constraint.solver.SolverVariable r34 = r0.createObjectVariable(r4)
            r8 = 0
            r4 = 0
            r5 = 0
            r7 = 0
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r6 = r0.mParent
            if (r6 == 0) goto L_0x0449
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            if (r4 == 0) goto L_0x0257
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r4 = r4.mListDimensionBehaviors
            r5 = 0
            r4 = r4[r5]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r5 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r4 != r5) goto L_0x0257
            r4 = 1
            r5 = r4
        L_0x0051:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            if (r4 == 0) goto L_0x025b
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r4 = r4.mListDimensionBehaviors
            r6 = 1
            r4 = r4[r6]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r6 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r4 != r6) goto L_0x025b
            r4 = 1
            r7 = r4
        L_0x0066:
            r4 = 0
            r0 = r35
            boolean r4 = r0.isChainHead(r4)
            if (r4 == 0) goto L_0x025f
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintWidgetContainer r4 = (android.support.constraint.solver.widgets.ConstraintWidgetContainer) r4
            r6 = 0
            r0 = r35
            r4.addChain(r0, r6)
            r4 = 1
            r8 = r4
        L_0x007d:
            r4 = 1
            r0 = r35
            boolean r4 = r0.isChainHead(r4)
            if (r4 == 0) goto L_0x0266
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintWidgetContainer r4 = (android.support.constraint.solver.widgets.ConstraintWidgetContainer) r4
            r6 = 1
            r0 = r35
            r4.addChain(r0, r6)
            r4 = 1
        L_0x0093:
            if (r5 == 0) goto L_0x00c2
            r0 = r35
            int r6 = r0.mVisibility
            r9 = 8
            if (r6 == r9) goto L_0x00c2
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r0.mLeft
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r6.mTarget
            if (r6 != 0) goto L_0x00c2
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r0.mRight
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r6.mTarget
            if (r6 != 0) goto L_0x00c2
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r6 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r6.mRight
            r0 = r36
            android.support.constraint.solver.SolverVariable r6 = r0.createObjectVariable(r6)
            r9 = 0
            r10 = 1
            r0 = r36
            r1 = r31
            r0.addGreaterThan(r6, r1, r9, r10)
        L_0x00c2:
            if (r7 == 0) goto L_0x0449
            r0 = r35
            int r6 = r0.mVisibility
            r9 = 8
            if (r6 == r9) goto L_0x0449
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r0.mTop
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r6.mTarget
            if (r6 != 0) goto L_0x0449
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r0.mBottom
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r6.mTarget
            if (r6 != 0) goto L_0x0449
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r0.mBaseline
            if (r6 != 0) goto L_0x0449
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r6 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r6.mBottom
            r0 = r36
            android.support.constraint.solver.SolverVariable r6 = r0.createObjectVariable(r6)
            r9 = 0
            r10 = 1
            r0 = r36
            r1 = r33
            r0.addGreaterThan(r6, r1, r9, r10)
            r25 = r7
            r6 = r5
            r26 = r4
            r19 = r8
        L_0x00fe:
            r0 = r35
            int r4 = r0.mWidth
            r0 = r35
            int r5 = r0.mMinWidth
            if (r4 >= r5) goto L_0x010c
            r0 = r35
            int r4 = r0.mMinWidth
        L_0x010c:
            r0 = r35
            int r5 = r0.mHeight
            r0 = r35
            int r7 = r0.mMinHeight
            if (r5 >= r7) goto L_0x011a
            r0 = r35
            int r5 = r0.mMinHeight
        L_0x011a:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r7 = r0.mListDimensionBehaviors
            r8 = 0
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r8 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r7 == r8) goto L_0x026c
            r7 = 1
        L_0x0126:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r8 = r0.mListDimensionBehaviors
            r9 = 1
            r8 = r8[r9]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r9 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r8 == r9) goto L_0x026f
            r8 = 1
        L_0x0132:
            r11 = 0
            r0 = r35
            int r9 = r0.mDimensionRatioSide
            r0 = r35
            r0.mResolvedDimensionRatioSide = r9
            r0 = r35
            float r9 = r0.mDimensionRatio
            r0 = r35
            r0.mResolvedDimensionRatio = r9
            r0 = r35
            int r9 = r0.mMatchConstraintDefaultWidth
            r0 = r35
            int r10 = r0.mMatchConstraintDefaultHeight
            r0 = r35
            float r12 = r0.mDimensionRatio
            r13 = 0
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 <= 0) goto L_0x0446
            r0 = r35
            int r12 = r0.mVisibility
            r13 = 8
            if (r12 == r13) goto L_0x0446
            r12 = 1
            r13 = 1
            r11 = 1
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r14 = r0.mListDimensionBehaviors
            r15 = 0
            r14 = r14[r15]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r15 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r14 != r15) goto L_0x016d
            if (r9 != 0) goto L_0x016d
            r9 = 3
        L_0x016d:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r14 = r0.mListDimensionBehaviors
            r15 = 1
            r14 = r14[r15]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r15 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r14 != r15) goto L_0x017b
            if (r10 != 0) goto L_0x017b
            r10 = 3
        L_0x017b:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r14 = r0.mListDimensionBehaviors
            r15 = 0
            r14 = r14[r15]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r15 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r14 != r15) goto L_0x0272
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r14 = r0.mListDimensionBehaviors
            r15 = 1
            r14 = r14[r15]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r15 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r14 != r15) goto L_0x0272
            r14 = 3
            if (r9 != r14) goto L_0x0272
            r14 = 3
            if (r10 != r14) goto L_0x0272
            r0 = r35
            r1 = r25
            r0.setupDimensionRatio(r6, r1, r7, r8)
            r7 = r11
        L_0x019f:
            r27 = r7
            r14 = r4
            r28 = r10
            r20 = r9
            r29 = r5
        L_0x01a8:
            r0 = r35
            int[] r4 = r0.mResolvedMatchConstraintDefault
            r5 = 0
            r4[r5] = r20
            r0 = r35
            int[] r4 = r0.mResolvedMatchConstraintDefault
            r5 = 1
            r4[r5] = r28
            if (r27 == 0) goto L_0x02ed
            r0 = r35
            int r4 = r0.mResolvedDimensionRatioSide
            if (r4 == 0) goto L_0x01c5
            r0 = r35
            int r4 = r0.mResolvedDimensionRatioSide
            r5 = -1
            if (r4 != r5) goto L_0x02ed
        L_0x01c5:
            r18 = 1
        L_0x01c7:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r4 = r0.mListDimensionBehaviors
            r5 = 0
            r4 = r4[r5]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r5 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r4 != r5) goto L_0x02f1
            r0 = r35
            boolean r4 = r0 instanceof android.support.constraint.solver.widgets.ConstraintWidgetContainer
            if (r4 == 0) goto L_0x02f1
            r10 = 1
        L_0x01d9:
            r24 = 1
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mCenter
            boolean r4 = r4.isConnected()
            if (r4 == 0) goto L_0x01e7
            r24 = 0
        L_0x01e7:
            r0 = r35
            int r4 = r0.mHorizontalResolution
            r5 = 2
            if (r4 == r5) goto L_0x024f
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            if (r4 == 0) goto L_0x02f4
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.mRight
            r0 = r36
            android.support.constraint.solver.SolverVariable r8 = r0.createObjectVariable(r4)
        L_0x0200:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            if (r4 == 0) goto L_0x02f7
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.mLeft
            r0 = r36
            android.support.constraint.solver.SolverVariable r7 = r0.createObjectVariable(r4)
        L_0x0212:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r4 = r0.mListDimensionBehaviors
            r5 = 0
            r9 = r4[r5]
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r11 = r0.mLeft
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r12 = r0.mRight
            r0 = r35
            int r13 = r0.f5mX
            r0 = r35
            int r15 = r0.mMinWidth
            r0 = r35
            int[] r4 = r0.mMaxDimension
            r5 = 0
            r16 = r4[r5]
            r0 = r35
            float r0 = r0.mHorizontalBiasPercent
            r17 = r0
            r0 = r35
            int r0 = r0.mMatchConstraintMinWidth
            r21 = r0
            r0 = r35
            int r0 = r0.mMatchConstraintMaxWidth
            r22 = r0
            r0 = r35
            float r0 = r0.mMatchConstraintPercentWidth
            r23 = r0
            r4 = r35
            r5 = r36
            r4.applyConstraints(r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24)
        L_0x024f:
            r0 = r35
            int r4 = r0.mVerticalResolution
            r5 = 2
            if (r4 != r5) goto L_0x02fa
        L_0x0256:
            return
        L_0x0257:
            r4 = 0
            r5 = r4
            goto L_0x0051
        L_0x025b:
            r4 = 0
            r7 = r4
            goto L_0x0066
        L_0x025f:
            boolean r4 = r35.isInHorizontalChain()
            r8 = r4
            goto L_0x007d
        L_0x0266:
            boolean r4 = r35.isInVerticalChain()
            goto L_0x0093
        L_0x026c:
            r7 = 0
            goto L_0x0126
        L_0x026f:
            r8 = 0
            goto L_0x0132
        L_0x0272:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r7 = r0.mListDimensionBehaviors
            r8 = 0
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r8 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r7 != r8) goto L_0x02a2
            r7 = 3
            if (r9 != r7) goto L_0x02a2
            r4 = 0
            r0 = r35
            r0.mResolvedDimensionRatioSide = r4
            r0 = r35
            float r4 = r0.mResolvedDimensionRatio
            r0 = r35
            int r7 = r0.mHeight
            float r7 = (float) r7
            float r4 = r4 * r7
            int r4 = (int) r4
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r7 = r0.mListDimensionBehaviors
            r8 = 1
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r8 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r7 == r8) goto L_0x029f
            r7 = 0
            r9 = 4
            goto L_0x019f
        L_0x029f:
            r7 = r12
            goto L_0x019f
        L_0x02a2:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r7 = r0.mListDimensionBehaviors
            r8 = 1
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r8 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r7 != r8) goto L_0x0446
            r7 = 3
            if (r10 != r7) goto L_0x0446
            r5 = 1
            r0 = r35
            r0.mResolvedDimensionRatioSide = r5
            r0 = r35
            int r5 = r0.mDimensionRatioSide
            r7 = -1
            if (r5 != r7) goto L_0x02c7
            r5 = 1065353216(0x3f800000, float:1.0)
            r0 = r35
            float r7 = r0.mResolvedDimensionRatio
            float r5 = r5 / r7
            r0 = r35
            r0.mResolvedDimensionRatio = r5
        L_0x02c7:
            r0 = r35
            float r5 = r0.mResolvedDimensionRatio
            r0 = r35
            int r7 = r0.mWidth
            float r7 = (float) r7
            float r5 = r5 * r7
            int r5 = (int) r5
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r7 = r0.mListDimensionBehaviors
            r8 = 0
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r8 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r7 == r8) goto L_0x02ea
            r7 = 0
            r10 = 4
            r27 = r7
            r14 = r4
            r28 = r10
            r20 = r9
            r29 = r5
            goto L_0x01a8
        L_0x02ea:
            r7 = r13
            goto L_0x019f
        L_0x02ed:
            r18 = 0
            goto L_0x01c7
        L_0x02f1:
            r10 = 0
            goto L_0x01d9
        L_0x02f4:
            r8 = 0
            goto L_0x0200
        L_0x02f7:
            r7 = 0
            goto L_0x0212
        L_0x02fa:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r4 = r0.mListDimensionBehaviors
            r5 = 1
            r4 = r4[r5]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r5 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r4 != r5) goto L_0x03f6
            r0 = r35
            boolean r4 = r0 instanceof android.support.constraint.solver.widgets.ConstraintWidgetContainer
            if (r4 == 0) goto L_0x03f6
            r10 = 1
        L_0x030c:
            if (r27 == 0) goto L_0x03f9
            r0 = r35
            int r4 = r0.mResolvedDimensionRatioSide
            r5 = 1
            if (r4 == r5) goto L_0x031c
            r0 = r35
            int r4 = r0.mResolvedDimensionRatioSide
            r5 = -1
            if (r4 != r5) goto L_0x03f9
        L_0x031c:
            r18 = 1
        L_0x031e:
            r0 = r35
            int r4 = r0.mBaselineDistance
            if (r4 <= 0) goto L_0x033e
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mBaseline
            android.support.constraint.solver.widgets.ResolutionAnchor r4 = r4.getResolutionNode()
            int r4 = r4.state
            r5 = 1
            if (r4 != r5) goto L_0x03fd
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mBaseline
            android.support.constraint.solver.widgets.ResolutionAnchor r4 = r4.getResolutionNode()
            r0 = r36
            r4.addResolvedValue(r0)
        L_0x033e:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            if (r4 == 0) goto L_0x042c
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.mBottom
            r0 = r36
            android.support.constraint.solver.SolverVariable r8 = r0.createObjectVariable(r4)
        L_0x0350:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            if (r4 == 0) goto L_0x042f
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mParent
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.mTop
            r0 = r36
            android.support.constraint.solver.SolverVariable r7 = r0.createObjectVariable(r4)
        L_0x0362:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r4 = r0.mListDimensionBehaviors
            r5 = 1
            r9 = r4[r5]
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r11 = r0.mTop
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r12 = r0.mBottom
            r0 = r35
            int r13 = r0.f6mY
            r0 = r35
            int r15 = r0.mMinHeight
            r0 = r35
            int[] r4 = r0.mMaxDimension
            r5 = 1
            r16 = r4[r5]
            r0 = r35
            float r0 = r0.mVerticalBiasPercent
            r17 = r0
            r0 = r35
            int r0 = r0.mMatchConstraintMinHeight
            r21 = r0
            r0 = r35
            int r0 = r0.mMatchConstraintMaxHeight
            r22 = r0
            r0 = r35
            float r0 = r0.mMatchConstraintPercentHeight
            r23 = r0
            r4 = r35
            r5 = r36
            r6 = r25
            r14 = r29
            r19 = r26
            r20 = r28
            r4.applyConstraints(r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24)
            if (r27 == 0) goto L_0x03c2
            r0 = r35
            int r4 = r0.mResolvedDimensionRatioSide
            r5 = 1
            if (r4 != r5) goto L_0x0432
            r0 = r35
            float r9 = r0.mResolvedDimensionRatio
            r10 = 6
            r4 = r36
            r5 = r33
            r6 = r32
            r7 = r31
            r8 = r30
            r4.addRatio(r5, r6, r7, r8, r9, r10)
        L_0x03c2:
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mCenter
            boolean r4 = r4.isConnected()
            if (r4 == 0) goto L_0x0256
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mCenter
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.getTarget()
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r4.getOwner()
            r0 = r35
            float r5 = r0.mCircleConstraintAngle
            r6 = 1119092736(0x42b40000, float:90.0)
            float r5 = r5 + r6
            double r6 = (double) r5
            double r6 = java.lang.Math.toRadians(r6)
            float r5 = (float) r6
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r0.mCenter
            int r6 = r6.getMargin()
            r0 = r36
            r1 = r35
            r0.addCenterPoint(r1, r4, r5, r6)
            goto L_0x0256
        L_0x03f6:
            r10 = 0
            goto L_0x030c
        L_0x03f9:
            r18 = 0
            goto L_0x031e
        L_0x03fd:
            int r4 = r35.getBaselineDistance()
            r5 = 6
            r0 = r36
            r1 = r34
            r2 = r32
            r0.addEquality(r1, r2, r4, r5)
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mBaseline
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.mTarget
            if (r4 == 0) goto L_0x033e
            r0 = r35
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r0.mBaseline
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.mTarget
            r0 = r36
            android.support.constraint.solver.SolverVariable r4 = r0.createObjectVariable(r4)
            r5 = 0
            r6 = 6
            r0 = r36
            r1 = r34
            r0.addEquality(r1, r4, r5, r6)
            r24 = 0
            goto L_0x033e
        L_0x042c:
            r8 = 0
            goto L_0x0350
        L_0x042f:
            r7 = 0
            goto L_0x0362
        L_0x0432:
            r0 = r35
            float r9 = r0.mResolvedDimensionRatio
            r10 = 6
            r4 = r36
            r5 = r31
            r6 = r30
            r7 = r33
            r8 = r32
            r4.addRatio(r5, r6, r7, r8, r9, r10)
            goto L_0x03c2
        L_0x0446:
            r7 = r11
            goto L_0x019f
        L_0x0449:
            r25 = r7
            r6 = r5
            r26 = r4
            r19 = r8
            goto L_0x00fe
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.solver.widgets.ConstraintWidget.addToSolver(android.support.constraint.solver.LinearSystem):void");
    }

    public boolean allowedInBarrier() {
        return this.mVisibility != 8;
    }

    public void analyze(int i) {
        Optimizer.analyze(i, this);
    }

    public void connect(ConstraintAnchor.Type type, ConstraintWidget constraintWidget, ConstraintAnchor.Type type2) {
        connect(type, constraintWidget, type2, 0, ConstraintAnchor.Strength.STRONG);
    }

    public void connect(ConstraintAnchor.Type type, ConstraintWidget constraintWidget, ConstraintAnchor.Type type2, int i) {
        connect(type, constraintWidget, type2, i, ConstraintAnchor.Strength.STRONG);
    }

    public void connect(ConstraintAnchor.Type type, ConstraintWidget constraintWidget, ConstraintAnchor.Type type2, int i, ConstraintAnchor.Strength strength) {
        connect(type, constraintWidget, type2, i, strength, 0);
    }

    public void connect(ConstraintAnchor.Type type, ConstraintWidget constraintWidget, ConstraintAnchor.Type type2, int i, ConstraintAnchor.Strength strength, int i2) {
        boolean z;
        boolean z2;
        if (type == ConstraintAnchor.Type.CENTER) {
            if (type2 == ConstraintAnchor.Type.CENTER) {
                ConstraintAnchor anchor = getAnchor(ConstraintAnchor.Type.LEFT);
                ConstraintAnchor anchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
                ConstraintAnchor anchor3 = getAnchor(ConstraintAnchor.Type.TOP);
                ConstraintAnchor anchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
                if (anchor != null && anchor.isConnected()) {
                    z = false;
                } else if (anchor2 == null || !anchor2.isConnected()) {
                    connect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.LEFT, 0, strength, i2);
                    connect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.RIGHT, 0, strength, i2);
                    z = true;
                } else {
                    z = false;
                }
                if (anchor3 != null && anchor3.isConnected()) {
                    z2 = false;
                } else if (anchor4 == null || !anchor4.isConnected()) {
                    connect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.TOP, 0, strength, i2);
                    connect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.BOTTOM, 0, strength, i2);
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (z && z2) {
                    getAnchor(ConstraintAnchor.Type.CENTER).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.CENTER), 0, i2);
                } else if (z) {
                    getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_X), 0, i2);
                } else if (z2) {
                    getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_Y), 0, i2);
                }
            } else if (type2 == ConstraintAnchor.Type.LEFT || type2 == ConstraintAnchor.Type.RIGHT) {
                connect(ConstraintAnchor.Type.LEFT, constraintWidget, type2, 0, strength, i2);
                connect(ConstraintAnchor.Type.RIGHT, constraintWidget, type2, 0, strength, i2);
                getAnchor(ConstraintAnchor.Type.CENTER).connect(constraintWidget.getAnchor(type2), 0, i2);
            } else if (type2 == ConstraintAnchor.Type.TOP || type2 == ConstraintAnchor.Type.BOTTOM) {
                connect(ConstraintAnchor.Type.TOP, constraintWidget, type2, 0, strength, i2);
                connect(ConstraintAnchor.Type.BOTTOM, constraintWidget, type2, 0, strength, i2);
                getAnchor(ConstraintAnchor.Type.CENTER).connect(constraintWidget.getAnchor(type2), 0, i2);
            }
        } else if (type == ConstraintAnchor.Type.CENTER_X && (type2 == ConstraintAnchor.Type.LEFT || type2 == ConstraintAnchor.Type.RIGHT)) {
            ConstraintAnchor anchor5 = getAnchor(ConstraintAnchor.Type.LEFT);
            ConstraintAnchor anchor6 = constraintWidget.getAnchor(type2);
            ConstraintAnchor anchor7 = getAnchor(ConstraintAnchor.Type.RIGHT);
            anchor5.connect(anchor6, 0, i2);
            anchor7.connect(anchor6, 0, i2);
            getAnchor(ConstraintAnchor.Type.CENTER_X).connect(anchor6, 0, i2);
        } else if (type == ConstraintAnchor.Type.CENTER_Y && (type2 == ConstraintAnchor.Type.TOP || type2 == ConstraintAnchor.Type.BOTTOM)) {
            ConstraintAnchor anchor8 = constraintWidget.getAnchor(type2);
            getAnchor(ConstraintAnchor.Type.TOP).connect(anchor8, 0, i2);
            getAnchor(ConstraintAnchor.Type.BOTTOM).connect(anchor8, 0, i2);
            getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(anchor8, 0, i2);
        } else if (type == ConstraintAnchor.Type.CENTER_X && type2 == ConstraintAnchor.Type.CENTER_X) {
            getAnchor(ConstraintAnchor.Type.LEFT).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.LEFT), 0, i2);
            getAnchor(ConstraintAnchor.Type.RIGHT).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT), 0, i2);
            getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintWidget.getAnchor(type2), 0, i2);
        } else if (type == ConstraintAnchor.Type.CENTER_Y && type2 == ConstraintAnchor.Type.CENTER_Y) {
            getAnchor(ConstraintAnchor.Type.TOP).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.TOP), 0, i2);
            getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM), 0, i2);
            getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintWidget.getAnchor(type2), 0, i2);
        } else {
            ConstraintAnchor anchor9 = getAnchor(type);
            ConstraintAnchor anchor10 = constraintWidget.getAnchor(type2);
            if (anchor9.isValidConnection(anchor10)) {
                if (type == ConstraintAnchor.Type.BASELINE) {
                    ConstraintAnchor anchor11 = getAnchor(ConstraintAnchor.Type.TOP);
                    ConstraintAnchor anchor12 = getAnchor(ConstraintAnchor.Type.BOTTOM);
                    if (anchor11 != null) {
                        anchor11.reset();
                    }
                    if (anchor12 != null) {
                        anchor12.reset();
                    }
                    i = 0;
                } else if (type == ConstraintAnchor.Type.TOP || type == ConstraintAnchor.Type.BOTTOM) {
                    ConstraintAnchor anchor13 = getAnchor(ConstraintAnchor.Type.BASELINE);
                    if (anchor13 != null) {
                        anchor13.reset();
                    }
                    ConstraintAnchor anchor14 = getAnchor(ConstraintAnchor.Type.CENTER);
                    if (anchor14.getTarget() != anchor10) {
                        anchor14.reset();
                    }
                    ConstraintAnchor opposite = getAnchor(type).getOpposite();
                    ConstraintAnchor anchor15 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
                    if (anchor15.isConnected()) {
                        opposite.reset();
                        anchor15.reset();
                    }
                } else if (type == ConstraintAnchor.Type.LEFT || type == ConstraintAnchor.Type.RIGHT) {
                    ConstraintAnchor anchor16 = getAnchor(ConstraintAnchor.Type.CENTER);
                    if (anchor16.getTarget() != anchor10) {
                        anchor16.reset();
                    }
                    ConstraintAnchor opposite2 = getAnchor(type).getOpposite();
                    ConstraintAnchor anchor17 = getAnchor(ConstraintAnchor.Type.CENTER_X);
                    if (anchor17.isConnected()) {
                        opposite2.reset();
                        anchor17.reset();
                    }
                }
                anchor9.connect(anchor10, i, strength, i2);
                anchor10.getOwner().connectedTo(anchor9.getOwner());
            }
        }
    }

    public void connect(ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, int i) {
        connect(constraintAnchor, constraintAnchor2, i, ConstraintAnchor.Strength.STRONG, 0);
    }

    public void connect(ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, int i, int i2) {
        connect(constraintAnchor, constraintAnchor2, i, ConstraintAnchor.Strength.STRONG, i2);
    }

    public void connect(ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, int i, ConstraintAnchor.Strength strength, int i2) {
        if (constraintAnchor.getOwner() == this) {
            connect(constraintAnchor.getType(), constraintAnchor2.getOwner(), constraintAnchor2.getType(), i, strength, i2);
        }
    }

    public void connectCircularConstraint(ConstraintWidget constraintWidget, float f, int i) {
        immediateConnect(ConstraintAnchor.Type.CENTER, constraintWidget, ConstraintAnchor.Type.CENTER, i, 0);
        this.mCircleConstraintAngle = f;
    }

    public void connectedTo(ConstraintWidget constraintWidget) {
    }

    public void createObjectVariables(LinearSystem linearSystem) {
        linearSystem.createObjectVariable(this.mLeft);
        linearSystem.createObjectVariable(this.mTop);
        linearSystem.createObjectVariable(this.mRight);
        linearSystem.createObjectVariable(this.mBottom);
        if (this.mBaselineDistance > 0) {
            linearSystem.createObjectVariable(this.mBaseline);
        }
    }

    public void disconnectUnlockedWidget(ConstraintWidget constraintWidget) {
        ArrayList<ConstraintAnchor> anchors = getAnchors();
        int size = anchors.size();
        for (int i = 0; i < size; i++) {
            ConstraintAnchor constraintAnchor = anchors.get(i);
            if (constraintAnchor.isConnected() && constraintAnchor.getTarget().getOwner() == constraintWidget && constraintAnchor.getConnectionCreator() == 2) {
                constraintAnchor.reset();
            }
        }
    }

    public void disconnectWidget(ConstraintWidget constraintWidget) {
        ArrayList<ConstraintAnchor> anchors = getAnchors();
        int size = anchors.size();
        for (int i = 0; i < size; i++) {
            ConstraintAnchor constraintAnchor = anchors.get(i);
            if (constraintAnchor.isConnected() && constraintAnchor.getTarget().getOwner() == constraintWidget) {
                constraintAnchor.reset();
            }
        }
    }

    public void forceUpdateDrawPosition() {
        int i = this.f5mX;
        int i2 = this.f6mY;
        int i3 = this.f5mX;
        int i4 = this.mWidth;
        int i5 = this.f6mY;
        int i6 = this.mHeight;
        this.mDrawX = i;
        this.mDrawY = i2;
        this.mDrawWidth = (i3 + i4) - i;
        this.mDrawHeight = (i5 + i6) - i2;
    }

    public ConstraintAnchor getAnchor(ConstraintAnchor.Type type) {
        switch (type) {
            case LEFT:
                return this.mLeft;
            case TOP:
                return this.mTop;
            case RIGHT:
                return this.mRight;
            case BOTTOM:
                return this.mBottom;
            case BASELINE:
                return this.mBaseline;
            case CENTER:
                return this.mCenter;
            case CENTER_X:
                return this.mCenterX;
            case CENTER_Y:
                return this.mCenterY;
            case NONE:
                return null;
            default:
                throw new AssertionError(type.name());
        }
    }

    public ArrayList<ConstraintAnchor> getAnchors() {
        return this.mAnchors;
    }

    public int getBaselineDistance() {
        return this.mBaselineDistance;
    }

    public float getBiasPercent(int i) {
        if (i == 0) {
            return this.mHorizontalBiasPercent;
        }
        if (i == 1) {
            return this.mVerticalBiasPercent;
        }
        return -1.0f;
    }

    public int getBottom() {
        return getY() + this.mHeight;
    }

    public Object getCompanionWidget() {
        return this.mCompanionWidget;
    }

    public int getContainerItemSkip() {
        return this.mContainerItemSkip;
    }

    public String getDebugName() {
        return this.mDebugName;
    }

    public DimensionBehaviour getDimensionBehaviour(int i) {
        if (i == 0) {
            return getHorizontalDimensionBehaviour();
        }
        if (i == 1) {
            return getVerticalDimensionBehaviour();
        }
        return null;
    }

    public float getDimensionRatio() {
        return this.mDimensionRatio;
    }

    public int getDimensionRatioSide() {
        return this.mDimensionRatioSide;
    }

    public int getDrawBottom() {
        return getDrawY() + this.mDrawHeight;
    }

    public int getDrawHeight() {
        return this.mDrawHeight;
    }

    public int getDrawRight() {
        return getDrawX() + this.mDrawWidth;
    }

    public int getDrawWidth() {
        return this.mDrawWidth;
    }

    public int getDrawX() {
        return this.mDrawX + this.mOffsetX;
    }

    public int getDrawY() {
        return this.mDrawY + this.mOffsetY;
    }

    public int getHeight() {
        if (this.mVisibility == 8) {
            return 0;
        }
        return this.mHeight;
    }

    public float getHorizontalBiasPercent() {
        return this.mHorizontalBiasPercent;
    }

    public ConstraintWidget getHorizontalChainControlWidget() {
        if (!isInHorizontalChain()) {
            return null;
        }
        ConstraintWidget constraintWidget = this;
        ConstraintWidget constraintWidget2 = null;
        while (constraintWidget2 == null && constraintWidget != null) {
            ConstraintAnchor anchor = constraintWidget.getAnchor(ConstraintAnchor.Type.LEFT);
            ConstraintAnchor target = anchor == null ? null : anchor.getTarget();
            ConstraintWidget owner = target == null ? null : target.getOwner();
            if (owner == getParent()) {
                return constraintWidget;
            }
            ConstraintAnchor target2 = owner == null ? null : owner.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
            if (!(target2 == null || target2.getOwner() == constraintWidget)) {
                owner = constraintWidget;
                constraintWidget2 = constraintWidget;
            }
            constraintWidget = owner;
        }
        return constraintWidget2;
    }

    public int getHorizontalChainStyle() {
        return this.mHorizontalChainStyle;
    }

    public DimensionBehaviour getHorizontalDimensionBehaviour() {
        return this.mListDimensionBehaviors[0];
    }

    public int getInternalDrawBottom() {
        return this.mDrawY + this.mDrawHeight;
    }

    public int getInternalDrawRight() {
        return this.mDrawX + this.mDrawWidth;
    }

    /* access modifiers changed from: package-private */
    public int getInternalDrawX() {
        return this.mDrawX;
    }

    /* access modifiers changed from: package-private */
    public int getInternalDrawY() {
        return this.mDrawY;
    }

    public int getLeft() {
        return getX();
    }

    public int getLength(int i) {
        if (i == 0) {
            return getWidth();
        }
        if (i == 1) {
            return getHeight();
        }
        return 0;
    }

    public int getMaxHeight() {
        return this.mMaxDimension[1];
    }

    public int getMaxWidth() {
        return this.mMaxDimension[0];
    }

    public int getMinHeight() {
        return this.mMinHeight;
    }

    public int getMinWidth() {
        return this.mMinWidth;
    }

    public int getOptimizerWrapHeight() {
        int i;
        int i2 = this.mHeight;
        if (this.mListDimensionBehaviors[1] != DimensionBehaviour.MATCH_CONSTRAINT) {
            return i2;
        }
        if (this.mMatchConstraintDefaultHeight == 1) {
            i = Math.max(this.mMatchConstraintMinHeight, i2);
        } else if (this.mMatchConstraintMinHeight > 0) {
            i = this.mMatchConstraintMinHeight;
            this.mHeight = i;
        } else {
            i = 0;
        }
        return (this.mMatchConstraintMaxHeight <= 0 || this.mMatchConstraintMaxHeight >= i) ? i : this.mMatchConstraintMaxHeight;
    }

    public int getOptimizerWrapWidth() {
        int i = 0;
        int i2 = this.mWidth;
        if (this.mListDimensionBehaviors[0] != DimensionBehaviour.MATCH_CONSTRAINT) {
            return i2;
        }
        if (this.mMatchConstraintDefaultWidth == 1) {
            i = Math.max(this.mMatchConstraintMinWidth, i2);
        } else if (this.mMatchConstraintMinWidth > 0) {
            i = this.mMatchConstraintMinWidth;
            this.mWidth = i;
        }
        return (this.mMatchConstraintMaxWidth <= 0 || this.mMatchConstraintMaxWidth >= i) ? i : this.mMatchConstraintMaxWidth;
    }

    public ConstraintWidget getParent() {
        return this.mParent;
    }

    /* access modifiers changed from: package-private */
    public int getRelativePositioning(int i) {
        if (i == 0) {
            return this.mRelX;
        }
        if (i == 1) {
            return this.mRelY;
        }
        return 0;
    }

    public ResolutionDimension getResolutionHeight() {
        if (this.mResolutionHeight == null) {
            this.mResolutionHeight = new ResolutionDimension();
        }
        return this.mResolutionHeight;
    }

    public ResolutionDimension getResolutionWidth() {
        if (this.mResolutionWidth == null) {
            this.mResolutionWidth = new ResolutionDimension();
        }
        return this.mResolutionWidth;
    }

    public int getRight() {
        return getX() + this.mWidth;
    }

    public WidgetContainer getRootWidgetContainer() {
        ConstraintWidget constraintWidget = this;
        while (constraintWidget.getParent() != null) {
            constraintWidget = constraintWidget.getParent();
        }
        if (constraintWidget instanceof WidgetContainer) {
            return (WidgetContainer) constraintWidget;
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public int getRootX() {
        return this.f5mX + this.mOffsetX;
    }

    /* access modifiers changed from: protected */
    public int getRootY() {
        return this.f6mY + this.mOffsetY;
    }

    public int getTop() {
        return getY();
    }

    public String getType() {
        return this.mType;
    }

    public float getVerticalBiasPercent() {
        return this.mVerticalBiasPercent;
    }

    public ConstraintWidget getVerticalChainControlWidget() {
        if (!isInVerticalChain()) {
            return null;
        }
        ConstraintWidget constraintWidget = this;
        ConstraintWidget constraintWidget2 = null;
        while (constraintWidget2 == null && constraintWidget != null) {
            ConstraintAnchor anchor = constraintWidget.getAnchor(ConstraintAnchor.Type.TOP);
            ConstraintAnchor target = anchor == null ? null : anchor.getTarget();
            ConstraintWidget owner = target == null ? null : target.getOwner();
            if (owner == getParent()) {
                return constraintWidget;
            }
            ConstraintAnchor target2 = owner == null ? null : owner.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
            if (!(target2 == null || target2.getOwner() == constraintWidget)) {
                owner = constraintWidget;
                constraintWidget2 = constraintWidget;
            }
            constraintWidget = owner;
        }
        return constraintWidget2;
    }

    public int getVerticalChainStyle() {
        return this.mVerticalChainStyle;
    }

    public DimensionBehaviour getVerticalDimensionBehaviour() {
        return this.mListDimensionBehaviors[1];
    }

    public int getVisibility() {
        return this.mVisibility;
    }

    public int getWidth() {
        if (this.mVisibility == 8) {
            return 0;
        }
        return this.mWidth;
    }

    public int getWrapHeight() {
        return this.mWrapHeight;
    }

    public int getWrapWidth() {
        return this.mWrapWidth;
    }

    public int getX() {
        return this.f5mX;
    }

    public int getY() {
        return this.f6mY;
    }

    public boolean hasAncestor(ConstraintWidget constraintWidget) {
        ConstraintWidget parent = getParent();
        if (parent == constraintWidget) {
            return true;
        }
        if (parent == constraintWidget.getParent()) {
            return false;
        }
        while (parent != null) {
            if (parent == constraintWidget || parent == constraintWidget.getParent()) {
                return true;
            }
            parent = parent.getParent();
        }
        return false;
    }

    public boolean hasBaseline() {
        return this.mBaselineDistance > 0;
    }

    public void immediateConnect(ConstraintAnchor.Type type, ConstraintWidget constraintWidget, ConstraintAnchor.Type type2, int i, int i2) {
        getAnchor(type).connect(constraintWidget.getAnchor(type2), i, i2, ConstraintAnchor.Strength.STRONG, 0, true);
    }

    public boolean isFullyResolved() {
        return this.mLeft.getResolutionNode().state == 1 && this.mRight.getResolutionNode().state == 1 && this.mTop.getResolutionNode().state == 1 && this.mBottom.getResolutionNode().state == 1;
    }

    public boolean isHeightWrapContent() {
        return this.mIsHeightWrapContent;
    }

    public boolean isInHorizontalChain() {
        return (this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight);
    }

    public boolean isInVerticalChain() {
        return (this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom);
    }

    public boolean isInsideConstraintLayout() {
        ConstraintWidget parent = getParent();
        if (parent == null) {
            return false;
        }
        while (parent != null) {
            if (parent instanceof ConstraintWidgetContainer) {
                return true;
            }
            parent = parent.getParent();
        }
        return false;
    }

    public boolean isRoot() {
        return this.mParent == null;
    }

    public boolean isRootContainer() {
        return (this instanceof ConstraintWidgetContainer) && (this.mParent == null || !(this.mParent instanceof ConstraintWidgetContainer));
    }

    public boolean isSpreadHeight() {
        return this.mMatchConstraintDefaultHeight == 0 && this.mDimensionRatio == 0.0f && this.mMatchConstraintMinHeight == 0 && this.mMatchConstraintMaxHeight == 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT;
    }

    public boolean isSpreadWidth() {
        return this.mMatchConstraintDefaultWidth == 0 && this.mDimensionRatio == 0.0f && this.mMatchConstraintMinWidth == 0 && this.mMatchConstraintMaxWidth == 0 && this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT;
    }

    public boolean isWidthWrapContent() {
        return this.mIsWidthWrapContent;
    }

    public void reset() {
        this.mLeft.reset();
        this.mTop.reset();
        this.mRight.reset();
        this.mBottom.reset();
        this.mBaseline.reset();
        this.mCenterX.reset();
        this.mCenterY.reset();
        this.mCenter.reset();
        this.mParent = null;
        this.mCircleConstraintAngle = 0.0f;
        this.mWidth = 0;
        this.mHeight = 0;
        this.mDimensionRatio = 0.0f;
        this.mDimensionRatioSide = -1;
        this.f5mX = 0;
        this.f6mY = 0;
        this.mDrawX = 0;
        this.mDrawY = 0;
        this.mDrawWidth = 0;
        this.mDrawHeight = 0;
        this.mOffsetX = 0;
        this.mOffsetY = 0;
        this.mBaselineDistance = 0;
        this.mMinWidth = 0;
        this.mMinHeight = 0;
        this.mWrapWidth = 0;
        this.mWrapHeight = 0;
        this.mHorizontalBiasPercent = DEFAULT_BIAS;
        this.mVerticalBiasPercent = DEFAULT_BIAS;
        this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
        this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
        this.mCompanionWidget = null;
        this.mContainerItemSkip = 0;
        this.mVisibility = 0;
        this.mType = null;
        this.mHorizontalWrapVisited = false;
        this.mVerticalWrapVisited = false;
        this.mHorizontalChainStyle = 0;
        this.mVerticalChainStyle = 0;
        this.mHorizontalChainFixedPosition = false;
        this.mVerticalChainFixedPosition = false;
        this.mWeight[0] = -1.0f;
        this.mWeight[1] = -1.0f;
        this.mHorizontalResolution = -1;
        this.mVerticalResolution = -1;
        this.mMaxDimension[0] = Integer.MAX_VALUE;
        this.mMaxDimension[1] = Integer.MAX_VALUE;
        this.mMatchConstraintDefaultWidth = 0;
        this.mMatchConstraintDefaultHeight = 0;
        this.mMatchConstraintPercentWidth = 1.0f;
        this.mMatchConstraintPercentHeight = 1.0f;
        this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
        this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
        this.mMatchConstraintMinWidth = 0;
        this.mMatchConstraintMinHeight = 0;
        this.mResolvedDimensionRatioSide = -1;
        this.mResolvedDimensionRatio = 1.0f;
        if (this.mResolutionWidth != null) {
            this.mResolutionWidth.reset();
        }
        if (this.mResolutionHeight != null) {
            this.mResolutionHeight.reset();
        }
        this.mBelongingGroup = null;
        this.mOptimizerMeasurable = false;
        this.mOptimizerMeasured = false;
        this.mGroupsToSolver = false;
    }

    public void resetAllConstraints() {
        resetAnchors();
        setVerticalBiasPercent(DEFAULT_BIAS);
        setHorizontalBiasPercent(DEFAULT_BIAS);
        if (!(this instanceof ConstraintWidgetContainer)) {
            if (getHorizontalDimensionBehaviour() == DimensionBehaviour.MATCH_CONSTRAINT) {
                if (getWidth() == getWrapWidth()) {
                    setHorizontalDimensionBehaviour(DimensionBehaviour.WRAP_CONTENT);
                } else if (getWidth() > getMinWidth()) {
                    setHorizontalDimensionBehaviour(DimensionBehaviour.FIXED);
                }
            }
            if (getVerticalDimensionBehaviour() != DimensionBehaviour.MATCH_CONSTRAINT) {
                return;
            }
            if (getHeight() == getWrapHeight()) {
                setVerticalDimensionBehaviour(DimensionBehaviour.WRAP_CONTENT);
            } else if (getHeight() > getMinHeight()) {
                setVerticalDimensionBehaviour(DimensionBehaviour.FIXED);
            }
        }
    }

    public void resetAnchor(ConstraintAnchor constraintAnchor) {
        if (getParent() == null || !(getParent() instanceof ConstraintWidgetContainer) || !((ConstraintWidgetContainer) getParent()).handlesInternalConstraints()) {
            ConstraintAnchor anchor = getAnchor(ConstraintAnchor.Type.LEFT);
            ConstraintAnchor anchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
            ConstraintAnchor anchor3 = getAnchor(ConstraintAnchor.Type.TOP);
            ConstraintAnchor anchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
            ConstraintAnchor anchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
            ConstraintAnchor anchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
            ConstraintAnchor anchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
            if (constraintAnchor == anchor5) {
                if (anchor.isConnected() && anchor2.isConnected() && anchor.getTarget() == anchor2.getTarget()) {
                    anchor.reset();
                    anchor2.reset();
                }
                if (anchor3.isConnected() && anchor4.isConnected() && anchor3.getTarget() == anchor4.getTarget()) {
                    anchor3.reset();
                    anchor4.reset();
                }
                this.mHorizontalBiasPercent = 0.5f;
                this.mVerticalBiasPercent = 0.5f;
            } else if (constraintAnchor == anchor6) {
                if (anchor.isConnected() && anchor2.isConnected() && anchor.getTarget().getOwner() == anchor2.getTarget().getOwner()) {
                    anchor.reset();
                    anchor2.reset();
                }
                this.mHorizontalBiasPercent = 0.5f;
            } else if (constraintAnchor == anchor7) {
                if (anchor3.isConnected() && anchor4.isConnected() && anchor3.getTarget().getOwner() == anchor4.getTarget().getOwner()) {
                    anchor3.reset();
                    anchor4.reset();
                }
                this.mVerticalBiasPercent = 0.5f;
            } else if (constraintAnchor == anchor || constraintAnchor == anchor2) {
                if (anchor.isConnected() && anchor.getTarget() == anchor2.getTarget()) {
                    anchor5.reset();
                }
            } else if ((constraintAnchor == anchor3 || constraintAnchor == anchor4) && anchor3.isConnected() && anchor3.getTarget() == anchor4.getTarget()) {
                anchor5.reset();
            }
            constraintAnchor.reset();
        }
    }

    public void resetAnchors() {
        ConstraintWidget parent = getParent();
        if (parent == null || !(parent instanceof ConstraintWidgetContainer) || !((ConstraintWidgetContainer) getParent()).handlesInternalConstraints()) {
            int size = this.mAnchors.size();
            for (int i = 0; i < size; i++) {
                this.mAnchors.get(i).reset();
            }
        }
    }

    public void resetAnchors(int i) {
        ConstraintWidget parent = getParent();
        if (parent == null || !(parent instanceof ConstraintWidgetContainer) || !((ConstraintWidgetContainer) getParent()).handlesInternalConstraints()) {
            int size = this.mAnchors.size();
            for (int i2 = 0; i2 < size; i2++) {
                ConstraintAnchor constraintAnchor = this.mAnchors.get(i2);
                if (i == constraintAnchor.getConnectionCreator()) {
                    if (constraintAnchor.isVerticalAnchor()) {
                        setVerticalBiasPercent(DEFAULT_BIAS);
                    } else {
                        setHorizontalBiasPercent(DEFAULT_BIAS);
                    }
                    constraintAnchor.reset();
                }
            }
        }
    }

    public void resetResolutionNodes() {
        for (int i = 0; i < 6; i++) {
            this.mListAnchors[i].getResolutionNode().reset();
        }
    }

    public void resetSolverVariables(Cache cache) {
        this.mLeft.resetSolverVariable(cache);
        this.mTop.resetSolverVariable(cache);
        this.mRight.resetSolverVariable(cache);
        this.mBottom.resetSolverVariable(cache);
        this.mBaseline.resetSolverVariable(cache);
        this.mCenter.resetSolverVariable(cache);
        this.mCenterX.resetSolverVariable(cache);
        this.mCenterY.resetSolverVariable(cache);
    }

    public void resolve() {
    }

    public void setBaselineDistance(int i) {
        this.mBaselineDistance = i;
    }

    public void setCompanionWidget(Object obj) {
        this.mCompanionWidget = obj;
    }

    public void setContainerItemSkip(int i) {
        if (i >= 0) {
            this.mContainerItemSkip = i;
        } else {
            this.mContainerItemSkip = 0;
        }
    }

    public void setDebugName(String str) {
        this.mDebugName = str;
    }

    public void setDebugSolverName(LinearSystem linearSystem, String str) {
        this.mDebugName = str;
        SolverVariable createObjectVariable = linearSystem.createObjectVariable(this.mLeft);
        SolverVariable createObjectVariable2 = linearSystem.createObjectVariable(this.mTop);
        SolverVariable createObjectVariable3 = linearSystem.createObjectVariable(this.mRight);
        SolverVariable createObjectVariable4 = linearSystem.createObjectVariable(this.mBottom);
        createObjectVariable.setName(str + ".left");
        createObjectVariable2.setName(str + ".top");
        createObjectVariable3.setName(str + ".right");
        createObjectVariable4.setName(str + ".bottom");
        if (this.mBaselineDistance > 0) {
            SolverVariable createObjectVariable5 = linearSystem.createObjectVariable(this.mBaseline);
            createObjectVariable5.setName(str + ".baseline");
        }
    }

    public void setDimension(int i, int i2) {
        this.mWidth = i;
        if (this.mWidth < this.mMinWidth) {
            this.mWidth = this.mMinWidth;
        }
        this.mHeight = i2;
        if (this.mHeight < this.mMinHeight) {
            this.mHeight = this.mMinHeight;
        }
    }

    public void setDimensionRatio(float f, int i) {
        this.mDimensionRatio = f;
        this.mDimensionRatioSide = i;
    }

    public void setDimensionRatio(String str) {
        int i;
        int i2;
        float f;
        int i3 = 0;
        if (str == null || str.length() == 0) {
            this.mDimensionRatio = 0.0f;
            return;
        }
        int length = str.length();
        int indexOf = str.indexOf(44);
        if (indexOf <= 0 || indexOf >= length - 1) {
            i = 0;
            i2 = -1;
        } else {
            String substring = str.substring(0, indexOf);
            if (!substring.equalsIgnoreCase("W")) {
                i3 = substring.equalsIgnoreCase("H") ? 1 : -1;
            }
            i = indexOf + 1;
            i2 = i3;
        }
        int indexOf2 = str.indexOf(58);
        if (indexOf2 < 0 || indexOf2 >= length - 1) {
            String substring2 = str.substring(i);
            if (substring2.length() > 0) {
                try {
                    f = Float.parseFloat(substring2);
                } catch (NumberFormatException e) {
                    f = 0.0f;
                }
            }
            f = 0.0f;
        } else {
            String substring3 = str.substring(i, indexOf2);
            String substring4 = str.substring(indexOf2 + 1);
            if (substring3.length() > 0 && substring4.length() > 0) {
                try {
                    float parseFloat = Float.parseFloat(substring3);
                    float parseFloat2 = Float.parseFloat(substring4);
                    if (parseFloat > 0.0f && parseFloat2 > 0.0f) {
                        f = i2 == 1 ? Math.abs(parseFloat2 / parseFloat) : Math.abs(parseFloat / parseFloat2);
                    }
                } catch (NumberFormatException e2) {
                    f = 0.0f;
                }
            }
            f = 0.0f;
        }
        if (f > 0.0f) {
            this.mDimensionRatio = f;
            this.mDimensionRatioSide = i2;
        }
    }

    public void setDrawHeight(int i) {
        this.mDrawHeight = i;
    }

    public void setDrawOrigin(int i, int i2) {
        this.mDrawX = i - this.mOffsetX;
        this.mDrawY = i2 - this.mOffsetY;
        this.f5mX = this.mDrawX;
        this.f6mY = this.mDrawY;
    }

    public void setDrawWidth(int i) {
        this.mDrawWidth = i;
    }

    public void setDrawX(int i) {
        this.mDrawX = i - this.mOffsetX;
        this.f5mX = this.mDrawX;
    }

    public void setDrawY(int i) {
        this.mDrawY = i - this.mOffsetY;
        this.f6mY = this.mDrawY;
    }

    public void setFrame(int i, int i2, int i3) {
        if (i3 == 0) {
            setHorizontalDimension(i, i2);
        } else if (i3 == 1) {
            setVerticalDimension(i, i2);
        }
        this.mOptimizerMeasured = true;
    }

    public void setFrame(int i, int i2, int i3, int i4) {
        int i5 = i3 - i;
        int i6 = i4 - i2;
        this.f5mX = i;
        this.f6mY = i2;
        if (this.mVisibility == 8) {
            this.mWidth = 0;
            this.mHeight = 0;
            return;
        }
        if (this.mListDimensionBehaviors[0] == DimensionBehaviour.FIXED && i5 < this.mWidth) {
            i5 = this.mWidth;
        }
        if (this.mListDimensionBehaviors[1] == DimensionBehaviour.FIXED && i6 < this.mHeight) {
            i6 = this.mHeight;
        }
        this.mWidth = i5;
        this.mHeight = i6;
        if (this.mHeight < this.mMinHeight) {
            this.mHeight = this.mMinHeight;
        }
        if (this.mWidth < this.mMinWidth) {
            this.mWidth = this.mMinWidth;
        }
        this.mOptimizerMeasured = true;
    }

    public void setGoneMargin(ConstraintAnchor.Type type, int i) {
        switch (type) {
            case LEFT:
                this.mLeft.mGoneMargin = i;
                return;
            case TOP:
                this.mTop.mGoneMargin = i;
                return;
            case RIGHT:
                this.mRight.mGoneMargin = i;
                return;
            case BOTTOM:
                this.mBottom.mGoneMargin = i;
                return;
            default:
                return;
        }
    }

    public void setHeight(int i) {
        this.mHeight = i;
        if (this.mHeight < this.mMinHeight) {
            this.mHeight = this.mMinHeight;
        }
    }

    public void setHeightWrapContent(boolean z) {
        this.mIsHeightWrapContent = z;
    }

    public void setHorizontalBiasPercent(float f) {
        this.mHorizontalBiasPercent = f;
    }

    public void setHorizontalChainStyle(int i) {
        this.mHorizontalChainStyle = i;
    }

    public void setHorizontalDimension(int i, int i2) {
        this.f5mX = i;
        this.mWidth = i2 - i;
        if (this.mWidth < this.mMinWidth) {
            this.mWidth = this.mMinWidth;
        }
    }

    public void setHorizontalDimensionBehaviour(DimensionBehaviour dimensionBehaviour) {
        this.mListDimensionBehaviors[0] = dimensionBehaviour;
        if (dimensionBehaviour == DimensionBehaviour.WRAP_CONTENT) {
            setWidth(this.mWrapWidth);
        }
    }

    public void setHorizontalMatchStyle(int i, int i2, int i3, float f) {
        this.mMatchConstraintDefaultWidth = i;
        this.mMatchConstraintMinWidth = i2;
        this.mMatchConstraintMaxWidth = i3;
        this.mMatchConstraintPercentWidth = f;
        if (f < 1.0f && this.mMatchConstraintDefaultWidth == 0) {
            this.mMatchConstraintDefaultWidth = 2;
        }
    }

    public void setHorizontalWeight(float f) {
        this.mWeight[0] = f;
    }

    public void setLength(int i, int i2) {
        if (i2 == 0) {
            setWidth(i);
        } else if (i2 == 1) {
            setHeight(i);
        }
    }

    public void setMaxHeight(int i) {
        this.mMaxDimension[1] = i;
    }

    public void setMaxWidth(int i) {
        this.mMaxDimension[0] = i;
    }

    public void setMinHeight(int i) {
        if (i < 0) {
            this.mMinHeight = 0;
        } else {
            this.mMinHeight = i;
        }
    }

    public void setMinWidth(int i) {
        if (i < 0) {
            this.mMinWidth = 0;
        } else {
            this.mMinWidth = i;
        }
    }

    public void setOffset(int i, int i2) {
        this.mOffsetX = i;
        this.mOffsetY = i2;
    }

    public void setOrigin(int i, int i2) {
        this.f5mX = i;
        this.f6mY = i2;
    }

    public void setParent(ConstraintWidget constraintWidget) {
        this.mParent = constraintWidget;
    }

    /* access modifiers changed from: package-private */
    public void setRelativePositioning(int i, int i2) {
        if (i2 == 0) {
            this.mRelX = i;
        } else if (i2 == 1) {
            this.mRelY = i;
        }
    }

    public void setType(String str) {
        this.mType = str;
    }

    public void setVerticalBiasPercent(float f) {
        this.mVerticalBiasPercent = f;
    }

    public void setVerticalChainStyle(int i) {
        this.mVerticalChainStyle = i;
    }

    public void setVerticalDimension(int i, int i2) {
        this.f6mY = i;
        this.mHeight = i2 - i;
        if (this.mHeight < this.mMinHeight) {
            this.mHeight = this.mMinHeight;
        }
    }

    public void setVerticalDimensionBehaviour(DimensionBehaviour dimensionBehaviour) {
        this.mListDimensionBehaviors[1] = dimensionBehaviour;
        if (dimensionBehaviour == DimensionBehaviour.WRAP_CONTENT) {
            setHeight(this.mWrapHeight);
        }
    }

    public void setVerticalMatchStyle(int i, int i2, int i3, float f) {
        this.mMatchConstraintDefaultHeight = i;
        this.mMatchConstraintMinHeight = i2;
        this.mMatchConstraintMaxHeight = i3;
        this.mMatchConstraintPercentHeight = f;
        if (f < 1.0f && this.mMatchConstraintDefaultHeight == 0) {
            this.mMatchConstraintDefaultHeight = 2;
        }
    }

    public void setVerticalWeight(float f) {
        this.mWeight[1] = f;
    }

    public void setVisibility(int i) {
        this.mVisibility = i;
    }

    public void setWidth(int i) {
        this.mWidth = i;
        if (this.mWidth < this.mMinWidth) {
            this.mWidth = this.mMinWidth;
        }
    }

    public void setWidthWrapContent(boolean z) {
        this.mIsWidthWrapContent = z;
    }

    public void setWrapHeight(int i) {
        this.mWrapHeight = i;
    }

    public void setWrapWidth(int i) {
        this.mWrapWidth = i;
    }

    public void setX(int i) {
        this.f5mX = i;
    }

    public void setY(int i) {
        this.f6mY = i;
    }

    public void setupDimensionRatio(boolean z, boolean z2, boolean z3, boolean z4) {
        if (this.mResolvedDimensionRatioSide == -1) {
            if (z3 && !z4) {
                this.mResolvedDimensionRatioSide = 0;
            } else if (!z3 && z4) {
                this.mResolvedDimensionRatioSide = 1;
                if (this.mDimensionRatioSide == -1) {
                    this.mResolvedDimensionRatio = 1.0f / this.mResolvedDimensionRatio;
                }
            }
        }
        if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
            this.mResolvedDimensionRatioSide = 1;
        } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
            this.mResolvedDimensionRatioSide = 0;
        }
        if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected())) {
            if (this.mTop.isConnected() && this.mBottom.isConnected()) {
                this.mResolvedDimensionRatioSide = 0;
            } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
                this.mResolvedDimensionRatio = 1.0f / this.mResolvedDimensionRatio;
                this.mResolvedDimensionRatioSide = 1;
            }
        }
        if (this.mResolvedDimensionRatioSide == -1) {
            if (z && !z2) {
                this.mResolvedDimensionRatioSide = 0;
            } else if (!z && z2) {
                this.mResolvedDimensionRatio = 1.0f / this.mResolvedDimensionRatio;
                this.mResolvedDimensionRatioSide = 1;
            }
        }
        if (this.mResolvedDimensionRatioSide == -1) {
            if (this.mMatchConstraintMinWidth > 0 && this.mMatchConstraintMinHeight == 0) {
                this.mResolvedDimensionRatioSide = 0;
            } else if (this.mMatchConstraintMinWidth == 0 && this.mMatchConstraintMinHeight > 0) {
                this.mResolvedDimensionRatio = 1.0f / this.mResolvedDimensionRatio;
                this.mResolvedDimensionRatioSide = 1;
            }
        }
        if (this.mResolvedDimensionRatioSide == -1 && z && z2) {
            this.mResolvedDimensionRatio = 1.0f / this.mResolvedDimensionRatio;
            this.mResolvedDimensionRatioSide = 1;
        }
    }

    public String toString() {
        String str;
        String str2;
        StringBuilder sb = new StringBuilder();
        if (this.mType != null) {
            str = "type: " + this.mType + " ";
        } else {
            str = BuildConfig.FLAVOR;
        }
        sb.append(str);
        if (this.mDebugName != null) {
            str2 = "id: " + this.mDebugName + " ";
        } else {
            str2 = BuildConfig.FLAVOR;
        }
        sb.append(str2);
        sb.append("(");
        sb.append(this.f5mX);
        sb.append(", ");
        sb.append(this.f6mY);
        sb.append(") - (");
        sb.append(this.mWidth);
        sb.append(" x ");
        sb.append(this.mHeight);
        sb.append(") wrap: (");
        sb.append(this.mWrapWidth);
        sb.append(" x ");
        sb.append(this.mWrapHeight);
        sb.append(")");
        return sb.toString();
    }

    public void updateDrawPosition() {
        int i = this.f5mX;
        int i2 = this.f6mY;
        int i3 = this.f5mX;
        int i4 = this.mWidth;
        int i5 = this.f6mY;
        int i6 = this.mHeight;
        this.mDrawX = i;
        this.mDrawY = i2;
        this.mDrawWidth = (i3 + i4) - i;
        this.mDrawHeight = (i5 + i6) - i2;
    }

    public void updateFromSolver(LinearSystem linearSystem) {
        int objectVariableValue = linearSystem.getObjectVariableValue(this.mLeft);
        int objectVariableValue2 = linearSystem.getObjectVariableValue(this.mTop);
        int objectVariableValue3 = linearSystem.getObjectVariableValue(this.mRight);
        int objectVariableValue4 = linearSystem.getObjectVariableValue(this.mBottom);
        if (objectVariableValue3 - objectVariableValue < 0 || objectVariableValue4 - objectVariableValue2 < 0 || objectVariableValue == Integer.MIN_VALUE || objectVariableValue == Integer.MAX_VALUE || objectVariableValue2 == Integer.MIN_VALUE || objectVariableValue2 == Integer.MAX_VALUE || objectVariableValue3 == Integer.MIN_VALUE || objectVariableValue3 == Integer.MAX_VALUE || objectVariableValue4 == Integer.MIN_VALUE || objectVariableValue4 == Integer.MAX_VALUE) {
            objectVariableValue4 = 0;
            objectVariableValue3 = 0;
            objectVariableValue2 = 0;
            objectVariableValue = 0;
        }
        setFrame(objectVariableValue, objectVariableValue2, objectVariableValue3, objectVariableValue4);
    }

    public void updateResolutionNodes() {
        for (int i = 0; i < 6; i++) {
            this.mListAnchors[i].getResolutionNode().update();
        }
    }
}
