package android.support.constraint.solver.widgets;

import android.support.constraint.solver.LinearSystem;
import android.support.constraint.solver.Metrics;
import android.support.constraint.solver.widgets.ConstraintAnchor;
import android.support.constraint.solver.widgets.ConstraintWidget;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ConstraintWidgetContainer extends WidgetContainer {
    private static final boolean DEBUG = false;
    static final boolean DEBUG_GRAPH = false;
    private static final boolean DEBUG_LAYOUT = false;
    private static final int MAX_ITERATIONS = 8;
    private static final boolean USE_SNAPSHOT = true;
    int mDebugSolverPassCount = 0;
    public boolean mGroupsWrapOptimized = false;
    private boolean mHeightMeasuredTooSmall = false;
    ChainHead[] mHorizontalChainsArray = new ChainHead[4];
    int mHorizontalChainsSize = 0;
    public boolean mHorizontalWrapOptimized = false;
    private boolean mIsRtl = false;
    private int mOptimizationLevel = 7;
    int mPaddingBottom;
    int mPaddingLeft;
    int mPaddingRight;
    int mPaddingTop;
    public boolean mSkipSolver = false;
    private Snapshot mSnapshot;
    protected LinearSystem mSystem = new LinearSystem();
    ChainHead[] mVerticalChainsArray = new ChainHead[4];
    int mVerticalChainsSize = 0;
    public boolean mVerticalWrapOptimized = false;
    public List<ConstraintWidgetGroup> mWidgetGroups = new ArrayList();
    private boolean mWidthMeasuredTooSmall = false;
    public int mWrapFixedHeight = 0;
    public int mWrapFixedWidth = 0;

    public ConstraintWidgetContainer() {
    }

    public ConstraintWidgetContainer(int i, int i2) {
        super(i, i2);
    }

    public ConstraintWidgetContainer(int i, int i2, int i3, int i4) {
        super(i, i2, i3, i4);
    }

    private void addHorizontalChain(ConstraintWidget constraintWidget) {
        if (this.mHorizontalChainsSize + 1 >= this.mHorizontalChainsArray.length) {
            this.mHorizontalChainsArray = (ChainHead[]) Arrays.copyOf(this.mHorizontalChainsArray, this.mHorizontalChainsArray.length * 2);
        }
        this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(constraintWidget, 0, isRtl());
        this.mHorizontalChainsSize++;
    }

    private void addVerticalChain(ConstraintWidget constraintWidget) {
        if (this.mVerticalChainsSize + 1 >= this.mVerticalChainsArray.length) {
            this.mVerticalChainsArray = (ChainHead[]) Arrays.copyOf(this.mVerticalChainsArray, this.mVerticalChainsArray.length * 2);
        }
        this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(constraintWidget, 1, isRtl());
        this.mVerticalChainsSize++;
    }

    private void resetChains() {
        this.mHorizontalChainsSize = 0;
        this.mVerticalChainsSize = 0;
    }

    /* access modifiers changed from: package-private */
    public void addChain(ConstraintWidget constraintWidget, int i) {
        if (i == 0) {
            addHorizontalChain(constraintWidget);
        } else if (i == 1) {
            addVerticalChain(constraintWidget);
        }
    }

    public boolean addChildrenToSolver(LinearSystem linearSystem) {
        addToSolver(linearSystem);
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i);
            if (constraintWidget instanceof ConstraintWidgetContainer) {
                ConstraintWidget.DimensionBehaviour dimensionBehaviour = constraintWidget.mListDimensionBehaviors[0];
                ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = constraintWidget.mListDimensionBehaviors[1];
                if (dimensionBehaviour == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                    constraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
                }
                if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                    constraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
                }
                constraintWidget.addToSolver(linearSystem);
                if (dimensionBehaviour == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                    constraintWidget.setHorizontalDimensionBehaviour(dimensionBehaviour);
                }
                if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                    constraintWidget.setVerticalDimensionBehaviour(dimensionBehaviour2);
                }
            } else {
                Optimizer.checkMatchParent(this, linearSystem, constraintWidget);
                constraintWidget.addToSolver(linearSystem);
            }
        }
        if (this.mHorizontalChainsSize > 0) {
            Chain.applyChainConstraints(this, linearSystem, 0);
        }
        if (this.mVerticalChainsSize > 0) {
            Chain.applyChainConstraints(this, linearSystem, 1);
        }
        return USE_SNAPSHOT;
    }

    public void analyze(int i) {
        super.analyze(i);
        int size = this.mChildren.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((ConstraintWidget) this.mChildren.get(i2)).analyze(i);
        }
    }

    public void fillMetrics(Metrics metrics) {
        this.mSystem.fillMetrics(metrics);
    }

    public ArrayList<Guideline> getHorizontalGuidelines() {
        ArrayList<Guideline> arrayList = new ArrayList<>();
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i);
            if (constraintWidget instanceof Guideline) {
                Guideline guideline = (Guideline) constraintWidget;
                if (guideline.getOrientation() == 0) {
                    arrayList.add(guideline);
                }
            }
        }
        return arrayList;
    }

    public int getOptimizationLevel() {
        return this.mOptimizationLevel;
    }

    public LinearSystem getSystem() {
        return this.mSystem;
    }

    public String getType() {
        return "ConstraintLayout";
    }

    public ArrayList<Guideline> getVerticalGuidelines() {
        ArrayList<Guideline> arrayList = new ArrayList<>();
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i);
            if (constraintWidget instanceof Guideline) {
                Guideline guideline = (Guideline) constraintWidget;
                if (guideline.getOrientation() == 1) {
                    arrayList.add(guideline);
                }
            }
        }
        return arrayList;
    }

    public List<ConstraintWidgetGroup> getWidgetGroups() {
        return this.mWidgetGroups;
    }

    public boolean handlesInternalConstraints() {
        return false;
    }

    public boolean isHeightMeasuredTooSmall() {
        return this.mHeightMeasuredTooSmall;
    }

    public boolean isRtl() {
        return this.mIsRtl;
    }

    public boolean isWidthMeasuredTooSmall() {
        return this.mWidthMeasuredTooSmall;
    }

    /* JADX WARNING: Removed duplicated region for block: B:118:0x02ec  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x030e  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0320  */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x0374  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x0405  */
    /* JADX WARNING: Removed duplicated region for block: B:158:0x0370 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x01d1  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x01ea  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x023e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void layout() {
        /*
            r21 = this;
            r0 = r21
            int r12 = r0.f5mX
            r0 = r21
            int r13 = r0.f6mY
            r1 = 0
            int r2 = r21.getWidth()
            int r14 = java.lang.Math.max(r1, r2)
            r1 = 0
            int r2 = r21.getHeight()
            int r15 = java.lang.Math.max(r1, r2)
            r1 = 0
            r0 = r21
            r0.mWidthMeasuredTooSmall = r1
            r1 = 0
            r0 = r21
            r0.mHeightMeasuredTooSmall = r1
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r0.mParent
            if (r1 == 0) goto L_0x00fd
            r0 = r21
            android.support.constraint.solver.widgets.Snapshot r1 = r0.mSnapshot
            if (r1 != 0) goto L_0x003b
            android.support.constraint.solver.widgets.Snapshot r1 = new android.support.constraint.solver.widgets.Snapshot
            r0 = r21
            r1.<init>(r0)
            r0 = r21
            r0.mSnapshot = r1
        L_0x003b:
            r0 = r21
            android.support.constraint.solver.widgets.Snapshot r1 = r0.mSnapshot
            r0 = r21
            r1.updateFrom(r0)
            r0 = r21
            int r1 = r0.mPaddingLeft
            r0 = r21
            r0.setX(r1)
            r0 = r21
            int r1 = r0.mPaddingTop
            r0 = r21
            r0.setY(r1)
            r21.resetAnchors()
            r0 = r21
            android.support.constraint.solver.LinearSystem r1 = r0.mSystem
            android.support.constraint.solver.Cache r1 = r1.getCache()
            r0 = r21
            r0.resetSolverVariables(r1)
        L_0x0066:
            r0 = r21
            int r1 = r0.mOptimizationLevel
            if (r1 == 0) goto L_0x0109
            r1 = 8
            r0 = r21
            boolean r1 = r0.optimizeFor(r1)
            if (r1 != 0) goto L_0x0079
            r21.optimizeReset()
        L_0x0079:
            r1 = 32
            r0 = r21
            boolean r1 = r0.optimizeFor(r1)
            if (r1 != 0) goto L_0x0086
            r21.optimize()
        L_0x0086:
            r0 = r21
            android.support.constraint.solver.LinearSystem r1 = r0.mSystem
            r2 = 1
            r1.graphOptimizer = r2
        L_0x008d:
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r2 = 1
            r16 = r1[r2]
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r2 = 0
            r17 = r1[r2]
            r21.resetChains()
            r0 = r21
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidgetGroup> r1 = r0.mWidgetGroups
            int r1 = r1.size()
            if (r1 != 0) goto L_0x00c0
            r0 = r21
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidgetGroup> r1 = r0.mWidgetGroups
            r1.clear()
            r0 = r21
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidgetGroup> r1 = r0.mWidgetGroups
            r2 = 0
            android.support.constraint.solver.widgets.ConstraintWidgetGroup r3 = new android.support.constraint.solver.widgets.ConstraintWidgetGroup
            r0 = r21
            java.util.ArrayList r4 = r0.mChildren
            r3.<init>(r4)
            r1.add(r2, r3)
        L_0x00c0:
            r0 = r21
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidgetGroup> r1 = r0.mWidgetGroups
            int r7 = r1.size()
            r0 = r21
            java.util.ArrayList r2 = r0.mChildren
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r1 = r21.getHorizontalDimensionBehaviour()
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r3 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r1 == r3) goto L_0x00dc
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r1 = r21.getVerticalDimensionBehaviour()
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r3 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r1 != r3) goto L_0x0112
        L_0x00dc:
            r1 = 1
            r3 = r1
        L_0x00de:
            r6 = 0
            r1 = 0
            r11 = r1
        L_0x00e1:
            if (r11 >= r7) goto L_0x0387
            r0 = r21
            boolean r1 = r0.mSkipSolver
            if (r1 != 0) goto L_0x0387
            r0 = r21
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidgetGroup> r1 = r0.mWidgetGroups
            java.lang.Object r1 = r1.get(r11)
            android.support.constraint.solver.widgets.ConstraintWidgetGroup r1 = (android.support.constraint.solver.widgets.ConstraintWidgetGroup) r1
            boolean r1 = r1.mSkipSolver
            if (r1 == 0) goto L_0x0115
            r1 = r7
        L_0x00f8:
            int r4 = r11 + 1
            r11 = r4
            r7 = r1
            goto L_0x00e1
        L_0x00fd:
            r1 = 0
            r0 = r21
            r0.f5mX = r1
            r1 = 0
            r0 = r21
            r0.f6mY = r1
            goto L_0x0066
        L_0x0109:
            r0 = r21
            android.support.constraint.solver.LinearSystem r1 = r0.mSystem
            r2 = 0
            r1.graphOptimizer = r2
            goto L_0x008d
        L_0x0112:
            r1 = 0
            r3 = r1
            goto L_0x00de
        L_0x0115:
            r1 = 32
            r0 = r21
            boolean r1 = r0.optimizeFor(r1)
            if (r1 == 0) goto L_0x0143
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r1 = r21.getHorizontalDimensionBehaviour()
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r4 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.FIXED
            if (r1 != r4) goto L_0x016c
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r1 = r21.getVerticalDimensionBehaviour()
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r4 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.FIXED
            if (r1 != r4) goto L_0x016c
            r0 = r21
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidgetGroup> r1 = r0.mWidgetGroups
            java.lang.Object r1 = r1.get(r11)
            android.support.constraint.solver.widgets.ConstraintWidgetGroup r1 = (android.support.constraint.solver.widgets.ConstraintWidgetGroup) r1
            java.util.List r1 = r1.getWidgetsToSolve()
            java.util.ArrayList r1 = (java.util.ArrayList) r1
            r0 = r21
            r0.mChildren = r1
        L_0x0143:
            r21.resetChains()
            r0 = r21
            java.util.ArrayList r1 = r0.mChildren
            int r18 = r1.size()
            r4 = 0
            r1 = 0
            r5 = r1
        L_0x0151:
            r0 = r18
            if (r5 >= r0) goto L_0x017f
            r0 = r21
            java.util.ArrayList r1 = r0.mChildren
            java.lang.Object r1 = r1.get(r5)
            android.support.constraint.solver.widgets.ConstraintWidget r1 = (android.support.constraint.solver.widgets.ConstraintWidget) r1
            boolean r8 = r1 instanceof android.support.constraint.solver.widgets.WidgetContainer
            if (r8 == 0) goto L_0x0168
            android.support.constraint.solver.widgets.WidgetContainer r1 = (android.support.constraint.solver.widgets.WidgetContainer) r1
            r1.layout()
        L_0x0168:
            int r1 = r5 + 1
            r5 = r1
            goto L_0x0151
        L_0x016c:
            r0 = r21
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidgetGroup> r1 = r0.mWidgetGroups
            java.lang.Object r1 = r1.get(r11)
            android.support.constraint.solver.widgets.ConstraintWidgetGroup r1 = (android.support.constraint.solver.widgets.ConstraintWidgetGroup) r1
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidget> r1 = r1.mConstrainedGroup
            java.util.ArrayList r1 = (java.util.ArrayList) r1
            r0 = r21
            r0.mChildren = r1
            goto L_0x0143
        L_0x017f:
            r1 = 1
            r5 = r4
        L_0x0181:
            if (r1 == 0) goto L_0x0377
            int r10 = r5 + 1
            r0 = r21
            android.support.constraint.solver.LinearSystem r4 = r0.mSystem     // Catch:{ Exception -> 0x023a }
            r4.reset()     // Catch:{ Exception -> 0x023a }
            r21.resetChains()     // Catch:{ Exception -> 0x023a }
            r0 = r21
            android.support.constraint.solver.LinearSystem r4 = r0.mSystem     // Catch:{ Exception -> 0x023a }
            r0 = r21
            r0.createObjectVariables(r4)     // Catch:{ Exception -> 0x023a }
            r5 = 0
            r4 = r1
        L_0x019a:
            r0 = r18
            if (r5 >= r0) goto L_0x021e
            r0 = r21
            java.util.ArrayList r1 = r0.mChildren     // Catch:{ Exception -> 0x01b3 }
            java.lang.Object r1 = r1.get(r5)     // Catch:{ Exception -> 0x01b3 }
            android.support.constraint.solver.widgets.ConstraintWidget r1 = (android.support.constraint.solver.widgets.ConstraintWidget) r1     // Catch:{ Exception -> 0x01b3 }
            r0 = r21
            android.support.constraint.solver.LinearSystem r8 = r0.mSystem     // Catch:{ Exception -> 0x0236 }
            r1.createObjectVariables(r8)     // Catch:{ Exception -> 0x0236 }
            int r1 = r5 + 1
            r5 = r1
            goto L_0x019a
        L_0x01b3:
            r5 = move-exception
            r1 = r4
        L_0x01b5:
            r5.printStackTrace()
            java.io.PrintStream r4 = java.lang.System.out
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r9 = "EXCEPTION : "
            r8.append(r9)
            r8.append(r5)
            java.lang.String r5 = r8.toString()
            r4.println(r5)
            r5 = r6
        L_0x01cf:
            if (r1 == 0) goto L_0x023e
            r0 = r21
            android.support.constraint.solver.LinearSystem r1 = r0.mSystem
            boolean[] r4 = android.support.constraint.solver.widgets.Optimizer.flags
            r0 = r21
            r0.updateChildrenFromSolver(r1, r4)
        L_0x01dc:
            r4 = 0
            if (r3 == 0) goto L_0x0374
            r1 = 8
            if (r10 >= r1) goto L_0x0374
            boolean[] r1 = android.support.constraint.solver.widgets.Optimizer.flags
            r6 = 2
            boolean r1 = r1[r6]
            if (r1 == 0) goto L_0x0374
            r8 = 0
            r1 = 0
            r9 = 0
            r6 = r1
        L_0x01ee:
            r0 = r18
            if (r9 >= r0) goto L_0x0291
            r0 = r21
            java.util.ArrayList r1 = r0.mChildren
            java.lang.Object r1 = r1.get(r9)
            android.support.constraint.solver.widgets.ConstraintWidget r1 = (android.support.constraint.solver.widgets.ConstraintWidget) r1
            int r0 = r1.f5mX
            r19 = r0
            int r20 = r1.getWidth()
            int r19 = r19 + r20
            r0 = r19
            int r6 = java.lang.Math.max(r6, r0)
            int r0 = r1.f6mY
            r19 = r0
            int r1 = r1.getHeight()
            int r1 = r1 + r19
            int r1 = java.lang.Math.max(r8, r1)
            int r9 = r9 + 1
            r8 = r1
            goto L_0x01ee
        L_0x021e:
            r0 = r21
            android.support.constraint.solver.LinearSystem r1 = r0.mSystem     // Catch:{ Exception -> 0x0236 }
            r0 = r21
            boolean r1 = r0.addChildrenToSolver(r1)     // Catch:{ Exception -> 0x0236 }
            if (r1 == 0) goto L_0x0231
            r0 = r21
            android.support.constraint.solver.LinearSystem r4 = r0.mSystem     // Catch:{ Exception -> 0x0233 }
            r4.minimize()     // Catch:{ Exception -> 0x0233 }
        L_0x0231:
            r5 = r6
            goto L_0x01cf
        L_0x0233:
            r4 = move-exception
            r5 = r4
            goto L_0x01b5
        L_0x0236:
            r5 = move-exception
            r1 = r4
            goto L_0x01b5
        L_0x023a:
            r4 = move-exception
            r5 = r4
            goto L_0x01b5
        L_0x023e:
            r0 = r21
            android.support.constraint.solver.LinearSystem r1 = r0.mSystem
            r0 = r21
            r0.updateFromSolver(r1)
            r1 = 0
            r4 = r1
        L_0x0249:
            r0 = r18
            if (r4 >= r0) goto L_0x01dc
            r0 = r21
            java.util.ArrayList r1 = r0.mChildren
            java.lang.Object r1 = r1.get(r4)
            android.support.constraint.solver.widgets.ConstraintWidget r1 = (android.support.constraint.solver.widgets.ConstraintWidget) r1
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r6 = r1.mListDimensionBehaviors
            r8 = 0
            r6 = r6[r8]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r8 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r6 != r8) goto L_0x0272
            int r6 = r1.getWidth()
            int r8 = r1.getWrapWidth()
            if (r6 >= r8) goto L_0x0272
            boolean[] r1 = android.support.constraint.solver.widgets.Optimizer.flags
            r4 = 2
            r6 = 1
            r1[r4] = r6
            goto L_0x01dc
        L_0x0272:
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r6 = r1.mListDimensionBehaviors
            r8 = 1
            r6 = r6[r8]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r8 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r6 != r8) goto L_0x028d
            int r6 = r1.getHeight()
            int r1 = r1.getWrapHeight()
            if (r6 >= r1) goto L_0x028d
            boolean[] r1 = android.support.constraint.solver.widgets.Optimizer.flags
            r4 = 2
            r6 = 1
            r1[r4] = r6
            goto L_0x01dc
        L_0x028d:
            int r1 = r4 + 1
            r4 = r1
            goto L_0x0249
        L_0x0291:
            r0 = r21
            int r1 = r0.mMinWidth
            int r1 = java.lang.Math.max(r1, r6)
            r0 = r21
            int r6 = r0.mMinHeight
            int r6 = java.lang.Math.max(r6, r8)
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r8 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            r0 = r17
            if (r0 != r8) goto L_0x0408
            int r8 = r21.getWidth()
            if (r8 >= r1) goto L_0x0408
            r0 = r21
            r0.setWidth(r1)
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r4 = 0
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r5 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            r1[r4] = r5
            r4 = 1
            r1 = 1
            r5 = r4
        L_0x02be:
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r4 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            r0 = r16
            if (r0 != r4) goto L_0x02da
            int r4 = r21.getHeight()
            if (r4 >= r6) goto L_0x02da
            r0 = r21
            r0.setHeight(r6)
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r4 = 1
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r5 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            r1[r4] = r5
            r5 = 1
            r1 = 1
        L_0x02da:
            r0 = r21
            int r4 = r0.mMinWidth
            int r6 = r21.getWidth()
            int r4 = java.lang.Math.max(r4, r6)
            int r6 = r21.getWidth()
            if (r4 <= r6) goto L_0x02fc
            r0 = r21
            r0.setWidth(r4)
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r4 = 0
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r5 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.FIXED
            r1[r4] = r5
            r5 = 1
            r1 = 1
        L_0x02fc:
            r0 = r21
            int r4 = r0.mMinHeight
            int r6 = r21.getHeight()
            int r4 = java.lang.Math.max(r4, r6)
            int r6 = r21.getHeight()
            if (r4 <= r6) goto L_0x0405
            r0 = r21
            r0.setHeight(r4)
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r4 = 1
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r5 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.FIXED
            r1[r4] = r5
            r4 = 1
            r1 = 1
        L_0x031e:
            if (r4 != 0) goto L_0x0370
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r5 = r0.mListDimensionBehaviors
            r6 = 0
            r5 = r5[r6]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r6 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r5 != r6) goto L_0x0348
            if (r14 <= 0) goto L_0x0348
            int r5 = r21.getWidth()
            if (r5 <= r14) goto L_0x0348
            r1 = 1
            r0 = r21
            r0.mWidthMeasuredTooSmall = r1
            r4 = 1
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r5 = 0
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r6 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.FIXED
            r1[r5] = r6
            r0 = r21
            r0.setWidth(r14)
            r1 = 1
        L_0x0348:
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r5 = r0.mListDimensionBehaviors
            r6 = 1
            r5 = r5[r6]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r6 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r5 != r6) goto L_0x0370
            if (r15 <= 0) goto L_0x0370
            int r5 = r21.getHeight()
            if (r5 <= r15) goto L_0x0370
            r1 = 1
            r0 = r21
            r0.mHeightMeasuredTooSmall = r1
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r4 = 1
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r5 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.FIXED
            r1[r4] = r5
            r0 = r21
            r0.setHeight(r15)
            r4 = 1
            r1 = 1
        L_0x0370:
            r5 = r10
            r6 = r4
            goto L_0x0181
        L_0x0374:
            r1 = 0
            goto L_0x02da
        L_0x0377:
            r0 = r21
            java.util.List<android.support.constraint.solver.widgets.ConstraintWidgetGroup> r1 = r0.mWidgetGroups
            java.lang.Object r1 = r1.get(r11)
            android.support.constraint.solver.widgets.ConstraintWidgetGroup r1 = (android.support.constraint.solver.widgets.ConstraintWidgetGroup) r1
            r1.updateUnresolvedWidgets()
            r1 = r7
            goto L_0x00f8
        L_0x0387:
            r1 = r2
            java.util.ArrayList r1 = (java.util.ArrayList) r1
            r0 = r21
            r0.mChildren = r1
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r0.mParent
            if (r1 == 0) goto L_0x03fc
            r0 = r21
            int r1 = r0.mMinWidth
            int r2 = r21.getWidth()
            int r1 = java.lang.Math.max(r1, r2)
            r0 = r21
            int r2 = r0.mMinHeight
            int r3 = r21.getHeight()
            int r2 = java.lang.Math.max(r2, r3)
            r0 = r21
            android.support.constraint.solver.widgets.Snapshot r3 = r0.mSnapshot
            r0 = r21
            r3.applyTo(r0)
            r0 = r21
            int r3 = r0.mPaddingLeft
            int r1 = r1 + r3
            r0 = r21
            int r3 = r0.mPaddingRight
            int r1 = r1 + r3
            r0 = r21
            r0.setWidth(r1)
            r0 = r21
            int r1 = r0.mPaddingTop
            int r1 = r1 + r2
            r0 = r21
            int r2 = r0.mPaddingBottom
            int r1 = r1 + r2
            r0 = r21
            r0.setHeight(r1)
        L_0x03d3:
            if (r6 == 0) goto L_0x03e3
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r2 = 0
            r1[r2] = r17
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r2 = 1
            r1[r2] = r16
        L_0x03e3:
            r0 = r21
            android.support.constraint.solver.LinearSystem r1 = r0.mSystem
            android.support.constraint.solver.Cache r1 = r1.getCache()
            r0 = r21
            r0.resetSolverVariables(r1)
            android.support.constraint.solver.widgets.ConstraintWidgetContainer r1 = r21.getRootConstraintContainer()
            r0 = r21
            if (r0 != r1) goto L_0x03fb
            r21.updateDrawPosition()
        L_0x03fb:
            return
        L_0x03fc:
            r0 = r21
            r0.f5mX = r12
            r0 = r21
            r0.f6mY = r13
            goto L_0x03d3
        L_0x0405:
            r4 = r5
            goto L_0x031e
        L_0x0408:
            r1 = r4
            goto L_0x02be
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.solver.widgets.ConstraintWidgetContainer.layout():void");
    }

    public void optimize() {
        if (!optimizeFor(8)) {
            analyze(this.mOptimizationLevel);
        }
        solveGraph();
    }

    public boolean optimizeFor(int i) {
        if ((this.mOptimizationLevel & i) == i) {
            return USE_SNAPSHOT;
        }
        return false;
    }

    public void optimizeForDimensions(int i, int i2) {
        if (!(this.mListDimensionBehaviors[0] == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || this.mResolutionWidth == null)) {
            this.mResolutionWidth.resolve(i);
        }
        if (this.mListDimensionBehaviors[1] != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT && this.mResolutionHeight != null) {
            this.mResolutionHeight.resolve(i2);
        }
    }

    public void optimizeReset() {
        int size = this.mChildren.size();
        resetResolutionNodes();
        for (int i = 0; i < size; i++) {
            ((ConstraintWidget) this.mChildren.get(i)).resetResolutionNodes();
        }
    }

    public void preOptimize() {
        optimizeReset();
        analyze(this.mOptimizationLevel);
    }

    public void reset() {
        this.mSystem.reset();
        this.mPaddingLeft = 0;
        this.mPaddingRight = 0;
        this.mPaddingTop = 0;
        this.mPaddingBottom = 0;
        this.mWidgetGroups.clear();
        this.mSkipSolver = false;
        super.reset();
    }

    public void resetGraph() {
        ResolutionAnchor resolutionNode = getAnchor(ConstraintAnchor.Type.LEFT).getResolutionNode();
        ResolutionAnchor resolutionNode2 = getAnchor(ConstraintAnchor.Type.TOP).getResolutionNode();
        resolutionNode.invalidateAnchors();
        resolutionNode2.invalidateAnchors();
        resolutionNode.resolve((ResolutionAnchor) null, 0.0f);
        resolutionNode2.resolve((ResolutionAnchor) null, 0.0f);
    }

    public void setOptimizationLevel(int i) {
        this.mOptimizationLevel = i;
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        this.mPaddingLeft = i;
        this.mPaddingTop = i2;
        this.mPaddingRight = i3;
        this.mPaddingBottom = i4;
    }

    public void setRtl(boolean z) {
        this.mIsRtl = z;
    }

    public void solveGraph() {
        ResolutionAnchor resolutionNode = getAnchor(ConstraintAnchor.Type.LEFT).getResolutionNode();
        ResolutionAnchor resolutionNode2 = getAnchor(ConstraintAnchor.Type.TOP).getResolutionNode();
        resolutionNode.resolve((ResolutionAnchor) null, 0.0f);
        resolutionNode2.resolve((ResolutionAnchor) null, 0.0f);
    }

    public void updateChildrenFromSolver(LinearSystem linearSystem, boolean[] zArr) {
        zArr[2] = false;
        updateFromSolver(linearSystem);
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) this.mChildren.get(i);
            constraintWidget.updateFromSolver(linearSystem);
            if (constraintWidget.mListDimensionBehaviors[0] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.getWidth() < constraintWidget.getWrapWidth()) {
                zArr[2] = USE_SNAPSHOT;
            }
            if (constraintWidget.mListDimensionBehaviors[1] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.getHeight() < constraintWidget.getWrapHeight()) {
                zArr[2] = USE_SNAPSHOT;
            }
        }
    }
}
