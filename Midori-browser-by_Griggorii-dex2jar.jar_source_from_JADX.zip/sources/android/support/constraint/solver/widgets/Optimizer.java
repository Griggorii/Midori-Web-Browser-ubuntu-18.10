package android.support.constraint.solver.widgets;

import android.support.constraint.solver.LinearSystem;
import android.support.constraint.solver.widgets.ConstraintWidget;

public class Optimizer {
    static final int FLAG_CHAIN_DANGLING = 1;
    static final int FLAG_RECOMPUTE_BOUNDS = 2;
    static final int FLAG_USE_OPTIMIZE = 0;
    public static final int OPTIMIZATION_BARRIER = 2;
    public static final int OPTIMIZATION_CHAIN = 4;
    public static final int OPTIMIZATION_DIMENSIONS = 8;
    public static final int OPTIMIZATION_DIRECT = 1;
    public static final int OPTIMIZATION_GROUPS = 32;
    public static final int OPTIMIZATION_NONE = 0;
    public static final int OPTIMIZATION_RATIO = 16;
    public static final int OPTIMIZATION_STANDARD = 7;
    static boolean[] flags = new boolean[3];

    static void analyze(int i, ConstraintWidget constraintWidget) {
        boolean z = false;
        constraintWidget.updateResolutionNodes();
        ResolutionAnchor resolutionNode = constraintWidget.mLeft.getResolutionNode();
        ResolutionAnchor resolutionNode2 = constraintWidget.mTop.getResolutionNode();
        ResolutionAnchor resolutionNode3 = constraintWidget.mRight.getResolutionNode();
        ResolutionAnchor resolutionNode4 = constraintWidget.mBottom.getResolutionNode();
        boolean z2 = (i & 8) == 8;
        boolean z3 = constraintWidget.mListDimensionBehaviors[0] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && optimizableMatchConstraint(constraintWidget, 0);
        if (!(resolutionNode.type == 4 || resolutionNode3.type == 4)) {
            if (constraintWidget.mListDimensionBehaviors[0] == ConstraintWidget.DimensionBehaviour.FIXED || (z3 && constraintWidget.getVisibility() == 8)) {
                if (constraintWidget.mLeft.mTarget == null && constraintWidget.mRight.mTarget == null) {
                    resolutionNode.setType(1);
                    resolutionNode3.setType(1);
                    if (z2) {
                        resolutionNode3.dependsOn(resolutionNode, 1, constraintWidget.getResolutionWidth());
                    } else {
                        resolutionNode3.dependsOn(resolutionNode, constraintWidget.getWidth());
                    }
                } else if (constraintWidget.mLeft.mTarget != null && constraintWidget.mRight.mTarget == null) {
                    resolutionNode.setType(1);
                    resolutionNode3.setType(1);
                    if (z2) {
                        resolutionNode3.dependsOn(resolutionNode, 1, constraintWidget.getResolutionWidth());
                    } else {
                        resolutionNode3.dependsOn(resolutionNode, constraintWidget.getWidth());
                    }
                } else if (constraintWidget.mLeft.mTarget == null && constraintWidget.mRight.mTarget != null) {
                    resolutionNode.setType(1);
                    resolutionNode3.setType(1);
                    resolutionNode.dependsOn(resolutionNode3, -constraintWidget.getWidth());
                    if (z2) {
                        resolutionNode.dependsOn(resolutionNode3, -1, constraintWidget.getResolutionWidth());
                    } else {
                        resolutionNode.dependsOn(resolutionNode3, -constraintWidget.getWidth());
                    }
                } else if (!(constraintWidget.mLeft.mTarget == null || constraintWidget.mRight.mTarget == null)) {
                    resolutionNode.setType(2);
                    resolutionNode3.setType(2);
                    if (z2) {
                        constraintWidget.getResolutionWidth().addDependent(resolutionNode);
                        constraintWidget.getResolutionWidth().addDependent(resolutionNode3);
                        resolutionNode.setOpposite(resolutionNode3, -1, constraintWidget.getResolutionWidth());
                        resolutionNode3.setOpposite(resolutionNode, 1, constraintWidget.getResolutionWidth());
                    } else {
                        resolutionNode.setOpposite(resolutionNode3, (float) (-constraintWidget.getWidth()));
                        resolutionNode3.setOpposite(resolutionNode, (float) constraintWidget.getWidth());
                    }
                }
            } else if (z3) {
                int width = constraintWidget.getWidth();
                resolutionNode.setType(1);
                resolutionNode3.setType(1);
                if (constraintWidget.mLeft.mTarget == null && constraintWidget.mRight.mTarget == null) {
                    if (z2) {
                        resolutionNode3.dependsOn(resolutionNode, 1, constraintWidget.getResolutionWidth());
                    } else {
                        resolutionNode3.dependsOn(resolutionNode, width);
                    }
                } else if (constraintWidget.mLeft.mTarget == null || constraintWidget.mRight.mTarget != null) {
                    if (constraintWidget.mLeft.mTarget != null || constraintWidget.mRight.mTarget == null) {
                        if (!(constraintWidget.mLeft.mTarget == null || constraintWidget.mRight.mTarget == null)) {
                            if (z2) {
                                constraintWidget.getResolutionWidth().addDependent(resolutionNode);
                                constraintWidget.getResolutionWidth().addDependent(resolutionNode3);
                            }
                            if (constraintWidget.mDimensionRatio == 0.0f) {
                                resolutionNode.setType(3);
                                resolutionNode3.setType(3);
                                resolutionNode.setOpposite(resolutionNode3, 0.0f);
                                resolutionNode3.setOpposite(resolutionNode, 0.0f);
                            } else {
                                resolutionNode.setType(2);
                                resolutionNode3.setType(2);
                                resolutionNode.setOpposite(resolutionNode3, (float) (-width));
                                resolutionNode3.setOpposite(resolutionNode, (float) width);
                                constraintWidget.setWidth(width);
                            }
                        }
                    } else if (z2) {
                        resolutionNode.dependsOn(resolutionNode3, -1, constraintWidget.getResolutionWidth());
                    } else {
                        resolutionNode.dependsOn(resolutionNode3, -width);
                    }
                } else if (z2) {
                    resolutionNode3.dependsOn(resolutionNode, 1, constraintWidget.getResolutionWidth());
                } else {
                    resolutionNode3.dependsOn(resolutionNode, width);
                }
            }
        }
        if (constraintWidget.mListDimensionBehaviors[1] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && optimizableMatchConstraint(constraintWidget, 1)) {
            z = true;
        }
        if (resolutionNode2.type != 4 && resolutionNode4.type != 4) {
            if (constraintWidget.mListDimensionBehaviors[1] == ConstraintWidget.DimensionBehaviour.FIXED || (z && constraintWidget.getVisibility() == 8)) {
                if (constraintWidget.mTop.mTarget == null && constraintWidget.mBottom.mTarget == null) {
                    resolutionNode2.setType(1);
                    resolutionNode4.setType(1);
                    if (z2) {
                        resolutionNode4.dependsOn(resolutionNode2, 1, constraintWidget.getResolutionHeight());
                    } else {
                        resolutionNode4.dependsOn(resolutionNode2, constraintWidget.getHeight());
                    }
                    if (constraintWidget.mBaseline.mTarget != null) {
                        constraintWidget.mBaseline.getResolutionNode().setType(1);
                        resolutionNode2.dependsOn(1, constraintWidget.mBaseline.getResolutionNode(), -constraintWidget.mBaselineDistance);
                    }
                } else if (constraintWidget.mTop.mTarget != null && constraintWidget.mBottom.mTarget == null) {
                    resolutionNode2.setType(1);
                    resolutionNode4.setType(1);
                    if (z2) {
                        resolutionNode4.dependsOn(resolutionNode2, 1, constraintWidget.getResolutionHeight());
                    } else {
                        resolutionNode4.dependsOn(resolutionNode2, constraintWidget.getHeight());
                    }
                    if (constraintWidget.mBaselineDistance > 0) {
                        constraintWidget.mBaseline.getResolutionNode().dependsOn(1, resolutionNode2, constraintWidget.mBaselineDistance);
                    }
                } else if (constraintWidget.mTop.mTarget == null && constraintWidget.mBottom.mTarget != null) {
                    resolutionNode2.setType(1);
                    resolutionNode4.setType(1);
                    if (z2) {
                        resolutionNode2.dependsOn(resolutionNode4, -1, constraintWidget.getResolutionHeight());
                    } else {
                        resolutionNode2.dependsOn(resolutionNode4, -constraintWidget.getHeight());
                    }
                    if (constraintWidget.mBaselineDistance > 0) {
                        constraintWidget.mBaseline.getResolutionNode().dependsOn(1, resolutionNode2, constraintWidget.mBaselineDistance);
                    }
                } else if (constraintWidget.mTop.mTarget != null && constraintWidget.mBottom.mTarget != null) {
                    resolutionNode2.setType(2);
                    resolutionNode4.setType(2);
                    if (z2) {
                        resolutionNode2.setOpposite(resolutionNode4, -1, constraintWidget.getResolutionHeight());
                        resolutionNode4.setOpposite(resolutionNode2, 1, constraintWidget.getResolutionHeight());
                        constraintWidget.getResolutionHeight().addDependent(resolutionNode2);
                        constraintWidget.getResolutionWidth().addDependent(resolutionNode4);
                    } else {
                        resolutionNode2.setOpposite(resolutionNode4, (float) (-constraintWidget.getHeight()));
                        resolutionNode4.setOpposite(resolutionNode2, (float) constraintWidget.getHeight());
                    }
                    if (constraintWidget.mBaselineDistance > 0) {
                        constraintWidget.mBaseline.getResolutionNode().dependsOn(1, resolutionNode2, constraintWidget.mBaselineDistance);
                    }
                }
            } else if (z) {
                int height = constraintWidget.getHeight();
                resolutionNode2.setType(1);
                resolutionNode4.setType(1);
                if (constraintWidget.mTop.mTarget == null && constraintWidget.mBottom.mTarget == null) {
                    if (z2) {
                        resolutionNode4.dependsOn(resolutionNode2, 1, constraintWidget.getResolutionHeight());
                    } else {
                        resolutionNode4.dependsOn(resolutionNode2, height);
                    }
                } else if (constraintWidget.mTop.mTarget == null || constraintWidget.mBottom.mTarget != null) {
                    if (constraintWidget.mTop.mTarget != null || constraintWidget.mBottom.mTarget == null) {
                        if (constraintWidget.mTop.mTarget != null && constraintWidget.mBottom.mTarget != null) {
                            if (z2) {
                                constraintWidget.getResolutionHeight().addDependent(resolutionNode2);
                                constraintWidget.getResolutionWidth().addDependent(resolutionNode4);
                            }
                            if (constraintWidget.mDimensionRatio == 0.0f) {
                                resolutionNode2.setType(3);
                                resolutionNode4.setType(3);
                                resolutionNode2.setOpposite(resolutionNode4, 0.0f);
                                resolutionNode4.setOpposite(resolutionNode2, 0.0f);
                                return;
                            }
                            resolutionNode2.setType(2);
                            resolutionNode4.setType(2);
                            resolutionNode2.setOpposite(resolutionNode4, (float) (-height));
                            resolutionNode4.setOpposite(resolutionNode2, (float) height);
                            constraintWidget.setHeight(height);
                            if (constraintWidget.mBaselineDistance > 0) {
                                constraintWidget.mBaseline.getResolutionNode().dependsOn(1, resolutionNode2, constraintWidget.mBaselineDistance);
                            }
                        }
                    } else if (z2) {
                        resolutionNode2.dependsOn(resolutionNode4, -1, constraintWidget.getResolutionHeight());
                    } else {
                        resolutionNode2.dependsOn(resolutionNode4, -height);
                    }
                } else if (z2) {
                    resolutionNode4.dependsOn(resolutionNode2, 1, constraintWidget.getResolutionHeight());
                } else {
                    resolutionNode4.dependsOn(resolutionNode2, height);
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0127, code lost:
        if (r7.mListAnchors[r22].mTarget.mOwner == r8) goto L_0x012a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static boolean applyChainOptimized(android.support.constraint.solver.widgets.ConstraintWidgetContainer r19, android.support.constraint.solver.LinearSystem r20, int r21, int r22, android.support.constraint.solver.widgets.ChainHead r23) {
        /*
            r0 = r23
            android.support.constraint.solver.widgets.ConstraintWidget r12 = r0.mFirst
            r0 = r23
            android.support.constraint.solver.widgets.ConstraintWidget r14 = r0.mLast
            r0 = r23
            android.support.constraint.solver.widgets.ConstraintWidget r15 = r0.mFirstVisibleWidget
            r0 = r23
            android.support.constraint.solver.widgets.ConstraintWidget r13 = r0.mLastVisibleWidget
            r0 = r23
            android.support.constraint.solver.widgets.ConstraintWidget r4 = r0.mHead
            r6 = 0
            r0 = r23
            float r0 = r0.mTotalWeight
            r16 = r0
            r0 = r23
            android.support.constraint.solver.widgets.ConstraintWidget r2 = r0.mFirstMatchConstraintWidget
            r0 = r23
            android.support.constraint.solver.widgets.ConstraintWidget r2 = r0.mLastMatchConstraintWidget
            r0 = r19
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r2 = r0.mListDimensionBehaviors
            r2 = r2[r21]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r3 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r2 != r3) goto L_0x002d
        L_0x002d:
            if (r21 != 0) goto L_0x00b4
            int r2 = r4.mHorizontalChainStyle
            if (r2 != 0) goto L_0x00ae
            r2 = 1
        L_0x0034:
            int r3 = r4.mHorizontalChainStyle
            r5 = 1
            if (r3 != r5) goto L_0x00b0
            r3 = 1
        L_0x003a:
            int r4 = r4.mHorizontalChainStyle
            r5 = 2
            if (r4 != r5) goto L_0x00b2
            r4 = 1
        L_0x0040:
            r9 = 0
            r5 = 0
            r10 = 0
            r11 = 0
            r8 = r12
        L_0x0045:
            if (r6 != 0) goto L_0x0132
            int r7 = r8.getVisibility()
            r17 = 8
            r0 = r17
            if (r7 == r0) goto L_0x008c
            int r11 = r11 + 1
            if (r21 != 0) goto L_0x00ce
            int r7 = r8.getWidth()
            float r7 = (float) r7
            float r7 = r7 + r10
        L_0x005b:
            if (r8 == r15) goto L_0x0067
            android.support.constraint.solver.widgets.ConstraintAnchor[] r10 = r8.mListAnchors
            r10 = r10[r22]
            int r10 = r10.getMargin()
            float r10 = (float) r10
            float r7 = r7 + r10
        L_0x0067:
            if (r8 == r13) goto L_0x0075
            android.support.constraint.solver.widgets.ConstraintAnchor[] r10 = r8.mListAnchors
            int r17 = r22 + 1
            r10 = r10[r17]
            int r10 = r10.getMargin()
            float r10 = (float) r10
            float r7 = r7 + r10
        L_0x0075:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r10 = r8.mListAnchors
            r10 = r10[r22]
            int r10 = r10.getMargin()
            float r10 = (float) r10
            float r9 = r9 + r10
            android.support.constraint.solver.widgets.ConstraintAnchor[] r10 = r8.mListAnchors
            int r17 = r22 + 1
            r10 = r10[r17]
            int r10 = r10.getMargin()
            float r10 = (float) r10
            float r9 = r9 + r10
            r10 = r7
        L_0x008c:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r8.mListAnchors
            r7 = r7[r22]
            int r7 = r8.getVisibility()
            r17 = 8
            r0 = r17
            if (r7 == r0) goto L_0x00f9
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r7 = r8.mListDimensionBehaviors
            r7 = r7[r21]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r17 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            r0 = r17
            if (r7 != r0) goto L_0x00f9
            int r5 = r5 + 1
            if (r21 != 0) goto L_0x00df
            int r7 = r8.mMatchConstraintDefaultWidth
            if (r7 == 0) goto L_0x00d5
            r2 = 0
        L_0x00ad:
            return r2
        L_0x00ae:
            r2 = 0
            goto L_0x0034
        L_0x00b0:
            r3 = 0
            goto L_0x003a
        L_0x00b2:
            r4 = 0
            goto L_0x0040
        L_0x00b4:
            int r2 = r4.mVerticalChainStyle
            if (r2 != 0) goto L_0x00c7
            r2 = 1
        L_0x00b9:
            int r3 = r4.mVerticalChainStyle
            r5 = 1
            if (r3 != r5) goto L_0x00c9
            r3 = 1
        L_0x00bf:
            int r4 = r4.mVerticalChainStyle
            r5 = 2
            if (r4 != r5) goto L_0x00cb
            r4 = 1
            goto L_0x0040
        L_0x00c7:
            r2 = 0
            goto L_0x00b9
        L_0x00c9:
            r3 = 0
            goto L_0x00bf
        L_0x00cb:
            r4 = 0
            goto L_0x0040
        L_0x00ce:
            int r7 = r8.getHeight()
            float r7 = (float) r7
            float r7 = r7 + r10
            goto L_0x005b
        L_0x00d5:
            int r7 = r8.mMatchConstraintMinWidth
            if (r7 != 0) goto L_0x00dd
            int r7 = r8.mMatchConstraintMaxWidth
            if (r7 == 0) goto L_0x00ef
        L_0x00dd:
            r2 = 0
            goto L_0x00ad
        L_0x00df:
            int r7 = r8.mMatchConstraintDefaultHeight
            if (r7 == 0) goto L_0x00e5
            r2 = 0
            goto L_0x00ad
        L_0x00e5:
            int r7 = r8.mMatchConstraintMinHeight
            if (r7 != 0) goto L_0x00ed
            int r7 = r8.mMatchConstraintMaxHeight
            if (r7 == 0) goto L_0x00ef
        L_0x00ed:
            r2 = 0
            goto L_0x00ad
        L_0x00ef:
            float r7 = r8.mDimensionRatio
            r17 = 0
            int r7 = (r7 > r17 ? 1 : (r7 == r17 ? 0 : -1))
            if (r7 == 0) goto L_0x00f9
            r2 = 0
            goto L_0x00ad
        L_0x00f9:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r8.mListAnchors
            int r17 = r22 + 1
            r7 = r7[r17]
            android.support.constraint.solver.widgets.ConstraintAnchor r7 = r7.mTarget
            if (r7 == 0) goto L_0x0129
            android.support.constraint.solver.widgets.ConstraintWidget r7 = r7.mOwner
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r7.mListAnchors
            r17 = r0
            r17 = r17[r22]
            r0 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r17 = r0
            if (r17 == 0) goto L_0x0129
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r7.mListAnchors
            r17 = r0
            r17 = r17[r22]
            r0 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r17 = r0
            r0 = r17
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mOwner
            r17 = r0
            r0 = r17
            if (r0 == r8) goto L_0x012a
        L_0x0129:
            r7 = 0
        L_0x012a:
            if (r7 == 0) goto L_0x012f
        L_0x012c:
            r8 = r7
            goto L_0x0045
        L_0x012f:
            r6 = 1
            r7 = r8
            goto L_0x012c
        L_0x0132:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r6 = r12.mListAnchors
            r6 = r6[r22]
            android.support.constraint.solver.widgets.ResolutionAnchor r17 = r6.getResolutionNode()
            android.support.constraint.solver.widgets.ConstraintAnchor[] r6 = r14.mListAnchors
            int r7 = r22 + 1
            r6 = r6[r7]
            android.support.constraint.solver.widgets.ResolutionAnchor r18 = r6.getResolutionNode()
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r6 = r0.target
            if (r6 == 0) goto L_0x0150
            r0 = r18
            android.support.constraint.solver.widgets.ResolutionAnchor r6 = r0.target
            if (r6 != 0) goto L_0x0153
        L_0x0150:
            r2 = 0
            goto L_0x00ad
        L_0x0153:
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r6 = r0.target
            int r6 = r6.state
            r7 = 1
            if (r6 != r7) goto L_0x0165
            r0 = r18
            android.support.constraint.solver.widgets.ResolutionAnchor r6 = r0.target
            int r6 = r6.state
            r7 = 1
            if (r6 == r7) goto L_0x0168
        L_0x0165:
            r2 = 0
            goto L_0x00ad
        L_0x0168:
            if (r5 <= 0) goto L_0x016f
            if (r5 == r11) goto L_0x016f
            r2 = 0
            goto L_0x00ad
        L_0x016f:
            r6 = 0
            r7 = 0
            if (r4 != 0) goto L_0x0177
            if (r2 != 0) goto L_0x0177
            if (r3 == 0) goto L_0x0190
        L_0x0177:
            if (r15 == 0) goto L_0x040d
            android.support.constraint.solver.widgets.ConstraintAnchor[] r6 = r15.mListAnchors
            r6 = r6[r22]
            int r6 = r6.getMargin()
            float r6 = (float) r6
        L_0x0182:
            if (r13 == 0) goto L_0x0190
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r13.mListAnchors
            int r13 = r22 + 1
            r7 = r7[r13]
            int r7 = r7.getMargin()
            float r7 = (float) r7
            float r6 = r6 + r7
        L_0x0190:
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r0.target
            float r7 = r7.resolvedOffset
            r0 = r18
            android.support.constraint.solver.widgets.ResolutionAnchor r13 = r0.target
            float r13 = r13.resolvedOffset
            int r18 = (r7 > r13 ? 1 : (r7 == r13 ? 0 : -1))
            if (r18 >= 0) goto L_0x01bb
            float r13 = r13 - r7
            float r13 = r13 - r10
        L_0x01a2:
            if (r5 <= 0) goto L_0x026f
            if (r5 != r11) goto L_0x026f
            android.support.constraint.solver.widgets.ConstraintWidget r2 = r8.getParent()
            if (r2 == 0) goto L_0x01bf
            android.support.constraint.solver.widgets.ConstraintWidget r2 = r8.getParent()
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r2 = r2.mListDimensionBehaviors
            r2 = r2[r21]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r3 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            if (r2 != r3) goto L_0x01bf
            r2 = 0
            goto L_0x00ad
        L_0x01bb:
            float r13 = r7 - r13
            float r13 = r13 - r10
            goto L_0x01a2
        L_0x01bf:
            float r2 = r13 + r10
            float r6 = r2 - r9
            r3 = r7
        L_0x01c4:
            if (r12 == 0) goto L_0x026c
            android.support.constraint.solver.Metrics r2 = android.support.constraint.solver.LinearSystem.sMetrics
            if (r2 == 0) goto L_0x01e5
            android.support.constraint.solver.Metrics r2 = android.support.constraint.solver.LinearSystem.sMetrics
            long r8 = r2.nonresolvedWidgets
            r10 = 1
            long r8 = r8 - r10
            r2.nonresolvedWidgets = r8
            android.support.constraint.solver.Metrics r2 = android.support.constraint.solver.LinearSystem.sMetrics
            long r8 = r2.resolvedWidgets
            r10 = 1
            long r8 = r8 + r10
            r2.resolvedWidgets = r8
            android.support.constraint.solver.Metrics r2 = android.support.constraint.solver.LinearSystem.sMetrics
            long r8 = r2.chainConnectionResolved
            r10 = 1
            long r8 = r8 + r10
            r2.chainConnectionResolved = r8
        L_0x01e5:
            android.support.constraint.solver.widgets.ConstraintWidget[] r2 = r12.mNextChainWidget
            r4 = r2[r21]
            if (r4 != 0) goto L_0x01ed
            if (r12 != r14) goto L_0x0262
        L_0x01ed:
            float r2 = (float) r5
            float r2 = r6 / r2
            r7 = 0
            int r7 = (r16 > r7 ? 1 : (r16 == r7 ? 0 : -1))
            if (r7 <= 0) goto L_0x0200
            float[] r2 = r12.mWeight
            r2 = r2[r21]
            r7 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r2 = (r2 > r7 ? 1 : (r2 == r7 ? 0 : -1))
            if (r2 != 0) goto L_0x0264
            r2 = 0
        L_0x0200:
            int r7 = r12.getVisibility()
            r8 = 8
            if (r7 != r8) goto L_0x0209
            r2 = 0
        L_0x0209:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r12.mListAnchors
            r7 = r7[r22]
            int r7 = r7.getMargin()
            float r7 = (float) r7
            float r3 = r3 + r7
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r12.mListAnchors
            r7 = r7[r22]
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r7.getResolutionNode()
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r8 = r0.resolvedTarget
            r7.resolve(r8, r3)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r12.mListAnchors
            int r8 = r22 + 1
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r7.getResolutionNode()
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r8 = r0.resolvedTarget
            float r9 = r3 + r2
            r7.resolve(r8, r9)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r12.mListAnchors
            r7 = r7[r22]
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r7.getResolutionNode()
            r0 = r20
            r7.addResolvedValue(r0)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r12.mListAnchors
            int r8 = r22 + 1
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r7.getResolutionNode()
            r0 = r20
            r7.addResolvedValue(r0)
            float r2 = r2 + r3
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r12.mListAnchors
            int r7 = r22 + 1
            r3 = r3[r7]
            int r3 = r3.getMargin()
            float r3 = (float) r3
            float r2 = r2 + r3
        L_0x025e:
            r3 = r2
            r12 = r4
            goto L_0x01c4
        L_0x0262:
            r2 = r3
            goto L_0x025e
        L_0x0264:
            float[] r2 = r12.mWeight
            r2 = r2[r21]
            float r2 = r2 * r6
            float r2 = r2 / r16
            goto L_0x0200
        L_0x026c:
            r2 = 1
            goto L_0x00ad
        L_0x026f:
            r5 = 0
            int r5 = (r13 > r5 ? 1 : (r13 == r5 ? 0 : -1))
            if (r5 >= 0) goto L_0x0409
            r3 = 0
            r4 = 1
            r2 = 0
            r5 = r3
            r8 = r2
        L_0x0279:
            if (r4 == 0) goto L_0x0315
            r0 = r21
            float r2 = r12.getBiasPercent(r0)
            float r3 = r13 - r6
            float r2 = r2 * r3
            float r3 = r7 + r2
        L_0x0286:
            if (r12 == 0) goto L_0x03fd
            android.support.constraint.solver.Metrics r2 = android.support.constraint.solver.LinearSystem.sMetrics
            if (r2 == 0) goto L_0x02a7
            android.support.constraint.solver.Metrics r2 = android.support.constraint.solver.LinearSystem.sMetrics
            long r4 = r2.nonresolvedWidgets
            r6 = 1
            long r4 = r4 - r6
            r2.nonresolvedWidgets = r4
            android.support.constraint.solver.Metrics r2 = android.support.constraint.solver.LinearSystem.sMetrics
            long r4 = r2.resolvedWidgets
            r6 = 1
            long r4 = r4 + r6
            r2.resolvedWidgets = r4
            android.support.constraint.solver.Metrics r2 = android.support.constraint.solver.LinearSystem.sMetrics
            long r4 = r2.chainConnectionResolved
            r6 = 1
            long r4 = r4 + r6
            r2.chainConnectionResolved = r4
        L_0x02a7:
            android.support.constraint.solver.widgets.ConstraintWidget[] r2 = r12.mNextChainWidget
            r4 = r2[r21]
            if (r4 != 0) goto L_0x02af
            if (r12 != r14) goto L_0x0406
        L_0x02af:
            if (r21 != 0) goto L_0x030f
            int r2 = r12.getWidth()
            float r2 = (float) r2
        L_0x02b6:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r12.mListAnchors
            r5 = r5[r22]
            int r5 = r5.getMargin()
            float r5 = (float) r5
            float r3 = r3 + r5
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r12.mListAnchors
            r5 = r5[r22]
            android.support.constraint.solver.widgets.ResolutionAnchor r5 = r5.getResolutionNode()
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r6 = r0.resolvedTarget
            r5.resolve(r6, r3)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r12.mListAnchors
            int r6 = r22 + 1
            r5 = r5[r6]
            android.support.constraint.solver.widgets.ResolutionAnchor r5 = r5.getResolutionNode()
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r6 = r0.resolvedTarget
            float r7 = r3 + r2
            r5.resolve(r6, r7)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r12.mListAnchors
            r5 = r5[r22]
            android.support.constraint.solver.widgets.ResolutionAnchor r5 = r5.getResolutionNode()
            r0 = r20
            r5.addResolvedValue(r0)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r12.mListAnchors
            int r6 = r22 + 1
            r5 = r5[r6]
            android.support.constraint.solver.widgets.ResolutionAnchor r5 = r5.getResolutionNode()
            r0 = r20
            r5.addResolvedValue(r0)
            float r2 = r2 + r3
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r12.mListAnchors
            int r5 = r22 + 1
            r3 = r3[r5]
            int r3 = r3.getMargin()
            float r3 = (float) r3
            float r2 = r2 + r3
        L_0x030b:
            r3 = r2
            r12 = r4
            goto L_0x0286
        L_0x030f:
            int r2 = r12.getHeight()
            float r2 = (float) r2
            goto L_0x02b6
        L_0x0315:
            if (r8 != 0) goto L_0x0319
            if (r5 == 0) goto L_0x03fd
        L_0x0319:
            if (r8 == 0) goto L_0x03ea
            float r2 = r13 - r6
            r3 = r2
        L_0x031e:
            int r2 = r11 + 1
            float r2 = (float) r2
            float r2 = r3 / r2
            if (r5 == 0) goto L_0x032d
            r2 = 1
            if (r11 <= r2) goto L_0x03f1
            int r2 = r11 + -1
            float r2 = (float) r2
            float r2 = r3 / r2
        L_0x032d:
            int r3 = r12.getVisibility()
            r4 = 8
            if (r3 == r4) goto L_0x0400
            float r3 = r7 + r2
        L_0x0337:
            if (r5 == 0) goto L_0x0346
            r4 = 1
            if (r11 <= r4) goto L_0x0346
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r15.mListAnchors
            r3 = r3[r22]
            int r3 = r3.getMargin()
            float r3 = (float) r3
            float r3 = r3 + r7
        L_0x0346:
            if (r8 == 0) goto L_0x0354
            if (r15 == 0) goto L_0x0354
            android.support.constraint.solver.widgets.ConstraintAnchor[] r4 = r15.mListAnchors
            r4 = r4[r22]
            int r4 = r4.getMargin()
            float r4 = (float) r4
            float r3 = r3 + r4
        L_0x0354:
            r5 = r12
        L_0x0355:
            if (r5 == 0) goto L_0x03fd
            android.support.constraint.solver.Metrics r4 = android.support.constraint.solver.LinearSystem.sMetrics
            if (r4 == 0) goto L_0x0376
            android.support.constraint.solver.Metrics r4 = android.support.constraint.solver.LinearSystem.sMetrics
            long r6 = r4.nonresolvedWidgets
            r8 = 1
            long r6 = r6 - r8
            r4.nonresolvedWidgets = r6
            android.support.constraint.solver.Metrics r4 = android.support.constraint.solver.LinearSystem.sMetrics
            long r6 = r4.resolvedWidgets
            r8 = 1
            long r6 = r6 + r8
            r4.resolvedWidgets = r6
            android.support.constraint.solver.Metrics r4 = android.support.constraint.solver.LinearSystem.sMetrics
            long r6 = r4.chainConnectionResolved
            r8 = 1
            long r6 = r6 + r8
            r4.chainConnectionResolved = r6
        L_0x0376:
            android.support.constraint.solver.widgets.ConstraintWidget[] r4 = r5.mNextChainWidget
            r6 = r4[r21]
            if (r6 != 0) goto L_0x037e
            if (r5 != r14) goto L_0x03e7
        L_0x037e:
            if (r21 != 0) goto L_0x03f7
            int r4 = r5.getWidth()
            float r4 = (float) r4
        L_0x0385:
            if (r5 == r15) goto L_0x0391
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r5.mListAnchors
            r7 = r7[r22]
            int r7 = r7.getMargin()
            float r7 = (float) r7
            float r3 = r3 + r7
        L_0x0391:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r5.mListAnchors
            r7 = r7[r22]
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r7.getResolutionNode()
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r8 = r0.resolvedTarget
            r7.resolve(r8, r3)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r5.mListAnchors
            int r8 = r22 + 1
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r7.getResolutionNode()
            r0 = r17
            android.support.constraint.solver.widgets.ResolutionAnchor r8 = r0.resolvedTarget
            float r9 = r3 + r4
            r7.resolve(r8, r9)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r5.mListAnchors
            r7 = r7[r22]
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r7.getResolutionNode()
            r0 = r20
            r7.addResolvedValue(r0)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r7 = r5.mListAnchors
            int r8 = r22 + 1
            r7 = r7[r8]
            android.support.constraint.solver.widgets.ResolutionAnchor r7 = r7.getResolutionNode()
            r0 = r20
            r7.addResolvedValue(r0)
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r5.mListAnchors
            int r7 = r22 + 1
            r5 = r5[r7]
            int r5 = r5.getMargin()
            float r5 = (float) r5
            float r4 = r4 + r5
            float r3 = r3 + r4
            if (r6 == 0) goto L_0x03e7
            int r4 = r6.getVisibility()
            r5 = 8
            if (r4 == r5) goto L_0x03e7
            float r3 = r3 + r2
        L_0x03e7:
            r5 = r6
            goto L_0x0355
        L_0x03ea:
            if (r5 == 0) goto L_0x0403
            float r2 = r13 - r6
            r3 = r2
            goto L_0x031e
        L_0x03f1:
            r2 = 1073741824(0x40000000, float:2.0)
            float r2 = r3 / r2
            goto L_0x032d
        L_0x03f7:
            int r4 = r5.getHeight()
            float r4 = (float) r4
            goto L_0x0385
        L_0x03fd:
            r2 = 1
            goto L_0x00ad
        L_0x0400:
            r3 = r7
            goto L_0x0337
        L_0x0403:
            r3 = r13
            goto L_0x031e
        L_0x0406:
            r2 = r3
            goto L_0x030b
        L_0x0409:
            r5 = r3
            r8 = r2
            goto L_0x0279
        L_0x040d:
            r6 = r7
            goto L_0x0182
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.solver.widgets.Optimizer.applyChainOptimized(android.support.constraint.solver.widgets.ConstraintWidgetContainer, android.support.constraint.solver.LinearSystem, int, int, android.support.constraint.solver.widgets.ChainHead):boolean");
    }

    static void checkMatchParent(ConstraintWidgetContainer constraintWidgetContainer, LinearSystem linearSystem, ConstraintWidget constraintWidget) {
        if (constraintWidgetContainer.mListDimensionBehaviors[0] != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT && constraintWidget.mListDimensionBehaviors[0] == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
            int i = constraintWidget.mLeft.mMargin;
            int width = constraintWidgetContainer.getWidth() - constraintWidget.mRight.mMargin;
            constraintWidget.mLeft.mSolverVariable = linearSystem.createObjectVariable(constraintWidget.mLeft);
            constraintWidget.mRight.mSolverVariable = linearSystem.createObjectVariable(constraintWidget.mRight);
            linearSystem.addEquality(constraintWidget.mLeft.mSolverVariable, i);
            linearSystem.addEquality(constraintWidget.mRight.mSolverVariable, width);
            constraintWidget.mHorizontalResolution = 2;
            constraintWidget.setHorizontalDimension(i, width);
        }
        if (constraintWidgetContainer.mListDimensionBehaviors[1] != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT && constraintWidget.mListDimensionBehaviors[1] == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
            int i2 = constraintWidget.mTop.mMargin;
            int height = constraintWidgetContainer.getHeight() - constraintWidget.mBottom.mMargin;
            constraintWidget.mTop.mSolverVariable = linearSystem.createObjectVariable(constraintWidget.mTop);
            constraintWidget.mBottom.mSolverVariable = linearSystem.createObjectVariable(constraintWidget.mBottom);
            linearSystem.addEquality(constraintWidget.mTop.mSolverVariable, i2);
            linearSystem.addEquality(constraintWidget.mBottom.mSolverVariable, height);
            if (constraintWidget.mBaselineDistance > 0 || constraintWidget.getVisibility() == 8) {
                constraintWidget.mBaseline.mSolverVariable = linearSystem.createObjectVariable(constraintWidget.mBaseline);
                linearSystem.addEquality(constraintWidget.mBaseline.mSolverVariable, constraintWidget.mBaselineDistance + i2);
            }
            constraintWidget.mVerticalResolution = 2;
            constraintWidget.setVerticalDimension(i2, height);
        }
    }

    private static boolean optimizableMatchConstraint(ConstraintWidget constraintWidget, int i) {
        char c = 1;
        if (constraintWidget.mListDimensionBehaviors[i] != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            return false;
        }
        if (constraintWidget.mDimensionRatio != 0.0f) {
            ConstraintWidget.DimensionBehaviour[] dimensionBehaviourArr = constraintWidget.mListDimensionBehaviors;
            if (i != 0) {
                c = 0;
            }
            if (dimensionBehaviourArr[c] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            }
            return false;
        }
        if (i == 0) {
            if (!(constraintWidget.mMatchConstraintDefaultWidth == 0 && constraintWidget.mMatchConstraintMinWidth == 0 && constraintWidget.mMatchConstraintMaxWidth == 0)) {
                return false;
            }
        } else if (!(constraintWidget.mMatchConstraintDefaultHeight == 0 && constraintWidget.mMatchConstraintMinHeight == 0 && constraintWidget.mMatchConstraintMaxHeight == 0)) {
            return false;
        }
        return true;
    }

    static void setOptimizedWidget(ConstraintWidget constraintWidget, int i, int i2) {
        int i3 = i * 2;
        int i4 = i3 + 1;
        constraintWidget.mListAnchors[i3].getResolutionNode().resolvedTarget = constraintWidget.getParent().mLeft.getResolutionNode();
        constraintWidget.mListAnchors[i3].getResolutionNode().resolvedOffset = (float) i2;
        constraintWidget.mListAnchors[i3].getResolutionNode().state = 1;
        constraintWidget.mListAnchors[i4].getResolutionNode().resolvedTarget = constraintWidget.mListAnchors[i3].getResolutionNode();
        constraintWidget.mListAnchors[i4].getResolutionNode().resolvedOffset = (float) constraintWidget.getLength(i);
        constraintWidget.mListAnchors[i4].getResolutionNode().state = 1;
    }
}
