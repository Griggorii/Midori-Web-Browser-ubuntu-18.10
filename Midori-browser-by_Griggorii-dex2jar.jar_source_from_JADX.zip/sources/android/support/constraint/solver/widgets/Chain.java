package android.support.constraint.solver.widgets;

import android.support.constraint.solver.LinearSystem;

class Chain {
    private static final boolean DEBUG = false;

    Chain() {
    }

    static void applyChainConstraints(ConstraintWidgetContainer constraintWidgetContainer, LinearSystem linearSystem, int i) {
        int i2;
        int i3;
        ChainHead[] chainHeadArr;
        if (i == 0) {
            i3 = constraintWidgetContainer.mHorizontalChainsSize;
            chainHeadArr = constraintWidgetContainer.mHorizontalChainsArray;
            i2 = 0;
        } else {
            i2 = 2;
            i3 = constraintWidgetContainer.mVerticalChainsSize;
            chainHeadArr = constraintWidgetContainer.mVerticalChainsArray;
        }
        for (int i4 = 0; i4 < i3; i4++) {
            ChainHead chainHead = chainHeadArr[i4];
            chainHead.define();
            if (!constraintWidgetContainer.optimizeFor(4)) {
                applyChainConstraints(constraintWidgetContainer, linearSystem, i, i2, chainHead);
            } else if (!Optimizer.applyChainOptimized(constraintWidgetContainer, linearSystem, i, i2, chainHead)) {
                applyChainConstraints(constraintWidgetContainer, linearSystem, i, i2, chainHead);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:127:0x02a4 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:131:0x02b8  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x02c0  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x02c8  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x02da  */
    /* JADX WARNING: Removed duplicated region for block: B:144:0x02e8 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:277:0x0544  */
    /* JADX WARNING: Removed duplicated region for block: B:278:0x0547  */
    /* JADX WARNING: Removed duplicated region for block: B:281:0x0551  */
    /* JADX WARNING: Removed duplicated region for block: B:306:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void applyChainConstraints(android.support.constraint.solver.widgets.ConstraintWidgetContainer r21, android.support.constraint.solver.LinearSystem r22, int r23, int r24, android.support.constraint.solver.widgets.ChainHead r25) {
        /*
            r0 = r25
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mFirst
            r19 = r0
            r0 = r25
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mLast
            r16 = r0
            r0 = r25
            android.support.constraint.solver.widgets.ConstraintWidget r15 = r0.mFirstVisibleWidget
            r0 = r25
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mLastVisibleWidget
            r18 = r0
            r0 = r25
            android.support.constraint.solver.widgets.ConstraintWidget r14 = r0.mHead
            r0 = r25
            float r5 = r0.mTotalWeight
            r0 = r25
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r0.mFirstMatchConstraintWidget
            r0 = r25
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r0.mLastMatchConstraintWidget
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r0.mListDimensionBehaviors
            r1 = r1[r23]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r2 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            r6 = 0
            if (r1 != r2) goto L_0x00f3
            r1 = 1
            r7 = r1
        L_0x0033:
            if (r23 != 0) goto L_0x0100
            int r1 = r14.mHorizontalChainStyle
            if (r1 != 0) goto L_0x00f7
            r1 = 1
        L_0x003a:
            int r2 = r14.mHorizontalChainStyle
            r3 = 1
            if (r2 != r3) goto L_0x00fa
            r2 = 1
        L_0x0040:
            int r3 = r14.mHorizontalChainStyle
            r4 = 2
            if (r3 != r4) goto L_0x00fd
            r3 = 1
        L_0x0046:
            r10 = r2
            r11 = r3
            r12 = r1
        L_0x0049:
            r2 = r6
            r4 = r19
        L_0x004c:
            if (r2 != 0) goto L_0x0136
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r4.mListAnchors
            r6 = r1[r24]
            r1 = 4
            if (r7 != 0) goto L_0x0057
            if (r11 == 0) goto L_0x0058
        L_0x0057:
            r1 = 1
        L_0x0058:
            int r3 = r6.getMargin()
            android.support.constraint.solver.widgets.ConstraintAnchor r8 = r6.mTarget
            if (r8 == 0) goto L_0x006b
            r0 = r19
            if (r4 == r0) goto L_0x006b
            android.support.constraint.solver.widgets.ConstraintAnchor r8 = r6.mTarget
            int r8 = r8.getMargin()
            int r3 = r3 + r8
        L_0x006b:
            if (r11 == 0) goto L_0x011c
            r0 = r19
            if (r4 == r0) goto L_0x011c
            if (r4 == r15) goto L_0x011c
            r1 = 6
        L_0x0074:
            android.support.constraint.solver.widgets.ConstraintAnchor r8 = r6.mTarget
            if (r8 == 0) goto L_0x0091
            if (r4 != r15) goto L_0x0123
            android.support.constraint.solver.SolverVariable r8 = r6.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor r9 = r6.mTarget
            android.support.constraint.solver.SolverVariable r9 = r9.mSolverVariable
            r13 = 5
            r0 = r22
            r0.addGreaterThan(r8, r9, r3, r13)
        L_0x0086:
            android.support.constraint.solver.SolverVariable r8 = r6.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r6.mTarget
            android.support.constraint.solver.SolverVariable r6 = r6.mSolverVariable
            r0 = r22
            r0.addEquality(r8, r6, r3, r1)
        L_0x0091:
            if (r7 == 0) goto L_0x00cd
            int r1 = r4.getVisibility()
            r3 = 8
            if (r1 == r3) goto L_0x00b8
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r1 = r4.mListDimensionBehaviors
            r1 = r1[r23]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r3 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            if (r1 != r3) goto L_0x00b8
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r4.mListAnchors
            int r3 = r24 + 1
            r1 = r1[r3]
            android.support.constraint.solver.SolverVariable r1 = r1.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r4.mListAnchors
            r3 = r3[r24]
            android.support.constraint.solver.SolverVariable r3 = r3.mSolverVariable
            r6 = 0
            r8 = 5
            r0 = r22
            r0.addGreaterThan(r1, r3, r6, r8)
        L_0x00b8:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r4.mListAnchors
            r1 = r1[r24]
            android.support.constraint.solver.SolverVariable r1 = r1.mSolverVariable
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r0.mListAnchors
            r3 = r3[r24]
            android.support.constraint.solver.SolverVariable r3 = r3.mSolverVariable
            r6 = 0
            r8 = 6
            r0 = r22
            r0.addGreaterThan(r1, r3, r6, r8)
        L_0x00cd:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r4.mListAnchors
            int r3 = r24 + 1
            r1 = r1[r3]
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r1.mTarget
            if (r1 == 0) goto L_0x0131
            android.support.constraint.solver.widgets.ConstraintWidget r3 = r1.mOwner
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r3.mListAnchors
            r1 = r1[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r1.mTarget
            if (r1 == 0) goto L_0x00eb
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r3.mListAnchors
            r1 = r1[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r1.mTarget
            android.support.constraint.solver.widgets.ConstraintWidget r1 = r1.mOwner
            if (r1 == r4) goto L_0x00ec
        L_0x00eb:
            r3 = 0
        L_0x00ec:
            if (r3 == 0) goto L_0x0133
            r1 = r2
        L_0x00ef:
            r2 = r1
            r4 = r3
            goto L_0x004c
        L_0x00f3:
            r1 = 0
            r7 = r1
            goto L_0x0033
        L_0x00f7:
            r1 = 0
            goto L_0x003a
        L_0x00fa:
            r2 = 0
            goto L_0x0040
        L_0x00fd:
            r3 = 0
            goto L_0x0046
        L_0x0100:
            int r1 = r14.mVerticalChainStyle
            if (r1 != 0) goto L_0x0116
            r1 = 1
        L_0x0105:
            int r2 = r14.mVerticalChainStyle
            r3 = 1
            if (r2 != r3) goto L_0x0118
            r2 = 1
        L_0x010b:
            int r3 = r14.mVerticalChainStyle
            r4 = 2
            if (r3 != r4) goto L_0x011a
            r3 = 1
        L_0x0111:
            r10 = r2
            r11 = r3
            r12 = r1
            goto L_0x0049
        L_0x0116:
            r1 = 0
            goto L_0x0105
        L_0x0118:
            r2 = 0
            goto L_0x010b
        L_0x011a:
            r3 = 0
            goto L_0x0111
        L_0x011c:
            if (r12 == 0) goto L_0x0074
            if (r7 == 0) goto L_0x0074
            r1 = 4
            goto L_0x0074
        L_0x0123:
            android.support.constraint.solver.SolverVariable r8 = r6.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor r9 = r6.mTarget
            android.support.constraint.solver.SolverVariable r9 = r9.mSolverVariable
            r13 = 6
            r0 = r22
            r0.addGreaterThan(r8, r9, r3, r13)
            goto L_0x0086
        L_0x0131:
            r3 = 0
            goto L_0x00ec
        L_0x0133:
            r1 = 1
            r3 = r4
            goto L_0x00ef
        L_0x0136:
            if (r18 == 0) goto L_0x0165
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            int r2 = r24 + 1
            r1 = r1[r2]
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r1.mTarget
            if (r1 == 0) goto L_0x0165
            r0 = r18
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            int r2 = r24 + 1
            r1 = r1[r2]
            android.support.constraint.solver.SolverVariable r2 = r1.mSolverVariable
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r0.mListAnchors
            int r4 = r24 + 1
            r3 = r3[r4]
            android.support.constraint.solver.widgets.ConstraintAnchor r3 = r3.mTarget
            android.support.constraint.solver.SolverVariable r3 = r3.mSolverVariable
            int r1 = r1.getMargin()
            int r1 = -r1
            r4 = 5
            r0 = r22
            r0.addLowerThan(r2, r3, r1, r4)
        L_0x0165:
            if (r7 == 0) goto L_0x018d
            r0 = r21
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            int r2 = r24 + 1
            r1 = r1[r2]
            android.support.constraint.solver.SolverVariable r1 = r1.mSolverVariable
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r2 = r0.mListAnchors
            int r3 = r24 + 1
            r2 = r2[r3]
            android.support.constraint.solver.SolverVariable r2 = r2.mSolverVariable
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r0.mListAnchors
            int r4 = r24 + 1
            r3 = r3[r4]
            int r3 = r3.getMargin()
            r4 = 6
            r0 = r22
            r0.addGreaterThan(r1, r2, r3, r4)
        L_0x018d:
            r0 = r25
            java.util.ArrayList<android.support.constraint.solver.widgets.ConstraintWidget> r0 = r0.mWeightedMatchConstraintsWidgets
            r17 = r0
            if (r17 == 0) goto L_0x0234
            int r20 = r17.size()
            r1 = 1
            r0 = r20
            if (r0 <= r1) goto L_0x0234
            r6 = 0
            r2 = 0
            r0 = r25
            boolean r1 = r0.mHasUndefinedWeights
            if (r1 == 0) goto L_0x055f
            r0 = r25
            boolean r1 = r0.mHasComplexMatchWeights
            if (r1 != 0) goto L_0x055f
            r0 = r25
            int r1 = r0.mWidgetsMatchCount
            float r3 = (float) r1
        L_0x01b1:
            r1 = 0
            r13 = r1
        L_0x01b3:
            r0 = r20
            if (r13 >= r0) goto L_0x0234
            r0 = r17
            java.lang.Object r1 = r0.get(r13)
            r9 = r1
            android.support.constraint.solver.widgets.ConstraintWidget r9 = (android.support.constraint.solver.widgets.ConstraintWidget) r9
            float[] r1 = r9.mWeight
            r4 = r1[r23]
            r1 = 0
            int r1 = (r4 > r1 ? 1 : (r4 == r1 ? 0 : -1))
            if (r1 >= 0) goto L_0x01ec
            r0 = r25
            boolean r1 = r0.mHasComplexMatchWeights
            if (r1 == 0) goto L_0x01ea
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r9.mListAnchors
            int r4 = r24 + 1
            r1 = r1[r4]
            android.support.constraint.solver.SolverVariable r1 = r1.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor[] r4 = r9.mListAnchors
            r4 = r4[r24]
            android.support.constraint.solver.SolverVariable r4 = r4.mSolverVariable
            r5 = 0
            r7 = 4
            r0 = r22
            r0.addEquality(r1, r4, r5, r7)
            r9 = r6
        L_0x01e5:
            int r1 = r13 + 1
            r13 = r1
            r6 = r9
            goto L_0x01b3
        L_0x01ea:
            r4 = 1065353216(0x3f800000, float:1.0)
        L_0x01ec:
            r1 = 0
            int r1 = (r4 > r1 ? 1 : (r4 == r1 ? 0 : -1))
            if (r1 != 0) goto L_0x0208
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r9.mListAnchors
            int r4 = r24 + 1
            r1 = r1[r4]
            android.support.constraint.solver.SolverVariable r1 = r1.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor[] r4 = r9.mListAnchors
            r4 = r4[r24]
            android.support.constraint.solver.SolverVariable r4 = r4.mSolverVariable
            r5 = 0
            r7 = 6
            r0 = r22
            r0.addEquality(r1, r4, r5, r7)
            r9 = r6
            goto L_0x01e5
        L_0x0208:
            if (r6 == 0) goto L_0x0232
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r6.mListAnchors
            r1 = r1[r24]
            android.support.constraint.solver.SolverVariable r5 = r1.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r6.mListAnchors
            int r6 = r24 + 1
            r1 = r1[r6]
            android.support.constraint.solver.SolverVariable r6 = r1.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r9.mListAnchors
            r1 = r1[r24]
            android.support.constraint.solver.SolverVariable r7 = r1.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r9.mListAnchors
            int r8 = r24 + 1
            r1 = r1[r8]
            android.support.constraint.solver.SolverVariable r8 = r1.mSolverVariable
            android.support.constraint.solver.ArrayRow r1 = r22.createRow()
            r1.createRowEqualMatchDimensions(r2, r3, r4, r5, r6, r7, r8)
            r0 = r22
            r0.addConstraint(r1)
        L_0x0232:
            r2 = r4
            goto L_0x01e5
        L_0x0234:
            if (r15 == 0) goto L_0x0312
            r0 = r18
            if (r15 == r0) goto L_0x023c
            if (r11 == 0) goto L_0x0312
        L_0x023c:
            r0 = r19
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            r2 = r1[r24]
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            int r3 = r24 + 1
            r1 = r1[r3]
            r0 = r19
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r0.mListAnchors
            r3 = r3[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor r3 = r3.mTarget
            if (r3 == 0) goto L_0x0308
            r0 = r19
            android.support.constraint.solver.widgets.ConstraintAnchor[] r3 = r0.mListAnchors
            r3 = r3[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor r3 = r3.mTarget
            android.support.constraint.solver.SolverVariable r3 = r3.mSolverVariable
        L_0x025e:
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r4 = r0.mListAnchors
            int r5 = r24 + 1
            r4 = r4[r5]
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.mTarget
            if (r4 == 0) goto L_0x030b
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r4 = r0.mListAnchors
            int r5 = r24 + 1
            r4 = r4[r5]
            android.support.constraint.solver.widgets.ConstraintAnchor r4 = r4.mTarget
            android.support.constraint.solver.SolverVariable r6 = r4.mSolverVariable
        L_0x0276:
            r0 = r18
            if (r15 != r0) goto L_0x0284
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r15.mListAnchors
            r2 = r1[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r15.mListAnchors
            int r4 = r24 + 1
            r1 = r1[r4]
        L_0x0284:
            if (r3 == 0) goto L_0x029e
            if (r6 == 0) goto L_0x029e
            if (r23 != 0) goto L_0x030e
            float r5 = r14.mHorizontalBiasPercent
        L_0x028c:
            int r4 = r2.getMargin()
            int r8 = r1.getMargin()
            android.support.constraint.solver.SolverVariable r2 = r2.mSolverVariable
            android.support.constraint.solver.SolverVariable r7 = r1.mSolverVariable
            r9 = 5
            r1 = r22
            r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9)
        L_0x029e:
            r1 = r15
            r2 = r16
        L_0x02a1:
            r15 = r1
        L_0x02a2:
            if (r12 != 0) goto L_0x02a6
            if (r10 == 0) goto L_0x0307
        L_0x02a6:
            if (r15 == 0) goto L_0x0307
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r15.mListAnchors
            r4 = r1[r24]
            r0 = r18
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            int r3 = r24 + 1
            r1 = r1[r3]
            android.support.constraint.solver.widgets.ConstraintAnchor r3 = r4.mTarget
            if (r3 == 0) goto L_0x0544
            android.support.constraint.solver.widgets.ConstraintAnchor r3 = r4.mTarget
            android.support.constraint.solver.SolverVariable r3 = r3.mSolverVariable
        L_0x02bc:
            android.support.constraint.solver.widgets.ConstraintAnchor r5 = r1.mTarget
            if (r5 == 0) goto L_0x0547
            android.support.constraint.solver.widgets.ConstraintAnchor r5 = r1.mTarget
            android.support.constraint.solver.SolverVariable r6 = r5.mSolverVariable
        L_0x02c4:
            r0 = r18
            if (r2 == r0) goto L_0x02d6
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r2.mListAnchors
            int r6 = r24 + 1
            r5 = r5[r6]
            android.support.constraint.solver.widgets.ConstraintAnchor r6 = r5.mTarget
            if (r6 == 0) goto L_0x054a
            android.support.constraint.solver.widgets.ConstraintAnchor r5 = r5.mTarget
            android.support.constraint.solver.SolverVariable r6 = r5.mSolverVariable
        L_0x02d6:
            r0 = r18
            if (r15 != r0) goto L_0x0551
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r15.mListAnchors
            r4 = r1[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r15.mListAnchors
            int r5 = r24 + 1
            r1 = r1[r5]
            r7 = r1
            r5 = r4
        L_0x02e6:
            if (r3 == 0) goto L_0x0307
            if (r6 == 0) goto L_0x0307
            int r4 = r5.getMargin()
            if (r18 != 0) goto L_0x054d
            r1 = r2
        L_0x02f1:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r1.mListAnchors
            int r2 = r24 + 1
            r1 = r1[r2]
            int r8 = r1.getMargin()
            android.support.constraint.solver.SolverVariable r2 = r5.mSolverVariable
            r5 = 1056964608(0x3f000000, float:0.5)
            android.support.constraint.solver.SolverVariable r7 = r7.mSolverVariable
            r9 = 5
            r1 = r22
            r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9)
        L_0x0307:
            return
        L_0x0308:
            r3 = 0
            goto L_0x025e
        L_0x030b:
            r6 = 0
            goto L_0x0276
        L_0x030e:
            float r5 = r14.mVerticalBiasPercent
            goto L_0x028c
        L_0x0312:
            if (r12 == 0) goto L_0x0414
            if (r15 == 0) goto L_0x0414
            r0 = r25
            int r1 = r0.mWidgetsMatchCount
            if (r1 <= 0) goto L_0x0345
            r0 = r25
            int r1 = r0.mWidgetsCount
            r0 = r25
            int r2 = r0.mWidgetsMatchCount
            if (r1 != r2) goto L_0x0345
            r1 = 1
            r11 = r1
        L_0x0328:
            r13 = r15
            r14 = r15
        L_0x032a:
            if (r13 == 0) goto L_0x040f
            android.support.constraint.solver.widgets.ConstraintWidget[] r1 = r13.mNextChainWidget
            r1 = r1[r23]
            r17 = r1
        L_0x0332:
            if (r17 == 0) goto L_0x0348
            int r1 = r17.getVisibility()
            r2 = 8
            if (r1 != r2) goto L_0x0348
            r0 = r17
            android.support.constraint.solver.widgets.ConstraintWidget[] r1 = r0.mNextChainWidget
            r1 = r1[r23]
            r17 = r1
            goto L_0x0332
        L_0x0345:
            r1 = 0
            r11 = r1
            goto L_0x0328
        L_0x0348:
            if (r17 != 0) goto L_0x034e
            r0 = r18
            if (r13 != r0) goto L_0x03c9
        L_0x034e:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r13.mListAnchors
            r4 = r1[r24]
            android.support.constraint.solver.SolverVariable r2 = r4.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r4.mTarget
            if (r1 == 0) goto L_0x03d7
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r4.mTarget
            android.support.constraint.solver.SolverVariable r3 = r1.mSolverVariable
        L_0x035c:
            if (r14 == r13) goto L_0x03d9
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r14.mListAnchors
            int r3 = r24 + 1
            r1 = r1[r3]
            android.support.constraint.solver.SolverVariable r3 = r1.mSolverVariable
        L_0x0366:
            r1 = 0
            int r4 = r4.getMargin()
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r13.mListAnchors
            int r6 = r24 + 1
            r5 = r5[r6]
            int r8 = r5.getMargin()
            if (r17 == 0) goto L_0x03f6
            r0 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            r1 = r1[r24]
            android.support.constraint.solver.SolverVariable r6 = r1.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r13.mListAnchors
            int r7 = r24 + 1
            r5 = r5[r7]
            android.support.constraint.solver.SolverVariable r7 = r5.mSolverVariable
            r5 = r1
        L_0x0388:
            if (r5 == 0) goto L_0x038f
            int r1 = r5.getMargin()
            int r8 = r8 + r1
        L_0x038f:
            if (r14 == 0) goto L_0x039c
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r14.mListAnchors
            int r5 = r24 + 1
            r1 = r1[r5]
            int r1 = r1.getMargin()
            int r4 = r4 + r1
        L_0x039c:
            if (r2 == 0) goto L_0x03c9
            if (r3 == 0) goto L_0x03c9
            if (r6 == 0) goto L_0x03c9
            if (r7 == 0) goto L_0x03c9
            if (r13 != r15) goto L_0x03ae
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r15.mListAnchors
            r1 = r1[r24]
            int r4 = r1.getMargin()
        L_0x03ae:
            r0 = r18
            if (r13 != r0) goto L_0x03be
            r0 = r18
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            int r5 = r24 + 1
            r1 = r1[r5]
            int r8 = r1.getMargin()
        L_0x03be:
            r9 = 4
            if (r11 == 0) goto L_0x03c2
            r9 = 6
        L_0x03c2:
            r5 = 1056964608(0x3f000000, float:0.5)
            r1 = r22
            r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9)
        L_0x03c9:
            int r1 = r13.getVisibility()
            r2 = 8
            if (r1 == r2) goto L_0x055c
            r1 = r13
        L_0x03d2:
            r13 = r17
            r14 = r1
            goto L_0x032a
        L_0x03d7:
            r3 = 0
            goto L_0x035c
        L_0x03d9:
            if (r13 != r15) goto L_0x0366
            if (r14 != r13) goto L_0x0366
            r0 = r19
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            r1 = r1[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r1.mTarget
            if (r1 == 0) goto L_0x03f3
            r0 = r19
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            r1 = r1[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r1.mTarget
            android.support.constraint.solver.SolverVariable r3 = r1.mSolverVariable
            goto L_0x0366
        L_0x03f3:
            r3 = 0
            goto L_0x0366
        L_0x03f6:
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r0.mListAnchors
            int r6 = r24 + 1
            r5 = r5[r6]
            android.support.constraint.solver.widgets.ConstraintAnchor r5 = r5.mTarget
            if (r5 == 0) goto L_0x0404
            android.support.constraint.solver.SolverVariable r1 = r5.mSolverVariable
        L_0x0404:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r6 = r13.mListAnchors
            int r7 = r24 + 1
            r6 = r6[r7]
            android.support.constraint.solver.SolverVariable r7 = r6.mSolverVariable
            r6 = r1
            goto L_0x0388
        L_0x040f:
            r1 = r15
            r2 = r16
            goto L_0x02a1
        L_0x0414:
            if (r10 == 0) goto L_0x0540
            if (r15 == 0) goto L_0x0540
            r0 = r25
            int r1 = r0.mWidgetsMatchCount
            if (r1 <= 0) goto L_0x0442
            r0 = r25
            int r1 = r0.mWidgetsCount
            r0 = r25
            int r2 = r0.mWidgetsMatchCount
            if (r1 != r2) goto L_0x0442
            r1 = 1
            r11 = r1
        L_0x042a:
            r17 = r15
            r14 = r15
        L_0x042d:
            if (r14 == 0) goto L_0x04da
            android.support.constraint.solver.widgets.ConstraintWidget[] r1 = r14.mNextChainWidget
            r1 = r1[r23]
        L_0x0433:
            if (r1 == 0) goto L_0x0445
            int r2 = r1.getVisibility()
            r3 = 8
            if (r2 != r3) goto L_0x0445
            android.support.constraint.solver.widgets.ConstraintWidget[] r1 = r1.mNextChainWidget
            r1 = r1[r23]
            goto L_0x0433
        L_0x0442:
            r1 = 0
            r11 = r1
            goto L_0x042a
        L_0x0445:
            if (r14 == r15) goto L_0x04b4
            r0 = r18
            if (r14 == r0) goto L_0x04b4
            if (r1 == 0) goto L_0x04b4
            r0 = r18
            if (r1 != r0) goto L_0x0555
            r13 = 0
        L_0x0452:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r14.mListAnchors
            r4 = r1[r24]
            android.support.constraint.solver.SolverVariable r2 = r4.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r4.mTarget
            if (r1 == 0) goto L_0x0460
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r4.mTarget
            android.support.constraint.solver.SolverVariable r1 = r1.mSolverVariable
        L_0x0460:
            r0 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            int r3 = r24 + 1
            r1 = r1[r3]
            android.support.constraint.solver.SolverVariable r3 = r1.mSolverVariable
            r1 = 0
            int r4 = r4.getMargin()
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r14.mListAnchors
            int r6 = r24 + 1
            r5 = r5[r6]
            int r8 = r5.getMargin()
            if (r13 == 0) goto L_0x04c4
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r13.mListAnchors
            r5 = r1[r24]
            android.support.constraint.solver.SolverVariable r6 = r5.mSolverVariable
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r5.mTarget
            if (r1 == 0) goto L_0x04c2
            android.support.constraint.solver.widgets.ConstraintAnchor r1 = r5.mTarget
            android.support.constraint.solver.SolverVariable r1 = r1.mSolverVariable
        L_0x0489:
            r7 = r1
        L_0x048a:
            if (r5 == 0) goto L_0x0491
            int r1 = r5.getMargin()
            int r8 = r8 + r1
        L_0x0491:
            if (r17 == 0) goto L_0x04a0
            r0 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r0.mListAnchors
            int r5 = r24 + 1
            r1 = r1[r5]
            int r1 = r1.getMargin()
            int r4 = r4 + r1
        L_0x04a0:
            r9 = 4
            if (r11 == 0) goto L_0x04a4
            r9 = 6
        L_0x04a4:
            if (r2 == 0) goto L_0x04b3
            if (r3 == 0) goto L_0x04b3
            if (r6 == 0) goto L_0x04b3
            if (r7 == 0) goto L_0x04b3
            r5 = 1056964608(0x3f000000, float:0.5)
            r1 = r22
            r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9)
        L_0x04b3:
            r1 = r13
        L_0x04b4:
            int r2 = r14.getVisibility()
            r3 = 8
            if (r2 == r3) goto L_0x0558
            r2 = r14
        L_0x04bd:
            r17 = r2
            r14 = r1
            goto L_0x042d
        L_0x04c2:
            r1 = 0
            goto L_0x0489
        L_0x04c4:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r5 = r14.mListAnchors
            int r6 = r24 + 1
            r5 = r5[r6]
            android.support.constraint.solver.widgets.ConstraintAnchor r5 = r5.mTarget
            if (r5 == 0) goto L_0x04d0
            android.support.constraint.solver.SolverVariable r1 = r5.mSolverVariable
        L_0x04d0:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r6 = r14.mListAnchors
            int r7 = r24 + 1
            r6 = r6[r7]
            android.support.constraint.solver.SolverVariable r7 = r6.mSolverVariable
            r6 = r1
            goto L_0x048a
        L_0x04da:
            android.support.constraint.solver.widgets.ConstraintAnchor[] r1 = r15.mListAnchors
            r1 = r1[r24]
            r0 = r19
            android.support.constraint.solver.widgets.ConstraintAnchor[] r2 = r0.mListAnchors
            r2 = r2[r24]
            android.support.constraint.solver.widgets.ConstraintAnchor r3 = r2.mTarget
            r0 = r18
            android.support.constraint.solver.widgets.ConstraintAnchor[] r2 = r0.mListAnchors
            int r4 = r24 + 1
            r11 = r2[r4]
            r0 = r16
            android.support.constraint.solver.widgets.ConstraintAnchor[] r2 = r0.mListAnchors
            int r4 = r24 + 1
            r2 = r2[r4]
            android.support.constraint.solver.widgets.ConstraintAnchor r13 = r2.mTarget
            if (r3 == 0) goto L_0x050c
            r0 = r18
            if (r15 == r0) goto L_0x0525
            android.support.constraint.solver.SolverVariable r2 = r1.mSolverVariable
            android.support.constraint.solver.SolverVariable r3 = r3.mSolverVariable
            int r1 = r1.getMargin()
            r4 = 5
            r0 = r22
            r0.addEquality(r2, r3, r1, r4)
        L_0x050c:
            if (r13 == 0) goto L_0x0521
            r0 = r18
            if (r15 == r0) goto L_0x0521
            android.support.constraint.solver.SolverVariable r1 = r11.mSolverVariable
            android.support.constraint.solver.SolverVariable r2 = r13.mSolverVariable
            int r3 = r11.getMargin()
            int r3 = -r3
            r4 = 5
            r0 = r22
            r0.addEquality(r1, r2, r3, r4)
        L_0x0521:
            r2 = r16
            goto L_0x02a2
        L_0x0525:
            if (r13 == 0) goto L_0x050c
            android.support.constraint.solver.SolverVariable r2 = r1.mSolverVariable
            android.support.constraint.solver.SolverVariable r3 = r3.mSolverVariable
            int r4 = r1.getMargin()
            r5 = 1056964608(0x3f000000, float:0.5)
            android.support.constraint.solver.SolverVariable r6 = r11.mSolverVariable
            android.support.constraint.solver.SolverVariable r7 = r13.mSolverVariable
            int r8 = r11.getMargin()
            r9 = 5
            r1 = r22
            r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9)
            goto L_0x050c
        L_0x0540:
            r2 = r16
            goto L_0x02a2
        L_0x0544:
            r3 = 0
            goto L_0x02bc
        L_0x0547:
            r6 = 0
            goto L_0x02c4
        L_0x054a:
            r6 = 0
            goto L_0x02d6
        L_0x054d:
            r1 = r18
            goto L_0x02f1
        L_0x0551:
            r7 = r1
            r5 = r4
            goto L_0x02e6
        L_0x0555:
            r13 = r1
            goto L_0x0452
        L_0x0558:
            r2 = r17
            goto L_0x04bd
        L_0x055c:
            r1 = r14
            goto L_0x03d2
        L_0x055f:
            r3 = r5
            goto L_0x01b1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.solver.widgets.Chain.applyChainConstraints(android.support.constraint.solver.widgets.ConstraintWidgetContainer, android.support.constraint.solver.LinearSystem, int, int, android.support.constraint.solver.widgets.ChainHead):void");
    }
}
