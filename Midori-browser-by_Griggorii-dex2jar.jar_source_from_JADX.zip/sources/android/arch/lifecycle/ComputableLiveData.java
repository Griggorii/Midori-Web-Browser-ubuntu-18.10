package android.arch.lifecycle;

import android.arch.core.executor.ArchTaskExecutor;
import android.support.annotation.MainThread;
import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;
import android.support.annotation.VisibleForTesting;
import android.support.annotation.WorkerThread;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public abstract class ComputableLiveData<T> {
    /* access modifiers changed from: private */
    public AtomicBoolean mComputing;
    /* access modifiers changed from: private */
    public final Executor mExecutor;
    /* access modifiers changed from: private */
    public AtomicBoolean mInvalid;
    @VisibleForTesting
    final Runnable mInvalidationRunnable;
    /* access modifiers changed from: private */
    public final LiveData<T> mLiveData;
    @VisibleForTesting
    final Runnable mRefreshRunnable;

    public ComputableLiveData() {
        this(ArchTaskExecutor.getIOThreadExecutor());
    }

    public ComputableLiveData(@NonNull Executor executor) {
        this.mInvalid = new AtomicBoolean(true);
        this.mComputing = new AtomicBoolean(false);
        this.mRefreshRunnable = new Runnable() {
            /* JADX WARNING: Removed duplicated region for block: B:17:0x0054  */
            /* JADX WARNING: Removed duplicated region for block: B:3:0x000e  */
            @android.support.annotation.WorkerThread
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                    r7 = this;
                    r3 = 1
                    r1 = 0
                L_0x0002:
                    android.arch.lifecycle.ComputableLiveData r0 = android.arch.lifecycle.ComputableLiveData.this
                    java.util.concurrent.atomic.AtomicBoolean r0 = r0.mComputing
                    boolean r0 = r0.compareAndSet(r1, r3)
                    if (r0 == 0) goto L_0x0054
                    r2 = 0
                    r0 = r1
                L_0x0010:
                    android.arch.lifecycle.ComputableLiveData r4 = android.arch.lifecycle.ComputableLiveData.this     // Catch:{ all -> 0x0049 }
                    java.util.concurrent.atomic.AtomicBoolean r4 = r4.mInvalid     // Catch:{ all -> 0x0049 }
                    r5 = 1
                    r6 = 0
                    boolean r4 = r4.compareAndSet(r5, r6)     // Catch:{ all -> 0x0049 }
                    if (r4 == 0) goto L_0x0026
                    android.arch.lifecycle.ComputableLiveData r0 = android.arch.lifecycle.ComputableLiveData.this     // Catch:{ all -> 0x0049 }
                    java.lang.Object r2 = r0.compute()     // Catch:{ all -> 0x0049 }
                    r0 = r3
                    goto L_0x0010
                L_0x0026:
                    if (r0 == 0) goto L_0x0031
                    android.arch.lifecycle.ComputableLiveData r4 = android.arch.lifecycle.ComputableLiveData.this     // Catch:{ all -> 0x0049 }
                    android.arch.lifecycle.LiveData r4 = r4.mLiveData     // Catch:{ all -> 0x0049 }
                    r4.postValue(r2)     // Catch:{ all -> 0x0049 }
                L_0x0031:
                    android.arch.lifecycle.ComputableLiveData r2 = android.arch.lifecycle.ComputableLiveData.this
                    java.util.concurrent.atomic.AtomicBoolean r2 = r2.mComputing
                    r2.set(r1)
                L_0x003a:
                    if (r0 == 0) goto L_0x0048
                    android.arch.lifecycle.ComputableLiveData r0 = android.arch.lifecycle.ComputableLiveData.this
                    java.util.concurrent.atomic.AtomicBoolean r0 = r0.mInvalid
                    boolean r0 = r0.get()
                    if (r0 != 0) goto L_0x0002
                L_0x0048:
                    return
                L_0x0049:
                    r0 = move-exception
                    android.arch.lifecycle.ComputableLiveData r2 = android.arch.lifecycle.ComputableLiveData.this
                    java.util.concurrent.atomic.AtomicBoolean r2 = r2.mComputing
                    r2.set(r1)
                    throw r0
                L_0x0054:
                    r0 = r1
                    goto L_0x003a
                */
                throw new UnsupportedOperationException("Method not decompiled: android.arch.lifecycle.ComputableLiveData.C00052.run():void");
            }
        };
        this.mInvalidationRunnable = new Runnable() {
            @MainThread
            public void run() {
                boolean hasActiveObservers = ComputableLiveData.this.mLiveData.hasActiveObservers();
                if (ComputableLiveData.this.mInvalid.compareAndSet(false, true) && hasActiveObservers) {
                    ComputableLiveData.this.mExecutor.execute(ComputableLiveData.this.mRefreshRunnable);
                }
            }
        };
        this.mExecutor = executor;
        this.mLiveData = new LiveData<T>() {
            /* access modifiers changed from: protected */
            public void onActive() {
                ComputableLiveData.this.mExecutor.execute(ComputableLiveData.this.mRefreshRunnable);
            }
        };
    }

    /* access modifiers changed from: protected */
    @WorkerThread
    public abstract T compute();

    @NonNull
    public LiveData<T> getLiveData() {
        return this.mLiveData;
    }

    public void invalidate() {
        ArchTaskExecutor.getInstance().executeOnMainThread(this.mInvalidationRunnable);
    }
}
