package android.arch.lifecycle;

public interface LifecycleObserver {
}
