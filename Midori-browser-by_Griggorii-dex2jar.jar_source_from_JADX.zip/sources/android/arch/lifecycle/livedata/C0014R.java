package android.arch.lifecycle.livedata;

/* renamed from: android.arch.lifecycle.livedata.R */
public final class C0014R {
    private C0014R() {
    }
}
