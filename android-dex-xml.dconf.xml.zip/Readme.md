                                                               Griggorii@gmail.com

                                                                     New Dex OS

android-dex-xml.dconf.xml test fix utf-8

dexdump -l xml classes.dex | less > android-dex-xml.dconf.xml

dexdump -l plain classes.dex | less > android-dex.dconf

https://youtu.be/k6EGJOsB3fQ
