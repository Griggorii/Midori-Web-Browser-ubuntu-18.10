/*
 Copyright (C) 2018 Christian Dywan <christian@twotoats.de>

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 See the file COPYING for the full license text.
*/

#define CORE_VERSION "8.0"
#define CORE_USER_AGENT_VERSION "Midori/6"
#define PROJECT_NAME "midori"
#define PROJECT_BUGS "https://github.com/midori-browser/core/issues"
#define PROJECT_WEBSITE "https://www.midori-browser.org"

#define DATADIR "/usr/local/share"
/* #undef SYSCONFDIR */
/* #undef LIBDIR */
#define PLUGINDIR "/usr/local/lib/midori"
/* #undef DOCDIR */
/* #undef LOCALEDIR */
